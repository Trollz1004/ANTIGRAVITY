import React, { useState, useEffect } from 'react';
import { View, AuditLog, DaoLaunch } from './types';
import Sidebar from './components/Sidebar';
import DashboardView from './components/DashboardView';
import CommandCenter from './components/CommandCenter';
import DaoGovernance from './components/DaoGovernance';
import AuditLogTable from './components/AuditLogTable';
import SecurityNexus from './components/SecurityNexus';
import ImpactTracker from './components/ImpactTracker';
import DatingManager from './components/DatingManager';
import StoreCommand from './components/StoreCommand';
import DaoTable from './components/DaoTable';
import AntigravityConsole from './components/AntigravityConsole';
import ScriptGenerator from './components/ScriptGenerator';
import EduNexus from './components/EduNexus';
import PrWizard from './components/PrWizard';
import CodeReviewer from './components/CodeReviewer';
import MediaStudio from './components/MediaStudio';
import KidsCorner from './components/KidsCorner';
import CometBrowser from './components/CometBrowser';
import ChatView from './components/ChatView';
import LiveChatView from './components/LiveChatView';
import MobileBridge from './components/MobileBridge';
import LaunchPad from './components/LaunchPad';
import TwoFactorAuth from './components/TwoFactorAuth';
import TitleBar from './components/TitleBar';
import MissionManifesto from './components/MissionManifesto';
import { DatingLanding } from './components/DatingLanding';
import { ShieldCheck, Lock, Users, Server, Activity, Share } from './components/IconComponents';
import { initialDaoLaunches, initialAuditLogs } from './data/mockData';

const App: React.FC = () => {
    const [view, setView] = useState<View>('dashboard');
    const [isMobileOpen, setIsMobileOpen] = useState(false);
    const [isAuthenticated, setIsAuthenticated] = useState(false);
    const [currentUser, setCurrentUser] = useState<any>(null);
    const [authError, setAuthError] = useState('');
    const [isMissionOpen, setIsMissionOpen] = useState(false);
    
    // 2FA State
    const [is2FAEnabled, setIs2FAEnabled] = useState(false);
    const [is2FAVerified, setIs2FAVerified] = useState(false);
    const [show2FASetup, setShow2FASetup] = useState(false);

    // Data State
    const [auditLogs, setAuditLogs] = useState<AuditLog[]>(initialAuditLogs);
    const [daoLaunches, setDaoLaunches] = useState<DaoLaunch[]>(initialDaoLaunches);

    useEffect(() => {
        // Check for saved user session
        const savedUser = localStorage.getItem('aiCollabUser');
        if (savedUser) {
            const user = JSON.parse(savedUser);
            setCurrentUser(user);
            
            const user2FA = localStorage.getItem('aiCollabUser2FA');
            if (user2FA === 'enabled') {
                setIs2FAEnabled(true);
                // For simplified persistence in this demo, assume verified if session exists
                setIs2FAVerified(true); 
            }
            setIsAuthenticated(true);
        }

        // Initialize Google Identity
        const initGoogle = () => {
            const clientId = process.env.VITE_GOOGLE_CLIENT_ID;
            if ((window as any).google && clientId && clientId !== 'undefined') {
                (window as any).google.accounts.id.initialize({
                    client_id: clientId,
                    callback: handleCredentialResponse,
                    auto_select: true // Attempt auto-login if one account
                });
                (window as any).google.accounts.id.renderButton(
                    document.getElementById("googleSignInDiv"),
                    { theme: "filled_black", size: "large", text: "continue_with", shape: "pill" }
                );
                // Trigger One Tap if appropriate
                (window as any).google.accounts.id.prompt();
            } else {
                console.warn("Google Client ID missing or invalid. Standard Google Sign-In disabled. Use Owner Access.");
            }
        };
        
        if (!(window as any).google) {
             const script = document.createElement('script');
             script.src = "https://accounts.google.com/gsi/client";
             script.async = true;
             script.defer = true;
             script.onload = initGoogle;
             document.body.appendChild(script);
        } else {
            initGoogle();
        }
    }, []);

    const handleCredentialResponse = (response: any) => {
        // Decode JWT
        const base64Url = response.credential.split('.')[1];
        const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
        const jsonPayload = decodeURIComponent(window.atob(base64).split('').map(function(c) {
            return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
        }).join(''));
        
        const payload = JSON.parse(jsonPayload);

        // Allow owner or verify logic
        if (payload.email === 'joshlcoleman@gmail.com' || payload.email_verified) {
             // Check if 2FA is enabled
            const user2FA = localStorage.getItem('aiCollabUser2FA');
            if (user2FA === 'enabled') {
                setIs2FAEnabled(true);
                setCurrentUser(payload); // Temporarily set user but wait for 2FA
                setIs2FAVerified(false);
                // Don't set isAuthenticated yet
            } else {
                setIsAuthenticated(true);
                setCurrentUser(payload);
                localStorage.setItem('aiCollabUser', JSON.stringify(payload));
                
                // Log the login
                const newLog: AuditLog = {
                    id: Date.now().toString(),
                    action: 'Admin Login',
                    details: 'Secure login via Google Identity',
                    user: payload.email,
                    timestamp: new Date().toISOString(),
                    status: 'success'
                };
                setAuditLogs(prev => [newLog, ...prev]);
            }
            setAuthError('');
        } else {
            setAuthError('Unauthorized Account. Access Restricted.');
        }
    };

    const handleDevBypass = () => {
        // Direct bypass for Josh to prevent auth denials in AI Studio preview
        const ownerUser = {
            email: 'joshlcoleman@gmail.com',
            name: 'Joshua Coleman (Architect)',
            picture: 'https://github.com/Trollz1004.png',
            email_verified: true
        };
        
        setCurrentUser(ownerUser);
        setIsAuthenticated(true);
        localStorage.setItem('aiCollabUser', JSON.stringify(ownerUser));
        
        const newLog: AuditLog = {
            id: Date.now().toString(),
            action: 'Dev-Bypass Login',
            details: 'Bypassed standard Google OAuth for owner access',
            user: ownerUser.email,
            timestamp: new Date().toISOString(),
            status: 'success'
        };
        setAuditLogs(prev => [newLog, ...prev]);
        setAuthError('');
    };

    const handleLogout = () => {
        setIsAuthenticated(false);
        setCurrentUser(null);
        setIs2FAVerified(false);
        localStorage.removeItem('aiCollabUser');
        // Log logout
         const newLog: AuditLog = {
            id: Date.now().toString(),
            action: 'Admin Logout',
            details: 'User logged out manually',
            user: currentUser?.email || 'Unknown',
            timestamp: new Date().toISOString(),
            status: 'success'
        };
        setAuditLogs(prev => [newLog, ...prev]);
    };

    const handle2FAVerify = () => {
        setIs2FAVerified(true);
        setIsAuthenticated(true);
        localStorage.setItem('aiCollabUser', JSON.stringify(currentUser));
        // Log success
         const newLog: AuditLog = {
            id: Date.now().toString(),
            action: '2FA Verification',
            details: 'Two-factor authentication successful',
            user: currentUser.email,
            timestamp: new Date().toISOString(),
            status: 'success'
        };
        setAuditLogs(prev => [newLog, ...prev]);
    };

    const enable2FA = () => {
        setIs2FAEnabled(true);
        setIs2FAVerified(true);
        localStorage.setItem('aiCollabUser2FA', 'enabled');
        setShow2FASetup(false);
        alert("2FA Enabled Successfully!");
    };

    // Render Login
    if (!isAuthenticated && !currentUser) {
        return (
            <div className="min-h-screen bg-[#050505] flex items-center justify-center relative overflow-hidden">
                <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10"></div>
                <div className="glass-card p-10 max-w-md w-full text-center relative z-10 border border-white/10 shadow-2xl">
                    <div className="w-20 h-20 bg-indigo-600/20 rounded-full flex items-center justify-center mx-auto mb-6 border border-indigo-500/30">
                        <ShieldCheck className="w-10 h-10 text-indigo-400" />
                    </div>
                    <h1 className="text-3xl font-bold text-white mb-2">AiCollab<span className="text-indigo-400">Admin</span></h1>
                    <p className="text-slate-400 mb-8 text-sm">Secure Enterprise Gateway</p>
                    
                    <div className="flex flex-col items-center gap-4 mb-6">
                        <div id="googleSignInDiv"></div>
                        
                        <div className="w-full flex items-center gap-2">
                            <div className="flex-1 h-px bg-white/10"></div>
                            <span className="text-[10px] text-slate-500 uppercase font-bold">Owner Access</span>
                            <div className="flex-1 h-px bg-white/10"></div>
                        </div>

                        <button 
                            onClick={handleDevBypass}
                            className="w-full py-2.5 bg-indigo-600/10 hover:bg-indigo-600/20 text-indigo-400 border border-indigo-500/30 rounded-full text-sm font-bold transition-all flex items-center justify-center gap-2"
                        >
                            <Users className="w-4 h-4" />
                            Joshua's Quick Access
                        </button>
                    </div>
                    
                    {authError && (
                        <div className="p-3 bg-red-900/30 border border-red-500/30 rounded-lg text-red-400 text-sm flex items-center justify-center gap-2">
                            <Lock className="w-4 h-4" /> {authError}
                        </div>
                    )}
                    
                    <p className="mt-8 text-xs text-slate-500 font-mono">
                        SYSTEM ID: GEMINI-PRO-X1
                        <br />
                        PROTECTED BY GOOGLE CLOUD
                    </p>
                </div>
            </div>
        );
    }

    // Render 2FA Verify
    if (!isAuthenticated && currentUser && is2FAEnabled && !is2FAVerified) {
        return <TwoFactorAuth mode="verify" onVerify={handle2FAVerify} onCancel={() => { setCurrentUser(null); setIs2FAEnabled(false); }} />;
    }
    
    // Render 2FA Setup
    if (show2FASetup) {
        return <TwoFactorAuth mode="setup" onVerify={enable2FA} onCancel={() => setShow2FASetup(false)} />;
    }

    // Render Main App
    return (
        <div className="flex h-screen bg-[#0f172a] text-slate-100 font-sans overflow-hidden">
            <Sidebar 
                currentView={view} 
                onSetView={setView} 
                isMobileOpen={isMobileOpen} 
                onMobileClose={() => setIsMobileOpen(false)}
                onOpenMission={() => setIsMissionOpen(true)}
            />
            
            <div className="flex-1 flex flex-col min-w-0 relative">
                <TitleBar />
                <div className="mt-[30px] flex-1 overflow-hidden relative flex flex-col animate-in fade-in duration-500">
                    {/* View Router */}
                    {view === 'dashboard' && <DashboardView />}
                    {view === 'launch' && <LaunchPad />}
                    {view === 'command' && <CommandCenter onLogAction={(a, d) => setAuditLogs(prev => [{id: Date.now().toString(), action: a, details: d, user: currentUser.email, timestamp: new Date().toISOString(), status: 'success'}, ...prev])} repoStatus="Synced" onCheckStatus={() => {}} />}
                    {view === 'governance' && <DaoGovernance />}
                    {view === 'audit' && <AuditLogTable logs={auditLogs} />}
                    {view === 'security' && <SecurityNexus onEnable2FA={() => setShow2FASetup(true)} is2FAEnabled={is2FAEnabled} />}
                    {view === 'impact' && <ImpactTracker />}
                    {view === 'dating' && <DatingManager />}
                    {view === 'dating-site' && <DatingLanding onClose={() => setView('dashboard')} />}
                    {view === 'store' && <StoreCommand />}
                    {view === 'dao' && <DaoTable daoLaunches={daoLaunches} onAnalyze={() => {}} />}
                    {view === 'antigravity' && <AntigravityConsole />}
                    {view === 'scripts' && <ScriptGenerator />}
                    {view === 'edu' && <EduNexus />}
                    {view === 'pr' && <PrWizard />}
                    {view === 'review' && <CodeReviewer />}
                    {view === 'media' && <MediaStudio />}
                    {view === 'kids' && <KidsCorner />}
                    {view === 'browser' && <CometBrowser />}
                    {view === 'chat' && <ChatView />}
                    {view === 'live' && <LiveChatView />}
                    {view === 'mobile' && <MobileBridge />}
                    
                    {/* New Views for Local Fleet */}
                    {view === 'command-1004' && (
                        <div className="flex-1 bg-black flex flex-col">
                            <div className="p-2 bg-slate-800 flex justify-between items-center text-xs border-b border-white/10">
                                <div className="flex items-center gap-2">
                                    <Server className="w-4 h-4 text-green-400" />
                                    <span className="font-bold text-white">Local Node: Port 1004</span>
                                    <span className="text-slate-400 font-mono">(Joshua's Port)</span>
                                </div>
                                <button className="text-blue-400 hover:text-white" onClick={() => window.open('http://localhost:1004', '_blank')}>Open External</button>
                            </div>
                            <iframe src="http://localhost:1004" className="flex-1 w-full h-full border-none" title="Command Dashboard 1004" />
                        </div>
                    )}
                    {view === 'hive' && (
                        <div className="flex-1 p-6 overflow-y-auto bg-slate-900">
                            <header className="glass-card p-6 mb-8 border-l-4 border-yellow-500">
                                <h1 className="text-3xl font-bold text-white flex items-center gap-3">
                                    <Activity className="w-8 h-8 text-yellow-400" />
                                    HIVE Swarm Status
                                </h1>
                                <p className="text-slate-400 mt-1">Real-time status of autonomous agents.</p>
                            </header>
                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                                {/* Placeholder HIVE Cards */}
                                <div className="glass-card p-6 flex flex-col items-center justify-center min-h-[200px]">
                                    <p className="text-slate-500">HIVE Dashboard coming soon...</p>
                                    <p className="text-xs text-slate-600 mt-2">Connecting to Agent Swarm...</p>
                                </div>
                            </div>
                        </div>
                    )}
                    {view === 'droid' && (
                        <div className="flex-1 p-6 overflow-y-auto bg-slate-900">
                            <header className="glass-card p-6 mb-8 border-l-4 border-purple-500">
                                <h1 className="text-3xl font-bold text-white flex items-center gap-3">
                                    <Share className="w-8 h-8 text-purple-400" />
                                    Claude Droid Social
                                </h1>
                                <p className="text-slate-400 mt-1">Automated Social Media Operations.</p>
                            </header>
                            <div className="glass-card p-6 flex flex-col items-center justify-center min-h-[300px]">
                                <p className="text-slate-500">Social Posting Interface Loading...</p>
                            </div>
                        </div>
                    )}
                </div>
            </div>
            
            <MissionManifesto isOpen={isMissionOpen} onClose={() => setIsMissionOpen(false)} />
        </div>
    );
};

export default App;