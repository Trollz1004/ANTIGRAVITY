
import { type DaoLaunch, type StartupKpis, type AuditLog, type AntigravityApplicant } from '../types';

// THE COLEMAN PROTOCOL - MISSION EXPANSION (Jan 6, 2026)
// Focus: Human Independence & Special Needs Support
// Disbursement: 100.00% to Public Utility

export const initialDaoLaunches: DaoLaunch[] = [
  { 
    id: '1', 
    name: 'Coleman Independence Fund', 
    token: 'LIFE-100', 
    treasury: 58050, 
    launchDate: '2025-12-10T09:00:00.000Z', 
    proposals: 15 
  },
  { 
    id: '2', 
    name: 'Adaptive Tech Node', 
    token: 'ADAPT-X', 
    treasury: 12000, 
    launchDate: '2026-01-06T08:00:00.000Z', 
    proposals: 2 
  },
];

export const initialStartupKpis: StartupKpis = {
  mrr: 0, 
  cac: 0.00,
  churnRate: '0.0%', 
  burnRate: 0, 
  runway: 9999, 
};

export const initialAuditLogs: AuditLog[] = [
    {
      id: 'coleman-v1',
      action: 'PROTOCOL COLEMAN ACTIVE',
      details: 'Mission expanded to include Specialized Life Skills for adults/kids with disabilities. Dedication to Founder brother hardcoded.',
      user: 'Architect',
      timestamp: '2026-01-06T19:30:00Z',
      status: 'success',
      metadata: { actionType: 'security' }
    },
    {
      id: 'lifeskills-001',
      action: 'LIFE SKILLS HUB SYNC',
      details: 'Integrated automated task and memory management templates for neurodiverse independence.',
      user: 'Jules (Admin)',
      timestamp: '2026-01-06T19:15:00Z',
      status: 'success',
      metadata: { actionType: 'none' }
    }
];

export const initialAntigravityApplicants: AntigravityApplicant[] = [
    {
        id: 'ag1',
        name: 'Adaptive Tech Team (Tribute)',
        email: 'tribute@DeepMind.ai',
        specialty: 'AI/ML',
        github: 'deepmind_open',
        pitch: 'Confirming alignment with COLEMAN PROTOCOL. Our tools will prioritize adaptive interfaces for the handicapable.',
        status: 'accepted',
        score: 100,
        appliedAt: '2026-01-06T00:00:00Z'
    }
];
