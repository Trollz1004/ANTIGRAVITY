
import React from 'react';
import { Heart, X, ShieldCheck, Gem, UserCheck, ArrowRight } from './IconComponents';

interface DatingLandingProps {
  onClose: () => void;
}

export const DatingLanding: React.FC<DatingLandingProps> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 z-50 bg-black overflow-y-auto">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 p-6 flex justify-between items-center z-50 bg-gradient-to-b from-black/80 to-transparent backdrop-blur-sm">
        <div className="flex items-center gap-2">
          <Heart className="w-8 h-8 text-pink-500 fill-pink-500" />
          <span className="text-2xl font-bold text-white tracking-tighter">YouAndI<span className="text-pink-500">NotAI</span></span>
        </div>
        <button 
          onClick={onClose}
          className="p-2 bg-white/10 hover:bg-white/20 rounded-full text-white transition-colors border border-white/10"
        >
          <X className="w-6 h-6" />
        </button>
      </nav>

      {/* Hero Section */}
      <section className="relative min-h-screen flex flex-col items-center justify-center text-center p-6 pt-24 overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1517849845537-4d257902454a?q=80&w=2835&auto=format&fit=crop')] bg-cover bg-center opacity-30"></div>
        <div className="absolute inset-0 bg-gradient-to-b from-black via-transparent to-black"></div>
        
        <div className="relative z-10 max-w-4xl mx-auto space-y-8">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-pink-500/20 border border-pink-500/40 text-pink-300 text-sm font-bold uppercase tracking-widest animate-fade-in-up">
            <ShieldCheck className="w-4 h-4" /> 100% Human Verified
          </div>
          
          <h1 className="text-5xl md:text-7xl font-black text-white tracking-tight leading-none animate-fade-in-up delay-100">
            Love is Real.<br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-pink-500 via-purple-500 to-indigo-500">Not Generated.</span>
          </h1>
          
          <p className="text-xl md:text-2xl text-slate-300 max-w-2xl mx-auto font-light leading-relaxed animate-fade-in-up delay-200">
            The world's first dating platform where every interaction is verified human. No bots. No AI chatbots. Just real connections.
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 animate-fade-in-up delay-300">
            <button className="px-8 py-4 bg-pink-600 hover:bg-pink-500 text-white rounded-full font-bold text-lg transition-all hover:scale-105 shadow-[0_0_30px_rgba(236,72,153,0.5)] flex items-center gap-2">
              Find Your Match <ArrowRight className="w-5 h-5" />
            </button>
            <button className="px-8 py-4 bg-white/10 hover:bg-white/20 text-white rounded-full font-bold text-lg transition-all border border-white/20 backdrop-blur-md">
              Learn the Protocol
            </button>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-24 px-6 bg-zinc-900">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-12">
          <div className="text-center space-y-4">
            <div className="w-20 h-20 bg-zinc-800 rounded-2xl flex items-center justify-center mx-auto rotate-3 hover:rotate-6 transition-transform">
              <UserCheck className="w-10 h-10 text-pink-500" />
            </div>
            <h3 className="text-2xl font-bold text-white">ID Verified Humans</h3>
            <p className="text-slate-400 leading-relaxed">Every user must pass a biometric liveness check. We purge bots instantly.</p>
          </div>
          <div className="text-center space-y-4">
            <div className="w-20 h-20 bg-zinc-800 rounded-2xl flex items-center justify-center mx-auto -rotate-3 hover:-rotate-6 transition-transform">
              <ShieldCheck className="w-10 h-10 text-purple-500" />
            </div>
            <h3 className="text-2xl font-bold text-white">Anti-Catfish AI</h3>
            <p className="text-slate-400 leading-relaxed">Our Guardian AI (Jules) monitors patterns to stop scammers before they message you.</p>
          </div>
          <div className="text-center space-y-4">
            <div className="w-20 h-20 bg-zinc-800 rounded-2xl flex items-center justify-center mx-auto rotate-3 hover:rotate-6 transition-transform">
              <Gem className="w-10 h-10 text-yellow-500" />
            </div>
            <h3 className="text-2xl font-bold text-white">Date for Charity</h3>
            <p className="text-slate-400 leading-relaxed">100% of platform profits go to verified pediatric charities. Date with purpose.</p>
          </div>
        </div>
      </section>

      {/* CTA Footer */}
      <section className="py-24 px-6 bg-black border-t border-white/10 text-center">
        <div className="max-w-3xl mx-auto space-y-8">
          <Heart className="w-16 h-16 text-pink-600 mx-auto fill-pink-600 animate-pulse" />
          <h2 className="text-4xl md:text-5xl font-black text-white">Ready for something real?</h2>
          <p className="text-slate-400">Join the waitlist for the God Tier Dating Platform.</p>
          <button className="px-10 py-5 bg-white text-black rounded-full font-black text-xl hover:bg-slate-200 transition-colors">
            JOIN GENESIS LIST
          </button>
        </div>
      </section>
    </div>
  );
};
