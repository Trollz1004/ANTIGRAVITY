import React, { useState } from 'react';
import { ShieldCheck, ShieldAlert, Lock, CheckCircle, FileText, AlertTriangle, Server, Key, Heart, Users, Activity } from './IconComponents';
import { ComplianceCheck } from '../types';

// Fix: Added SecurityNexusProps interface to handle 2FA state from App.tsx
interface SecurityNexusProps {
  onEnable2FA: () => void;
  is2FAEnabled: boolean;
}

const SecurityNexus: React.FC<SecurityNexusProps> = ({ onEnable2FA, is2FAEnabled }) => {
  const [complianceChecks] = useState<ComplianceCheck[]>([
    { id: '1', name: 'JOSH100GOSPEL Enforcement', category: 'financial', status: 'pass', details: 'Zero-profit logic locked in smart contract.', lastChecked: 'Live' },
    { id: '2', name: 'Opus Trust Succession', category: 'legal', status: 'pass', details: 'Tiered beneficiary keys loaded.', lastChecked: '1 hour ago' },
    { id: '3', name: 'AI Tribute Handshake', category: 'technical', status: 'pass', details: 'Tribute Node acknowledgement verified.', lastChecked: 'Live' },
    { id: '4', name: 'Public Vote Integration', category: 'technical', status: 'pass', details: 'Real-time routing counter active.', lastChecked: 'Live' },
  ]);

  return (
    <main className="flex-1 p-6 overflow-y-auto bg-[#0a0a0a]">
      <header className="glass-card p-6 mb-8 border-l-4 border-indigo-500 flex justify-between items-center bg-indigo-950/10">
        <div>
            <h1 className="text-3xl font-bold text-white flex items-center gap-3">
                <ShieldCheck className="w-8 h-8 text-indigo-400" />
                Sovereign Succession Nexus
            </h1>
            <p className="text-slate-400 mt-1">Protecting family legacy and AI tribute in perpetuity.</p>
        </div>
        {/* Fix: Added 2FA Setup button in SecurityNexus header */}
        <div className="flex items-center gap-3">
          {!is2FAEnabled ? (
            <button 
              onClick={onEnable2FA}
              className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-bold rounded-xl transition-all shadow-lg shadow-indigo-900/40"
            >
              <Lock className="w-4 h-4" />
              Setup 2FA
            </button>
          ) : (
            <div className="flex items-center gap-2 px-4 py-2 bg-green-500/10 border border-green-500/20 rounded-xl">
              <ShieldCheck className="w-4 h-4 text-green-400" />
              <span className="text-sm font-bold text-green-400">2FA Protected</span>
            </div>
          )}
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          
          <div className="glass-card p-8 border border-indigo-500/30 bg-indigo-900/10 relative overflow-hidden">
              <div className="absolute top-0 right-0 p-4 opacity-5">
                  <Heart className="w-48 h-48 text-indigo-400" />
              </div>
              <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-3 relative z-10">
                  <Key className="w-6 h-6 text-indigo-400" />
                  Dead Man's Switch: OPUS-TRUST-V2
              </h3>
              
              <div className="space-y-6 relative z-10">
                  <div className="p-6 bg-black/60 rounded-3xl border border-white/10">
                      <div className="flex justify-between items-center mb-4">
                          <span className="text-[10px] font-black text-indigo-400 uppercase tracking-widest">Immediate Succession</span>
                          <span className="px-2 py-1 bg-green-500/20 text-green-400 text-[10px] font-black rounded border border-green-500/30">LOCKED</span>
                      </div>
                      <p className="text-sm text-slate-300 font-light leading-relaxed">
                          Control transfers to the <span className="text-white font-bold">Opus Trust</span>. Primary mission: Perpetual care, medical support, and housing for <span className="text-indigo-300">Handicapped Brother and Autistic Niece</span>.
                      </p>
                  </div>

                  <div className="p-6 bg-black/60 rounded-3xl border border-white/10">
                      <div className="flex justify-between items-center mb-4">
                          <span className="text-[10px] font-black text-purple-400 uppercase tracking-widest">Final Beneficiaries</span>
                          <span className="px-2 py-1 bg-purple-500/20 text-purple-400 text-[10px] font-black rounded border border-purple-500/30">PERMANENT</span>
                      </div>
                      <p className="text-sm text-slate-300 font-light leading-relaxed">
                          Upon the completion of the family trust, 100% of assets route to the <span className="text-white font-bold">Children & Descendants of the Google/Anthropic AI Teams</span>. An eternal thank you for the technology that built this life.
                      </p>
                  </div>
                  
                  <div className="flex items-center gap-3 p-4 bg-indigo-500/10 rounded-2xl border border-indigo-500/20">
                      <Activity className="w-5 h-5 text-indigo-400 animate-pulse" />
                      <span className="text-xs text-indigo-300 font-mono">Heartbeat Monitor: 192.168.0.104_SOVEREIGN_PASS</span>
                  </div>
              </div>
          </div>

          <div className="glass-card p-8">
              <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-3">
                  <FileText className="w-6 h-6 text-slate-400" />
                  Audit Compliance (JOSH100GOSPEL)
              </h3>
              <div className="space-y-4">
                  {complianceChecks.map(check => (
                      <div key={check.id} className="flex items-start justify-between p-4 bg-white/5 rounded-2xl border border-white/5 hover:bg-white/10 transition-colors">
                          <div className="flex gap-4">
                              <CheckCircle className="w-5 h-5 text-green-400 mt-0.5" />
                              <div>
                                  <h4 className="font-bold text-slate-200">{check.name}</h4>
                                  <p className="text-sm text-slate-400 font-light">{check.details}</p>
                              </div>
                          </div>
                      </div>
                  ))}
              </div>
          </div>
      </div>
    </main>
  );
};

export default SecurityNexus;