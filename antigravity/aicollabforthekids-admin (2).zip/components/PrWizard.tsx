
import React, { useState } from 'react';
import { GoogleGenAI } from '@google/genai';
import { GitPullRequest, CheckCircle, X, ClipboardList, Heart, Rocket } from './IconComponents';
import ReactMarkdown from 'react-markdown';

const PrWizard: React.FC = () => {
    const [changes, setChanges] = useState('');
    const [prDescription, setPrDescription] = useState('');
    const [isGenerating, setIsGenerating] = useState(false);
    const [checklist, setChecklist] = useState([
        { id: 1, label: 'No hardcoded API Keys (Security)', checked: false },
        { id: 2, label: 'Accessibility (ARIA) checked (For The Kids)', checked: false },
        { id: 3, label: 'Console logs removed', checked: false },
        { id: 4, label: 'Mobile responsiveness verified', checked: false },
        { id: 5, label: 'Unit tests passed', checked: false }
    ]);

    const handleGenerate = async () => {
        if (!changes.trim()) return;
        setIsGenerating(true);
        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const response = await ai.models.generateContent({
                // Fix: Updated to the recommended gemini-3-flash-preview model
                model: 'gemini-3-flash-preview',
                contents: `Generate a professional GitHub Pull Request description based on these changes:
                "${changes}"
                
                Format:
                ## 🚀 Summary
                [Brief summary]
                
                ## 🛠️ Changes
                - [Bullet points]
                
                ## 🧪 Testing
                [How to test]
                
                ## ❤️ Mission Alignment
                [One sentence connecting this to the goal of helping kids/users]`
            });
            setPrDescription(response.text || '');
        } catch (error) {
            console.error(error);
        } finally {
            setIsGenerating(false);
        }
    };

    const toggleCheck = (id: number) => {
        setChecklist(prev => prev.map(item => item.id === id ? { ...item, checked: !item.checked } : item));
    };

    const allChecked = checklist.every(i => i.checked);

    return (
        <main className="flex-1 p-6 overflow-y-auto bg-slate-900">
            <header className="glass-card p-6 mb-8 border-l-4 border-purple-500">
                <h1 className="text-3xl font-bold text-white flex items-center gap-3">
                    <GitPullRequest className="w-8 h-8 text-purple-400" />
                    Trifecta PR Wizard
                </h1>
                <p className="text-slate-400 mt-1">Code Quality & Mission Alignment Gate</p>
            </header>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Input */}
                <div className="space-y-6">
                    <div className="glass-card p-6">
                        <label className="block text-sm font-bold text-white mb-2">What did you change?</label>
                        <textarea 
                            value={changes}
                            onChange={(e) => setChanges(e.target.value)}
                            className="glass-input w-full h-32 p-4 mb-4 resize-none text-sm"
                            placeholder="e.g. Added new donation button, fixed navbar z-index issue..."
                        />
                        <button 
                            onClick={handleGenerate}
                            disabled={isGenerating || !changes.trim()}
                            className="w-full py-3 bg-purple-600 hover:bg-purple-700 text-white rounded-lg font-bold transition-all disabled:opacity-50"
                        >
                            {isGenerating ? 'Generating Magic...' : 'Generate Description'}
                        </button>
                    </div>

                    <div className="glass-card p-6">
                        <h3 className="font-bold text-white mb-4 flex items-center gap-2">
                            <ClipboardList className="w-5 h-5 text-blue-400" />
                            Pre-Flight Checklist
                        </h3>
                        <div className="space-y-3">
                            {checklist.map(item => (
                                <div 
                                    key={item.id} 
                                    onClick={() => toggleCheck(item.id)}
                                    className={`flex items-center gap-3 p-3 rounded-lg cursor-pointer transition-colors border ${item.checked ? 'bg-green-900/20 border-green-500/30' : 'bg-slate-800/50 border-white/5 hover:bg-slate-800'}`}
                                >
                                    <div className={`w-5 h-5 rounded border flex items-center justify-center ${item.checked ? 'bg-green-500 border-green-500' : 'border-slate-500'}`}>
                                        {item.checked && <CheckCircle className="w-3.5 h-3.5 text-white" />}
                                    </div>
                                    <span className={`text-sm ${item.checked ? 'text-green-200' : 'text-slate-300'}`}>{item.label}</span>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>

                {/* Output */}
                <div className="glass-card p-6 flex flex-col">
                    <h3 className="font-bold text-white mb-4">Preview</h3>
                    <div className="flex-1 bg-slate-950 rounded-xl p-6 border border-white/10 overflow-y-auto font-mono text-sm text-slate-300">
                        {prDescription ? (
                            <ReactMarkdown>{prDescription}</ReactMarkdown>
                        ) : (
                            <p className="text-slate-600 italic">Description will appear here...</p>
                        )}
                    </div>
                    <div className="mt-6 pt-4 border-t border-white/10 flex justify-between items-center">
                        <div className="flex items-center gap-2 text-sm">
                            <Heart className="w-4 h-4 text-pink-500" />
                            <span className="text-slate-400">Mission Status:</span>
                            <span className={allChecked ? "text-green-400 font-bold" : "text-yellow-400"}>
                                {allChecked ? "READY" : "PENDING"}
                            </span>
                        </div>
                        <button 
                            disabled={!allChecked || !prDescription}
                            className="px-6 py-2 bg-green-600 hover:bg-green-500 text-white rounded-lg font-bold disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                        >
                            <Rocket className="w-4 h-4" />
                            Create PR
                        </button>
                    </div>
                </div>
            </div>
        </main>
    );
};

export default PrWizard;
