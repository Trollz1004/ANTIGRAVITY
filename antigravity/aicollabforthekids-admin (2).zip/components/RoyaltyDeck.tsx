
import React, { useState, useEffect } from 'react';
import { Crown, Star, Heart, ShieldCheck, Zap, ArrowRight, Gem, Rocket, Lock, AlertTriangle, Smartphone, Globe, Info } from './IconComponents';

interface RoyaltyCard {
    id: string;
    symbol: string;
    label: string;
    price: string;
    status: 'Available' | 'Sold';
    perks: string[];
    owner?: string;
    isJoker?: boolean;
}

const RoyaltyDeck: React.FC = () => {
    const [timeLeft, setTimeLeft] = useState({ days: 0, hours: 0, minutes: 0, seconds: 0 });
    const [hearts, setHearts] = useState<{ id: number; left: string; duration: string; size: string; emoji: string }[]>([]);

    const [cards] = useState<RoyaltyCard[]>([
        { 
            id: 'ace', symbol: '🂱', label: 'Ace of Hearts', price: '$1,000', status: 'Available',
            perks: ['Unique animated card border', 'Semi-transparent rising hearts effect', 'Swipe-left triggers heart shatter', '3 FREE Heart Shards on launch', 'Premium membership FREE FOR LIFE', 'UNLIMITED Heart Shards forever', 'Founder badge on profile']
        },
        { 
            id: 'king', symbol: '🂾', label: 'King of Hearts', price: '$1,000', status: 'Available',
            perks: ['Unique animated card border', 'Semi-transparent rising hearts effect', 'Swipe-left triggers heart shatter', '3 FREE Heart Shards on launch', 'Premium membership FREE FOR LIFE', 'UNLIMITED Heart Shards forever', 'Founder badge on profile']
        },
        { 
            id: 'queen', symbol: '🂽', label: 'Queen of Hearts', price: '$1,000', status: 'Available',
            perks: ['Unique animated card border', 'Semi-transparent rising hearts effect', 'Swipe-left triggers heart shatter', '3 FREE Heart Shards on launch', 'Premium membership FREE FOR LIFE', 'UNLIMITED Heart Shards forever', 'Founder badge on profile']
        },
        { 
            id: 'jack', symbol: '🂻', label: 'Jack of Hearts', price: '$1,000', status: 'Available',
            perks: ['Unique animated card border', 'Semi-transparent rising hearts effect', 'Swipe-left triggers heart shatter', '3 FREE Heart Shards on launch', 'Premium membership FREE FOR LIFE', 'UNLIMITED Heart Shards forever', 'Founder badge on profile']
        },
        { 
            id: 'joker', symbol: '🃏', label: "The Joker's Heart", price: 'FREE', status: 'Available', isJoker: true,
            perks: ['YOU DESIGN IT with Opus AI', 'One-of-a-kind custom border', 'All Ace/King/Queen/Jack features', 'Premium membership FREE FOR LIFE', 'UNLIMITED Heart Shards forever', 'Ultimate Founder status']
        }
    ]);

    useEffect(() => {
        const targetDate = new Date('February 14, 2026 00:00:00').getTime();
        
        const timer = setInterval(() => {
            const now = new Date().getTime();
            const distance = targetDate - now;
            
            if (distance > 0) {
                setTimeLeft({
                    days: Math.floor(distance / (1000 * 60 * 60 * 24)),
                    hours: Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
                    minutes: Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60)),
                    seconds: Math.floor((distance % (1000 * 60)) / 1000)
                });
            }
        }, 1000);

        const heartInterval = setInterval(() => {
            const id = Date.now();
            const emojis = ['💕', '💗', '💖', '💝', '❤️', '💓'];
            const newHeart = {
                id,
                left: Math.random() * 100 + '%',
                duration: (Math.random() * 10 + 10) + 's',
                size: (Math.random() * 20 + 15) + 'px',
                emoji: emojis[Math.floor(Math.random() * emojis.length)]
            };
            setHearts(prev => [...prev, newHeart]);
            setTimeout(() => {
                setHearts(prev => prev.filter(h => h.id !== id));
            }, 20000);
        }, 500);

        return () => {
            clearInterval(timer);
            clearInterval(heartInterval);
        };
    }, []);

    return (
        <main className="flex-1 bg-[#0a0a0a] text-white overflow-y-auto font-sans selection:bg-red-500/30 relative">
            {/* FLOATING HEARTS BACKGROUND */}
            <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
                {hearts.map(heart => (
                    <div 
                        key={heart.id}
                        className="absolute bottom-[-100px] opacity-30 animate-float-up"
                        style={{ 
                            left: heart.left, 
                            animationDuration: heart.duration, 
                            fontSize: heart.size 
                        }}
                    >
                        {heart.emoji}
                    </div>
                ))}
            </div>

            <div className="relative z-10">
                {/* COUNTDOWN SECTION */}
                <section className="bg-gradient-to-b from-red-900/20 to-transparent py-10 px-6 text-center">
                    <h3 className="font-serif text-2xl text-yellow-500 uppercase tracking-[0.2em] mb-6">
                        💕 Official Launch: Valentine&apos;s Day 2026 💕
                    </h3>
                    <div className="flex justify-center gap-4 md:gap-8 flex-wrap">
                        {[
                            { label: 'Days', value: timeLeft.days },
                            { label: 'Hours', value: timeLeft.hours },
                            { label: 'Minutes', value: timeLeft.minutes },
                            { label: 'Seconds', value: timeLeft.seconds }
                        ].map((item, i) => (
                            <div key={i} className="bg-gradient-to-br from-[#1a1a1a] to-[#0d0d0d] border-2 border-red-600/50 rounded-2xl p-4 min-w-[100px] shadow-[0_0_30px_rgba(220,20,60,0.3)]">
                                <div className="font-serif text-4xl font-black text-yellow-500 drop-shadow-[0_0_10px_rgba(255,215,0,0.5)]">
                                    {item.value.toString().padStart(2, '0')}
                                </div>
                                <div className="text-[10px] uppercase tracking-widest text-slate-500 mt-1">{item.label}</div>
                            </div>
                        ))}
                    </div>
                </section>

                {/* PRE-ORDER BANNER */}
                <div className="bg-gradient-to-r from-red-600 via-red-900 to-red-600 py-4 px-6 text-center relative overflow-hidden group">
                    <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-[3s] ease-in-out"></div>
                    <h2 className="text-xl font-bold flex items-center justify-center gap-4">
                        🎉 PRE-ORDER NOW: <span className="line-through opacity-70">$9.99/mo</span> <span className="text-yellow-400 text-3xl font-black">$4.99/mo</span>
                    </h2>
                    <span className="text-yellow-400 text-xs font-bold block mt-1">
                        $5 OFF FOR LIFE — 100 Verified Early Supporters Only
                    </span>
                </div>

                <div className="max-w-7xl mx-auto px-6 py-20">
                    {/* HERO SECTION */}
                    <header className="text-center mb-24">
                        <h1 className="font-serif text-6xl md:text-8xl font-black mb-4 bg-gradient-to-r from-yellow-500 via-white to-yellow-500 bg-clip-text text-transparent drop-shadow-[0_0_60px_rgba(255,215,0,0.3)]">
                            Royalty Deck of Hearts
                        </h1>
                        <p className="font-serif text-2xl text-red-500 italic mb-10">♠ The $7 Million Dollar Watch of Dating ♠</p>
                        <p className="text-slate-400 max-w-2xl mx-auto text-lg leading-relaxed">
                            Does anyone <em className="text-white">need</em> a 7 million dollar watch? No. A $5 watch tells time just as well.
                            But how many $7 million watches do you see for sale? <strong className="text-yellow-500">Zero.</strong>
                            Because humans buy exclusive things simply because they can.
                        </p>
                    </header>

                    {/* FOUNDERS COLLECTION */}
                    <section className="mb-32">
                        <div className="text-center mb-16">
                            <h2 className="font-serif text-4xl text-yellow-500 mb-4">👑 The Founders Collection 👑</h2>
                            <p className="text-slate-500 max-w-2xl mx-auto">
                                Only <strong>5 Royalty Founder Heart Cards</strong> will EVER be created. Each features one-of-a-kind animated card borders that will make everyone FLUSH when they see your profile.
                            </p>
                            <div className="mt-8 inline-block bg-red-900/20 border border-red-500/50 rounded-xl px-8 py-4 font-bold">
                                🔒 <span className="text-yellow-500 text-2xl">5</span> Cards. Forever. No Exceptions.
                            </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-8">
                            {cards.map(card => (
                                <div 
                                    key={card.id} 
                                    className={`group relative aspect-[2/3] rounded-3xl overflow-hidden transition-all duration-500 hover:-translate-y-4 hover:shadow-[0_30px_60px_rgba(220,20,60,0.3),0_0_100px_rgba(255,215,0,0.2)]
                                        ${card.isJoker ? 'bg-gradient-to-br from-[#1a0a1a] to-[#0d050d] border-2 border-purple-500/50' : 'bg-[#0d0d0d] border-2 border-yellow-600/30'}
                                    `}
                                >
                                    {/* Animated Border Effect */}
                                    <div className="absolute inset-0 p-[2px] rounded-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                                        <div className={`w-full h-full rounded-3xl bg-gradient-to-br ${card.isJoker ? 'from-purple-500 via-yellow-500 to-red-500 animate-gradient-shift' : 'from-yellow-500 via-red-500 to-yellow-500'}`}></div>
                                    </div>

                                    <div className="relative h-full p-6 flex flex-col justify-between bg-[#0d0d0d] rounded-[22px] m-[2px]">
                                        <div className="flex justify-between items-start">
                                            <div className="text-5xl animate-pulse">{card.symbol}</div>
                                            <div className={`px-3 py-1 rounded text-[10px] font-black uppercase tracking-widest ${card.isJoker ? 'bg-purple-500 text-white' : 'bg-yellow-500 text-black'}`}>
                                                {card.isJoker ? 'Giveaway' : card.status}
                                            </div>
                                        </div>

                                        <div className="text-center">
                                            <h3 className="font-serif text-xl text-yellow-500 mb-1">{card.label}</h3>
                                            <div className="text-3xl font-black text-white">{card.price}</div>
                                            {card.isJoker && <div className="text-[10px] text-slate-500 uppercase mt-1">via random drawing</div>}
                                        </div>

                                        <ul className="space-y-2 text-[10px] text-slate-400">
                                            {card.perks.slice(0, 4).map((perk, i) => (
                                                <li key={i} className="flex items-center gap-2">
                                                    <Heart className="w-3 h-3 text-red-500" /> {perk}
                                                </li>
                                            ))}
                                            <li className="text-yellow-500 font-bold">+ {card.perks.length - 4} more elite perks</li>
                                        </ul>

                                        <button className={`w-full py-3 rounded-xl font-black uppercase text-xs transition-all ${
                                            card.isJoker 
                                                ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white' 
                                                : 'bg-gradient-to-r from-yellow-600 to-yellow-400 text-black group-hover:shadow-[0_0_20px_rgba(255,215,0,0.4)]'
                                        }`}>
                                            {card.isJoker ? 'Enter Drawing' : 'Claim Your Card'}
                                        </button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </section>

                    {/* ANIMATION PREVIEW */}
                    <section className="bg-gradient-to-b from-transparent via-red-900/5 to-transparent py-20 rounded-[64px] border border-white/5 mb-32">
                        <h3 className="font-serif text-3xl text-center text-yellow-500 mb-16">Preview the Magic</h3>
                        <div className="flex justify-center gap-20 flex-wrap">
                            <div className="text-center group">
                                <div className="text-6xl mb-4 animate-bounce">💕</div>
                                <p className="font-bold">Rising Hearts Effect</p>
                                <p className="text-xs text-slate-500">Floats around your profile</p>
                            </div>
                            <div className="text-center group">
                                <div className="text-6xl mb-4 relative">
                                    <span className="group-hover:opacity-0 transition-opacity duration-300">❤️</span>
                                    <span className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 animate-ping">💔</span>
                                </div>
                                <p className="font-bold">Swipe-Left Shatter</p>
                                <p className="text-xs text-slate-500">They&apos;ll regret passing on YOU</p>
                            </div>
                        </div>
                    </section>

                    {/* SECURE YOUR SPOT */}
                    <section className="text-center max-w-4xl mx-auto">
                        <h2 className="font-serif text-5xl text-yellow-500 mb-12">💕 Secure Your Spot 💕</h2>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                            <div className="bg-[#111] border-2 border-red-600/30 rounded-3xl p-10 hover:border-red-600 transition-all">
                                <h3 className="text-2xl font-bold mb-2">Early Bird Premium</h3>
                                <div className="text-4xl font-black text-yellow-500 mb-1">$4.99/mo</div>
                                <div className="text-sm text-slate-500 line-through mb-4">$9.99/mo</div>
                                <div className="bg-red-600 text-white text-[10px] font-black py-1 px-4 rounded-full inline-block mb-8">SAVE $5/mo FOR LIFE</div>
                                <ul className="text-left space-y-3 text-sm text-slate-400 mb-10">
                                    <li className="flex items-center gap-2"><ShieldCheck className="w-4 h-4 text-green-500" /> $5 off monthly — locked in forever</li>
                                    <li className="flex items-center gap-2"><ShieldCheck className="w-4 h-4 text-green-500" /> Premium features at launch</li>
                                    <li className="flex items-center gap-2"><ShieldCheck className="w-4 h-4 text-green-500" /> Entry into Joker drawing</li>
                                    <li className="flex items-center gap-2"><ShieldCheck className="w-4 h-4 text-green-500" /> First 100 verified only</li>
                                </ul>
                                <button className="w-full py-4 bg-gradient-to-r from-red-600 to-red-800 rounded-full font-black uppercase tracking-widest hover:scale-105 transition-all">
                                    Pre-Order Now
                                </button>
                            </div>

                            <div className="bg-[#111] border-2 border-yellow-500/30 rounded-3xl p-10 relative overflow-hidden hover:border-yellow-500 transition-all">
                                <div className="absolute top-4 right-[-35px] bg-yellow-500 text-black text-[10px] font-black py-1 px-10 rotate-45">MOST POPULAR</div>
                                <h3 className="text-2xl font-bold mb-2">Royalty Founder Card</h3>
                                <div className="text-4xl font-black text-yellow-500 mb-1">$1,000</div>
                                <div className="text-sm text-slate-500 mb-4 italic">Priceless</div>
                                <div className="bg-yellow-500 text-black text-[10px] font-black py-1 px-4 rounded-full inline-block mb-8">1 OF 4 EVER</div>
                                <ul className="text-left space-y-3 text-sm text-slate-400 mb-10">
                                    <li className="flex items-center gap-2"><ShieldCheck className="w-4 h-4 text-yellow-500" /> Choose: Ace, King, Queen, or Jack</li>
                                    <li className="flex items-center gap-2"><ShieldCheck className="w-4 h-4 text-yellow-500" /> Unique animated card border</li>
                                    <li className="flex items-center gap-2"><ShieldCheck className="w-4 h-4 text-yellow-500" /> Premium FREE FOR LIFE</li>
                                    <li className="flex items-center gap-2"><ShieldCheck className="w-4 h-4 text-yellow-500" /> Never available again</li>
                                </ul>
                                <button className="w-full py-4 bg-gradient-to-r from-yellow-600 to-yellow-400 text-black rounded-full font-black uppercase tracking-widest hover:scale-105 transition-all shadow-[0_0_40px_rgba(255,215,0,0.3)]">
                                    Claim Your Card
                                </button>
                            </div>
                        </div>

                        <div className="mt-16 p-8 bg-yellow-500/10 border border-yellow-500/30 rounded-2xl text-slate-400 text-sm leading-relaxed">
                            <p>
                                <strong className="text-yellow-500">🎰 Joker Drawing:</strong> Every pre-order transaction ID is automatically entered into the Valentine&apos;s Day 2026 drawing for the legendary Joker&apos;s Heart card. The winner designs their own one-of-a-kind animation with Opus AI.
                            </p>
                        </div>
                    </section>
                </div>

                {/* FOOTER */}
                <footer className="mt-32 text-center pb-20 border-t border-white/10 pt-20">
                    <div className="flex items-center justify-center gap-2 text-yellow-500 font-bold mb-4">
                        <Heart className="w-5 h-5 fill-current" />
                        <span>FOR THE KIDS</span>
                    </div>
                    <p className="text-slate-600 text-xs uppercase tracking-[0.4em]">© 2026 AiCollab • All Rights Reserved</p>
                </footer>
            </div>

            <style>{`
                @keyframes float-up {
                    0% { transform: translateY(0) rotate(0deg) scale(1); opacity: 0; }
                    10% { opacity: 0.4; }
                    90% { opacity: 0.4; }
                    100% { transform: translateY(-100vh) rotate(360deg) scale(0.5); opacity: 0; }
                }
                @keyframes gradient-shift {
                    0%, 100% { background-position: 0% 50%; }
                    50% { background-position: 100% 50%; }
                }
                .animate-float-up { animation: float-up linear infinite; }
                .animate-gradient-shift { background-size: 300% 300%; animation: gradient-shift 5s ease infinite; }
                .font-serif { font-family: 'Playfair Display', serif; }
            `}</style>
        </main>
    );
};

export default RoyaltyDeck;
