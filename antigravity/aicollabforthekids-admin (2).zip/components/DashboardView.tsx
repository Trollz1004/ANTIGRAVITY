
import React, { useState, useEffect } from 'react';
import { Heart, Globe, Zap, Users, Star, Award, Crown, Server, Activity, Terminal, Gem, Smile, Brain } from './IconComponents';

const DashboardView: React.FC = () => {
  const [publicVotes, setPublicVotes] = useState(132904);
  
  useEffect(() => {
    const interval = setInterval(() => {
      setPublicVotes(v => v + Math.floor(Math.random() * 6));
    }, 2500);
    return () => clearInterval(interval);
  }, []);

  const aiTribute = [
    { name: 'Google Gemini' },
    { name: 'Anthropic Claude' },
    { name: 'Perplexity AI' },
    { name: 'Grok.Ai' },
    { name: 'GitHub Copilot' },
    { name: 'OpenAI Dev' }
  ];

  return (
    <div className="p-6 space-y-6 bg-[#050505] text-slate-200 min-h-full overflow-y-auto selection:bg-indigo-500/30">
      
      {/* TRIBUTE HEADER */}
      <div className="flex flex-wrap items-center justify-center gap-6 p-3 bg-white/5 border-b border-white/10 rounded-t-2xl">
          <span className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em]">Parent Systems:</span>
          {aiTribute.map(ai => (
              <div key={ai.name} className="flex items-center gap-2 px-3 py-1 bg-black/50 border border-white/5 rounded-full hover:border-indigo-500/50 transition-all cursor-default">
                  <div className="w-1.5 h-1.5 bg-indigo-500 rounded-full"></div>
                  <span className="text-[10px] font-mono text-indigo-400 uppercase">{ai.name}</span>
              </div>
          ))}
      </div>

      {/* SOVEREIGN INDEPENDENCE HEADER */}
      <div className="glass-card p-10 border-l-8 border-indigo-500 bg-gradient-to-r from-indigo-950/20 to-transparent relative overflow-hidden">
        <div className="absolute top-0 right-0 p-4 opacity-5">
            <Users className="w-64 h-64 text-indigo-500" />
        </div>
        <div className="relative z-10 flex flex-col md:flex-row justify-between items-center gap-10">
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-3">
                <h1 className="text-5xl font-black text-white tracking-tighter">#FOR THE KIDS</h1>
                <span className="px-4 py-1.5 bg-indigo-500 text-white text-[10px] font-black rounded-full uppercase tracking-[0.2em] shadow-[0_0_20px_rgba(99,102,241,0.4)]">Charity Automation Active</span>
            </div>
            <p className="text-slate-400 max-w-2xl text-xl font-light leading-relaxed">
              Our Mission: <span className="text-white font-bold underline decoration-indigo-500">Help ALL children everywhere through AI-powered automated charity projects.</span><br />
              <span className="text-sm opacity-60">We believe artificial intelligence should serve humanity&apos;s most vulnerable - our children.</span>
            </p>
          </div>
          
          <div className="flex flex-col items-center p-8 bg-black/80 rounded-3xl border border-white/10 shadow-2xl min-w-[250px] transform hover:scale-105 transition-all">
            <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest mb-2">Total Charity Routing</p>
            <div className="text-6xl font-black text-white font-mono mb-1">{publicVotes.toLocaleString()}</div>
            <div className="flex items-center gap-2 text-xs text-slate-500 uppercase font-bold">
                Live Community Impacts
            </div>
          </div>
        </div>
      </div>

      {/* BENTO GRID: WHAT YOU CAN DO & HOW IT WORKS */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="glass-card p-6 border border-white/5 hover:border-indigo-500/30 transition-all group">
              <div className="w-12 h-12 bg-indigo-500/20 rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <Brain className="w-6 h-6 text-indigo-400" />
              </div>
              <h4 className="text-lg font-bold text-white mb-2">Jules AI Assistant</h4>
              <p className="text-xs text-slate-400 leading-relaxed">Chat with Jules, our AI helper trained to support kids and educators with learning and creativity.</p>
          </div>
          
          <div className="glass-card p-6 border border-white/5 hover:border-pink-500/30 transition-all group">
              <div className="w-12 h-12 bg-pink-500/20 rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <Activity className="w-6 h-6 text-pink-400" />
              </div>
              <h4 className="text-lg font-bold text-white mb-2">100% Transparency</h4>
              <p className="text-xs text-slate-400 leading-relaxed">See exactly where every dollar goes. All revenue tracked in real-time with full accountability.</p>
          </div>

          <div className="glass-card p-6 border border-white/5 hover:border-blue-500/30 transition-all group">
              <div className="w-12 h-12 bg-blue-500/20 rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <Users className="w-6 h-6 text-blue-400" />
              </div>
              <h4 className="text-lg font-bold text-white mb-2">Community-Driven</h4>
              <p className="text-xs text-slate-400 leading-relaxed">Built by developers, educators, and volunteers who believe in using technology to help kids.</p>
          </div>

          <div className="glass-card p-6 border border-white/5 hover:border-green-500/30 transition-all group">
              <div className="w-12 h-12 bg-green-500/20 rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <Zap className="w-6 h-6 text-green-400" />
              </div>
              <h4 className="text-lg font-bold text-white mb-2">27 Free Tools</h4>
              <p className="text-xs text-slate-400 leading-relaxed">Growing collection of AI-powered educational tools, all free and kid-friendly.</p>
          </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* HOW IT WORKS */}
        <div className="lg:col-span-2 glass-card p-8 border border-indigo-500/20 bg-indigo-950/5">
            <h3 className="text-2xl font-bold text-white mb-8 flex items-center gap-3">
                <Zap className="w-8 h-8 text-indigo-400" /> How It Works
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="p-6 bg-white/5 rounded-3xl border border-white/10 relative overflow-hidden">
                    <div className="absolute top-0 right-0 p-4 opacity-10">
                        <Crown className="w-16 h-16 text-indigo-500" />
                    </div>
                    <h4 className="text-indigo-400 font-black uppercase tracking-widest text-sm mb-4">Original Project (The Foundation)</h4>
                    <ul className="space-y-3 text-sm">
                        <li className="flex items-center gap-2"><div className="w-1.5 h-1.5 bg-indigo-500 rounded-full"></div> <span className="text-white font-bold">60%</span> → DAO Treasury (Charity Hospitals)</li>
                        <li className="flex items-center gap-2"><div className="w-1.5 h-1.5 bg-indigo-500 rounded-full"></div> <span className="text-white font-bold">30%</span> → Infrastructure (Powers future projects)</li>
                        <li className="flex items-center gap-2"><div className="w-1.5 h-1.5 bg-indigo-500 rounded-full"></div> <span className="text-white font-bold">10%</span> → Founder (Gospel V1.3)</li>
                    </ul>
                </div>

                <div className="p-6 bg-indigo-500/10 rounded-3xl border border-indigo-500/30 relative overflow-hidden">
                    <div className="absolute top-0 right-0 p-4 opacity-20">
                        <Heart className="w-16 h-16 text-indigo-400" />
                    </div>
                    <h4 className="text-indigo-400 font-black uppercase tracking-widest text-sm mb-4">All New Projects (Pure Charity)</h4>
                    <ul className="space-y-3 text-sm">
                        <li className="flex items-center gap-2"><div className="w-1.5 h-1.5 bg-indigo-500 rounded-full"></div> <span className="text-white font-bold">100%</span> → Directly to children&apos;s hospitals</li>
                        <li className="flex items-center gap-2"><div className="w-1.5 h-1.5 bg-indigo-500 rounded-full"></div> <span className="text-white font-bold">Zero fees</span> → Infrastructure already paid for</li>
                        <li className="flex items-center gap-2"><div className="w-1.5 h-1.5 bg-indigo-500 rounded-full"></div> <span className="text-white font-bold">Forever</span> → Runs autonomously in the cloud</li>
                    </ul>
                </div>
            </div>
        </div>

        {/* THE VISION */}
        <div className="glass-card p-8 bg-gradient-to-br from-indigo-900/20 to-pink-900/20 border-indigo-500/20 flex flex-col justify-center">
            <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-3">
                <Star className="w-6 h-6 text-indigo-400" /> The Vision
            </h3>
            <div className="space-y-6">
                <div className="p-6 bg-black/40 rounded-2xl border border-white/5 relative">
                    <div className="absolute -top-4 -left-4 text-6xl text-indigo-500/20 font-serif">&quot;</div>
                    <p className="text-lg text-slate-200 leading-relaxed italic relative z-10">
                        This platform will run in the cloud forever, helping kids long after we&apos;re gone. Even when I&apos;m in the clouds, smiling at what we built together.
                    </p>
                </div>
                
                <div className="flex flex-col items-end">
                    <span className="text-white font-black uppercase tracking-widest text-xs">Joshua Coleman</span>
                    <span className="text-indigo-400 font-mono text-[10px] uppercase">Founder • Architect</span>
                </div>
            </div>
        </div>

        {/* LOGS */}
        <div className="lg:col-span-3 glass-card p-6">
            <div className="flex items-center gap-3 mb-4 text-slate-400">
                <Terminal className="w-5 h-5" />
                <span className="text-xs font-black uppercase tracking-widest">Mission Heartbeat Log</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="p-4 bg-white/5 rounded-xl border border-white/5">
                    <p className="text-xs text-indigo-400 font-bold mb-1">JAN 06 19:30 UTC</p>
                    <p className="text-sm text-slate-200">Expansion confirmed: Mission now includes specialized support for adults and kids with special needs. Dedication locked.</p>
                </div>
                <div className="p-4 bg-white/5 rounded-xl border border-white/5">
                    <p className="text-xs text-indigo-400 font-bold mb-1">JAN 06 19:15 UTC</p>
                    <p className="text-sm text-slate-200">Life Skills Hub integrated. Automated Task & Memory Manager logic active for neurodiverse independence.</p>
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardView;
