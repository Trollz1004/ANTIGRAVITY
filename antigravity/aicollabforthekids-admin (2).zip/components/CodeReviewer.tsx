
import React, { useState } from 'react';
import { GoogleGenAI } from '@google/genai';
import { Code, ShieldCheck, Zap, CheckCircle, AlertTriangle } from './IconComponents';
import ReactMarkdown from 'react-markdown';

const CodeReviewer: React.FC = () => {
    const [code, setCode] = useState('');
    const [review, setReview] = useState('');
    const [isReviewing, setIsReviewing] = useState(false);

    const handleReview = async () => {
        if (!code.trim()) return;
        setIsReviewing(true);
        setReview('');
        
        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const response = await ai.models.generateContent({
                model: 'gemini-3-flash-preview',
                contents: `Review the following code for:
                1. Security Vulnerabilities
                2. Performance Issues
                3. Code Clarity / Best Practices
                4. "For The Kids" Safety Check (Ensure no harmful logic)
                
                Code:
                \`\`\`
                ${code}
                \`\`\`
                
                Provide the output in Markdown with clear headers and a final score (0-100).`,
                config: { thinkingConfig: { thinkingBudget: 2048 } }
            });
            setReview(response.text || "Review failed.");
        } catch (error) {
            console.error(error);
            setReview("Error connecting to reviewer.");
        } finally {
            setIsReviewing(false);
        }
    };

    return (
        <main className="flex-1 p-6 overflow-y-auto bg-[#0d1117]">
            <header className="glass-card p-6 mb-8 border-l-4 border-blue-500 bg-slate-900/50">
                <h1 className="text-3xl font-bold text-white flex items-center gap-3">
                    <Code className="w-8 h-8 text-blue-400" />
                    Gemini Code Reviewer
                </h1>
                <p className="text-slate-400 mt-1">Automated Security & Performance Audit</p>
            </header>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 h-[calc(100vh-200px)]">
                {/* Editor */}
                <div className="flex flex-col h-full">
                    <div className="bg-slate-800/80 p-3 rounded-t-xl border border-white/10 flex justify-between items-center">
                        <span className="text-xs font-mono text-slate-400">Input Code</span>
                        <button 
                            onClick={handleReview}
                            disabled={isReviewing || !code.trim()}
                            className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded text-xs font-bold transition-colors disabled:opacity-50"
                        >
                            {isReviewing ? 'Analyzing...' : 'Run Review'}
                        </button>
                    </div>
                    <textarea 
                        value={code}
                        onChange={(e) => setCode(e.target.value)}
                        className="flex-1 bg-[#0d1117] border border-white/10 border-t-0 p-4 font-mono text-sm text-slate-300 focus:outline-none resize-none rounded-b-xl leading-relaxed"
                        placeholder="// Paste your code here..."
                        spellCheck={false}
                    />
                </div>

                {/* Output */}
                <div className="flex flex-col h-full">
                    <div className="bg-slate-800/80 p-3 rounded-t-xl border border-white/10 flex gap-4">
                        <div className="flex items-center gap-2">
                            <ShieldCheck className="w-4 h-4 text-green-400" />
                            <span className="text-xs text-slate-400">Security</span>
                        </div>
                        <div className="flex items-center gap-2">
                            <Zap className="w-4 h-4 text-yellow-400" />
                            <span className="text-xs text-slate-400">Performance</span>
                        </div>
                    </div>
                    <div className="flex-1 bg-[#0d1117] border border-white/10 border-t-0 p-6 overflow-y-auto rounded-b-xl">
                        {review ? (
                            <div className="prose prose-invert prose-sm max-w-none font-sans">
                                <ReactMarkdown>{review}</ReactMarkdown>
                            </div>
                        ) : (
                            <div className="h-full flex flex-col items-center justify-center text-slate-600">
                                <div className="w-16 h-16 mb-4 rounded-full border-4 border-slate-800 flex items-center justify-center">
                                    <Code className="w-8 h-8 opacity-50" />
                                </div>
                                <p>Ready to review.</p>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </main>
    );
};

export default CodeReviewer;
