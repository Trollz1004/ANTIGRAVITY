
import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI } from '@google/genai';
import { Compass, Globe, ArrowLeft, ArrowRight, RotateCcw, Plus, X, Search, Sparkles, Layout, Download, ClipboardList, Zap, MessageSquare, Activity } from './IconComponents';
import ReactMarkdown from 'react-markdown';

interface Tab {
  id: string;
  title: string;
  url: string;
  content?: string; 
  history: string[];
  historyIndex: number;
  mode: 'ai' | 'live';
}

interface AssistantMessage {
    role: 'user' | 'model';
    content: string;
    isSummarizing?: boolean;
}

const CometBrowser: React.FC = () => {
  // --- Browser State ---
  const [tabs, setTabs] = useState<Tab[]>([
    { id: '1', title: 'New Tab', url: '', history: [''], historyIndex: 0, mode: 'ai' }
  ]);
  const [activeTabId, setActiveTabId] = useState('1');
  const [addressBarInput, setAddressBarInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  
  // --- Assistant State ---
  const [assistantMessages, setAssistantMessages] = useState<AssistantMessage[]>([
      { role: 'model', content: "Comet Intelligence Node Online. I am ready to research specialized tools, medical breakthroughs, or project data for the kids." }
  ]);
  const [assistantInput, setAssistantInput] = useState('');
  const [isAssistantOpen, setIsAssistantOpen] = useState(true);
  const [isAssistantThinking, setIsAssistantThinking] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const activeTab = tabs.find(t => t.id === activeTabId) || tabs[0];

  useEffect(() => {
      setAddressBarInput(activeTab.url);
  }, [activeTabId, activeTab.url]);

  useEffect(() => {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [assistantMessages]);

  // --- Browser Actions ---

  const createTab = () => {
    const newId = Date.now().toString();
    const newTab: Tab = { id: newId, title: 'New Tab', url: '', history: [''], historyIndex: 0, mode: 'ai' };
    setTabs(prev => [...prev, newTab]);
    setActiveTabId(newId);
  };

  const closeTab = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (tabs.length === 1) {
        setTabs([{ id: Date.now().toString(), title: 'New Tab', url: '', history: [''], historyIndex: 0, mode: 'ai' }]);
        return;
    }
    const newTabs = tabs.filter(t => t.id !== id);
    setTabs(newTabs);
    if (activeTabId === id) {
        setActiveTabId(newTabs[newTabs.length - 1].id);
    }
  };

  const updateTab = (id: string, updates: Partial<Tab>) => {
      setTabs(prev => prev.map(t => t.id === id ? { ...t, ...updates } : t));
  };

  const handleNavigate = async (urlOrQuery: string) => {
      if (!urlOrQuery.trim()) return;
      
      setIsLoading(true);
      let targetUrl = urlOrQuery;
      let isSearch = !urlOrQuery.includes('.') || urlOrQuery.includes(' ');
      
      updateTab(activeTabId, { url: targetUrl, title: isSearch ? `Search: ${targetUrl}` : targetUrl });

      if (activeTab.mode === 'ai' || isSearch) {
          try {
              const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
              const response = await ai.models.generateContent({
                  model: 'gemini-3-flash-preview',
                  contents: `Research and synthesize a high-fidelity report on: "${targetUrl}". 
                  Focus on technical feasibility, cost impact, and alignment with humanitarian goals.
                  Use professional Markdown formatting with clear sections.`,
                  config: {
                      tools: [{ googleSearch: {} }],
                      thinkingConfig: { thinkingBudget: 2048 }
                  }
              });
              
              const content = response.text || "No intelligence retrieved.";
              updateTab(activeTabId, { content, mode: 'ai', title: isSearch ? targetUrl : 'Intelligence Report' });
              
              setAssistantMessages(prev => [...prev, { 
                  role: 'model', 
                  content: `Research complete for **${targetUrl}**. I've synthesized a technical overview in the main viewer. How should we process this data?` 
              }]);

          } catch (error) {
              console.error("Browser Error", error);
              updateTab(activeTabId, { content: "## Neural Link Severed\nUnable to establish search grounding for this node." });
          }
      } else {
           if (!targetUrl.startsWith('http')) targetUrl = 'https://' + targetUrl;
           updateTab(activeTabId, { url: targetUrl, mode: 'live' });
      }
      setIsLoading(false);
  };

  const handleAssistantSend = async (customPrompt?: string) => {
      const input = customPrompt || assistantInput;
      if (!input.trim() || isAssistantThinking) return;
      
      if (!customPrompt) setAssistantInput('');
      setAssistantMessages(prev => [...prev, { role: 'user', content: input }]);
      setIsAssistantThinking(true);
      
      try {
          const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
          const context = activeTab.mode === 'ai' 
              ? `CURRENT RESEARCH CONTEXT:\n${activeTab.content?.substring(0, 4000)}` 
              : `USER IS BROWSING LIVE URL: ${activeTab.url}`;
          
          const response = await ai.models.generateContent({
              model: 'gemini-3-flash-preview',
              contents: `System: You are the Comet Assistant. Your goal is to assist the Architect (Joshua) in refining research for "For The Kids". 
              Contextual Data: ${context}
              User Instruction: ${input}`,
              config: { thinkingConfig: { thinkingBudget: 1024 } }
          });
          
          setAssistantMessages(prev => [...prev, { role: 'model', content: response.text || "Reasoning failure." }]);
      } catch (error) {
          setAssistantMessages(prev => [...prev, { role: 'model', content: "Intelligence Hub connection error." }]);
      } finally {
          setIsAssistantThinking(false);
      }
  };

  const handleSaveToMissionLog = () => {
      if (!activeTab.content) return;
      // In a real app, this would trigger an API call to save to a database
      alert("Intelligence captured and synchronized to Sovereign Succession Ledger.");
  };

  return (
    <div className="flex flex-col h-full bg-[#020617] selection:bg-indigo-500/30">
        {/* Browser Chrome */}
        <div className="h-12 bg-slate-900 border-b border-white/5 flex items-center px-3 gap-3 select-none backdrop-blur-xl">
            <div className="flex items-center gap-2 mr-4">
                <div className="flex gap-1.5">
                    <div className="w-2.5 h-2.5 rounded-full bg-rose-500/30 border border-rose-500/50"></div>
                    <div className="w-2.5 h-2.5 rounded-full bg-amber-500/30 border border-amber-500/50"></div>
                    <div className="w-2.5 h-2.5 rounded-full bg-emerald-500/30 border border-emerald-500/50"></div>
                </div>
            </div>

            <div className="flex-1 flex items-center gap-1 overflow-x-auto no-scrollbar">
                {tabs.map(tab => (
                    <div 
                        key={tab.id}
                        onClick={() => setActiveTabId(tab.id)}
                        className={`
                            group flex items-center gap-2 px-4 py-1.5 rounded-xl text-xs max-w-[220px] cursor-pointer transition-all border
                            ${activeTabId === tab.id 
                                ? 'bg-indigo-600/10 text-indigo-400 border-indigo-500/30 shadow-[0_0_20px_rgba(99,102,241,0.1)]' 
                                : 'bg-transparent text-slate-500 border-transparent hover:bg-white/5 hover:text-slate-300'}
                        `}
                    >
                        {tab.mode === 'ai' ? <Sparkles className="w-3.5 h-3.5" /> : <Globe className="w-3.5 h-3.5" />}
                        <span className="truncate flex-1 font-bold uppercase tracking-tighter">{tab.title}</span>
                        <button 
                            onClick={(e) => closeTab(tab.id, e)}
                            className="opacity-0 group-hover:opacity-100 hover:bg-white/10 rounded-full p-0.5"
                        >
                            <X className="w-3.5 h-3.5" />
                        </button>
                    </div>
                ))}
                <button onClick={createTab} className="p-2 hover:bg-white/5 rounded-full text-slate-500 transition-colors">
                    <Plus className="w-4 h-4" />
                </button>
            </div>
        </div>

        {/* Omnibox */}
        <div className="h-14 bg-slate-950 border-b border-white/5 flex items-center px-6 gap-4">
            <div className="flex gap-2">
                <button className="p-2 hover:bg-white/5 rounded-lg text-slate-400"><ArrowLeft className="w-4 h-4" /></button>
                <button className="p-2 hover:bg-white/5 rounded-lg text-slate-400"><ArrowRight className="w-4 h-4" /></button>
                <button onClick={() => handleNavigate(activeTab.url)} className="p-2 hover:bg-white/5 rounded-lg text-slate-400"><RotateCcw className="w-4 h-4" /></button>
            </div>

            <div className="flex-1 relative group">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                    {activeTab.mode === 'ai' ? <Search className="w-4 h-4 text-indigo-400" /> : <Globe className="w-4 h-4 text-slate-500" />}
                </div>
                <input 
                    type="text" 
                    value={addressBarInput}
                    onChange={(e) => setAddressBarInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleNavigate(addressBarInput)}
                    className="w-full bg-slate-900 border border-white/10 rounded-2xl py-2.5 pl-11 pr-4 text-sm text-slate-200 focus:outline-none focus:border-indigo-500/50 focus:ring-1 focus:ring-indigo-500/20 transition-all"
                    placeholder="Ask Comet to research anything..."
                />
            </div>

            <div className="flex gap-3">
                 <button 
                    onClick={() => updateTab(activeTabId, { mode: activeTab.mode === 'ai' ? 'live' : 'ai' })}
                    className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-widest border transition-all ${activeTab.mode === 'ai' ? 'bg-indigo-600/20 text-indigo-400 border-indigo-500/40' : 'bg-slate-800 text-slate-400 border-white/10'}`}
                 >
                     {activeTab.mode === 'ai' ? 'AI MODE' : 'LIVE WEB'}
                 </button>
                 <button 
                    onClick={() => setIsAssistantOpen(!isAssistantOpen)}
                    className={`p-2.5 rounded-xl transition-all ${isAssistantOpen ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-900/40' : 'bg-white/5 text-slate-400 hover:text-white'}`}
                 >
                     <MessageSquare className="w-5 h-5" />
                 </button>
            </div>
        </div>

        {/* Viewport */}
        <div className="flex-1 flex overflow-hidden relative">
            <div className={`flex-1 bg-[#050505] overflow-y-auto relative ${isAssistantOpen ? 'mr-[380px]' : ''} transition-all duration-500 custom-scrollbar`}>
                {isLoading && (
                    <div className="absolute inset-0 flex items-center justify-center bg-slate-950/90 z-20 backdrop-blur-sm">
                        <div className="flex flex-col items-center gap-6">
                            <div className="relative">
                                <div className="w-12 h-12 rounded-full border-2 border-indigo-500/20 border-t-indigo-500 animate-spin"></div>
                                <Sparkles className="absolute inset-0 m-auto w-5 h-5 text-indigo-400 animate-pulse" />
                            </div>
                            <p className="text-indigo-400 font-mono text-xs tracking-[0.3em] uppercase animate-pulse">Comet Reasoning...</p>
                        </div>
                    </div>
                )}
                
                {activeTab.mode === 'ai' ? (
                    <div className="max-w-4xl mx-auto p-12 min-h-full">
                        {activeTab.content ? (
                             <div className="prose prose-invert prose-indigo max-w-none animate-in fade-in slide-in-from-bottom-4 duration-1000">
                                <ReactMarkdown>{activeTab.content}</ReactMarkdown>
                                
                                <div className="mt-12 pt-8 border-t border-white/5 flex justify-between items-center">
                                    <div className="flex items-center gap-2 text-xs font-mono text-slate-500">
                                        <Activity className="w-4 h-4" />
                                        GROUNDED IN REAL-TIME SEARCH
                                    </div>
                                    <button 
                                        onClick={handleSaveToMissionLog}
                                        className="flex items-center gap-2 px-4 py-2 bg-white/5 hover:bg-indigo-600/20 text-slate-400 hover:text-indigo-400 border border-white/10 hover:border-indigo-500/30 rounded-xl text-xs font-bold transition-all"
                                    >
                                        <Download className="w-4 h-4" /> SAVE TO MISSION LOG
                                    </button>
                                </div>
                            </div>
                        ) : (
                            <div className="flex flex-col items-center justify-center h-[60vh] text-center">
                                <div className="w-24 h-24 bg-indigo-600/10 rounded-[32px] flex items-center justify-center mb-8 border border-indigo-500/20 animate-bounce">
                                    <Compass className="w-12 h-12 text-indigo-400" />
                                </div>
                                <h2 className="text-3xl font-black text-white mb-4 tracking-tighter uppercase">Comet Research Hub</h2>
                                <p className="text-slate-500 max-w-sm mx-auto font-light leading-relaxed">
                                    Enter a query in the omnibox to initiate search grounding and autonomous synthesis.
                                </p>
                            </div>
                        )}
                    </div>
                ) : (
                    <iframe 
                        src={activeTab.url} 
                        className="w-full h-full border-none bg-white"
                        sandbox="allow-same-origin allow-scripts allow-popups allow-forms"
                        title="Live Browser"
                    />
                )}
            </div>

            {/* COMET ASSISTANT SIDEBAR */}
            <div className={`absolute top-0 right-0 bottom-0 w-[380px] bg-slate-900 border-l border-white/5 flex flex-col transition-all duration-500 z-10 shadow-[-20px_0_40px_rgba(0,0,0,0.5)] ${isAssistantOpen ? 'translate-x-0' : 'translate-x-full'}`}>
                {/* Assistant Header */}
                <div className="p-6 border-b border-white/5 bg-slate-800/20 backdrop-blur-xl">
                    <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-xl bg-indigo-600/20 flex items-center justify-center border border-indigo-500/30 relative">
                                <Sparkles className="w-5 h-5 text-indigo-400" />
                                {isAssistantThinking && (
                                    <div className="absolute -top-1 -right-1 w-3 h-3 bg-indigo-500 rounded-full animate-ping"></div>
                                )}
                            </div>
                            <div>
                                <h3 className="font-black text-white text-sm uppercase tracking-widest">Comet Assistant</h3>
                                <p className="text-[10px] text-indigo-400 font-bold tracking-widest uppercase">Grounded Node</p>
                            </div>
                        </div>
                        <button onClick={() => setIsAssistantOpen(false)} className="text-slate-500 hover:text-white p-1.5 hover:bg-white/5 rounded-lg transition-all">
                            <X className="w-5 h-5" />
                        </button>
                    </div>

                    {/* Quick Tools */}
                    <div className="grid grid-cols-3 gap-2 mt-6">
                        <button 
                            onClick={() => handleAssistantSend("Summarize the main findings of this research for a high-level briefing.")}
                            className="flex flex-col items-center justify-center p-3 bg-white/5 hover:bg-white/10 rounded-xl border border-white/5 transition-all group"
                        >
                            <ClipboardList className="w-4 h-4 text-slate-400 group-hover:text-indigo-400 mb-1.5" />
                            <span className="text-[9px] font-black text-slate-500 uppercase tracking-tighter">Summarize</span>
                        </button>
                        <button 
                            onClick={() => handleAssistantSend("Extract all technical specifications, costs, and data points into a structured table.")}
                            className="flex flex-col items-center justify-center p-3 bg-white/5 hover:bg-white/10 rounded-xl border border-white/5 transition-all group"
                        >
                            <Download className="w-4 h-4 text-slate-400 group-hover:text-indigo-400 mb-1.5" />
                            <span className="text-[9px] font-black text-slate-500 uppercase tracking-tighter">Extract Data</span>
                        </button>
                        <button 
                            onClick={() => handleAssistantSend("What are the potential risks or missing information in this research topic?")}
                            className="flex flex-col items-center justify-center p-3 bg-white/5 hover:bg-white/10 rounded-xl border border-white/5 transition-all group"
                        >
                            <Zap className="w-4 h-4 text-slate-400 group-hover:text-indigo-400 mb-1.5" />
                            <span className="text-[9px] font-black text-slate-500 uppercase tracking-tighter">Find Gaps</span>
                        </button>
                    </div>
                </div>
                
                {/* Chat Stream */}
                <div className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar bg-slate-900/50">
                    {assistantMessages.map((msg, idx) => (
                        <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-in fade-in slide-in-from-top-2 duration-300`}>
                            <div className={`
                                max-w-[90%] p-4 rounded-2xl text-sm leading-relaxed shadow-lg
                                ${msg.role === 'user' 
                                    ? 'bg-indigo-600 text-white rounded-br-none' 
                                    : 'bg-slate-800/80 border border-white/5 text-slate-300 rounded-bl-none'}
                            `}>
                                <div className="prose prose-sm prose-invert max-w-none">
                                    <ReactMarkdown>{msg.content}</ReactMarkdown>
                                </div>
                            </div>
                        </div>
                    ))}
                    {isAssistantThinking && (
                        <div className="flex justify-start">
                            <div className="bg-slate-800/40 p-4 rounded-2xl rounded-bl-none border border-white/5">
                                <div className="flex gap-1.5">
                                    <div className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-bounce" style={{ animationDelay: '0s' }}></div>
                                    <div className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                                    <div className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></div>
                                </div>
                            </div>
                        </div>
                    )}
                    <div ref={messagesEndRef} />
                </div>

                {/* Input Area */}
                <div className="p-6 border-t border-white/5 bg-slate-950/80 backdrop-blur-xl">
                    <div className="relative">
                        <textarea 
                            value={assistantInput}
                            onChange={(e) => setAssistantInput(e.target.value)}
                            onKeyDown={(e) => {
                                if (e.key === 'Enter' && !e.shiftKey) {
                                    e.preventDefault();
                                    handleAssistantSend();
                                }
                            }}
                            placeholder="Instruct assistant..."
                            className="w-full bg-slate-900 border border-white/10 rounded-2xl py-4 pl-4 pr-12 text-sm text-slate-200 focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500/50 resize-none h-24 custom-scrollbar transition-all"
                        />
                        <button 
                            onClick={() => handleAssistantSend()}
                            disabled={!assistantInput.trim() || isAssistantThinking}
                            className="absolute right-3 bottom-3 p-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl disabled:opacity-30 disabled:grayscale transition-all shadow-lg"
                        >
                            <ArrowRight className="w-5 h-5" />
                        </button>
                    </div>
                    <p className="text-[9px] text-slate-600 mt-3 text-center uppercase font-black tracking-widest">
                        Context-Aware Research Node • JULES-v4
                    </p>
                </div>
            </div>
        </div>
        
        <style>{`
            .no-scrollbar::-webkit-scrollbar { display: none; }
            .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
            .custom-scrollbar::-webkit-scrollbar { width: 4px; }
            .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
            .custom-scrollbar::-webkit-scrollbar-thumb { background: rgba(99, 102, 241, 0.2); border-radius: 2px; }
            .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: rgba(99, 102, 241, 0.4); }
        `}</style>
    </div>
  );
};

export default CometBrowser;
