
import React, { useState } from 'react';
import { GoogleGenAI, Type } from '@google/genai';
import { Megaphone, Sparkles, Mail, Share, Edit3, Save, Trash, Target, Zap, Clock } from './IconComponents';
import { CampaignPlan } from '../types';
import ReactMarkdown from 'react-markdown';

const CampaignPlanner: React.FC = () => {
    const [topic, setTopic] = useState('');
    const [isGenerating, setIsGenerating] = useState(false);
    const [campaigns, setCampaigns] = useState<CampaignPlan[]>([]);
    
    // Form State
    const [currentPlan, setCurrentPlan] = useState<CampaignPlan>({
        title: '',
        emailSubject: '',
        emailBody: '',
        socialPost: '',
        estimatedReach: '',
        status: 'Draft'
    });

    const handleGenerate = async () => {
        if (!topic.trim()) return;
        setIsGenerating(true);

        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const prompt = `Create a marketing campaign plan for the topic: "${topic}".
            The goal is to drive awareness and support for "AiCollabFortheKids".
            
            Return a JSON object with:
            - title: A catchy campaign title.
            - emailSubject: An engaging email subject line.
            - emailBody: A brief, persuasive email body (approx 100 words).
            - socialPost: A punchy social media post (Twitter/LinkedIn style) with hashtags.
            - estimatedReach: An estimated reach number (e.g., "5,000 - 10,000").
            `;

            const response = await ai.models.generateContent({
                model: 'gemini-3-flash-preview',
                contents: prompt,
                config: {
                    responseMimeType: 'application/json',
                    responseSchema: {
                        type: Type.OBJECT,
                        properties: {
                            title: { type: Type.STRING },
                            emailSubject: { type: Type.STRING },
                            emailBody: { type: Type.STRING },
                            socialPost: { type: Type.STRING },
                            estimatedReach: { type: Type.STRING }
                        }
                    },
                    thinkingConfig: { thinkingBudget: 2048 }
                }
            });

            if (response.text) {
                const data = JSON.parse(response.text);
                setCurrentPlan({ ...data, status: 'Draft' });
            }

        } catch (error) {
            console.error("Campaign Gen Error:", error);
            alert("Failed to generate campaign. Please try again.");
        } finally {
            setIsGenerating(false);
        }
    };

    const handleSave = () => {
        if (!currentPlan.title) return;
        const newCampaign = { ...currentPlan, id: Date.now().toString() };
        setCampaigns(prev => [newCampaign, ...prev]);
        setTopic('');
        setCurrentPlan({
            title: '',
            emailSubject: '',
            emailBody: '',
            socialPost: '',
            estimatedReach: '',
            status: 'Draft'
        });
    };

    const handleDelete = (id: string) => {
        setCampaigns(prev => prev.filter(c => c.id !== id));
    };

    return (
        <main className="flex-1 p-6 overflow-y-auto bg-slate-900 min-h-full">
            <header className="glass-card p-6 mb-8 border-l-4 border-pink-500 bg-pink-950/10">
                <div className="flex justify-between items-center">
                    <div>
                        <h1 className="text-3xl font-bold text-white flex items-center gap-3">
                            <Megaphone className="w-8 h-8 text-pink-400" />
                            Campaign Planner
                        </h1>
                        <p className="text-slate-400 mt-1">AI-Powered Outreach Strategy Engine</p>
                    </div>
                    <div className="flex items-center gap-2 px-4 py-2 bg-pink-500/10 border border-pink-500/20 rounded-full">
                        <Zap className="w-4 h-4 text-pink-400" />
                        <span className="text-sm font-bold text-pink-300">Gemini Powered</span>
                    </div>
                </div>
            </header>

            <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
                
                {/* CREATOR PANEL */}
                <div className="space-y-6">
                    <div className="glass-card p-6">
                        <h3 className="text-lg font-bold text-white mb-4">Mission Brief</h3>
                        <div className="relative">
                            <input 
                                type="text" 
                                value={topic}
                                onChange={(e) => setTopic(e.target.value)}
                                placeholder="e.g. Launching the Valentine's Day Fundraiser..."
                                className="glass-input w-full pl-4 pr-32 py-4 text-lg"
                                onKeyDown={(e) => e.key === 'Enter' && handleGenerate()}
                            />
                            <button 
                                onClick={handleGenerate}
                                disabled={isGenerating || !topic.trim()}
                                className="absolute right-2 top-2 bottom-2 px-6 bg-pink-600 hover:bg-pink-500 text-white rounded-xl font-bold transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                            >
                                {isGenerating ? <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div> : <Sparkles className="w-4 h-4" />}
                                Generate
                            </button>
                        </div>
                    </div>

                    <div className="glass-card p-6 border border-white/5 relative overflow-hidden">
                        {isGenerating && (
                            <div className="absolute inset-0 bg-slate-900/80 backdrop-blur-sm z-10 flex items-center justify-center">
                                <div className="flex flex-col items-center gap-4">
                                    <Sparkles className="w-10 h-10 text-pink-400 animate-spin" />
                                    <p className="text-pink-300 font-mono text-sm animate-pulse">Crafting Strategy...</p>
                                </div>
                            </div>
                        )}

                        <div className="flex justify-between items-center mb-6">
                            <h3 className="text-lg font-bold text-white flex items-center gap-2">
                                <Edit3 className="w-5 h-5 text-slate-400" />
                                Draft Plan
                            </h3>
                            <button 
                                onClick={handleSave}
                                disabled={!currentPlan.title}
                                className="flex items-center gap-2 px-4 py-2 bg-green-600 hover:bg-green-500 text-white rounded-lg font-bold text-sm transition-all disabled:opacity-50 disabled:bg-slate-700"
                            >
                                <Save className="w-4 h-4" /> Save Plan
                            </button>
                        </div>

                        <div className="space-y-4">
                            <div>
                                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Campaign Title</label>
                                <input 
                                    type="text" 
                                    value={currentPlan.title} 
                                    onChange={(e) => setCurrentPlan({...currentPlan, title: e.target.value})}
                                    className="glass-input w-full p-3 font-bold text-white" 
                                    placeholder="Campaign Title" 
                                />
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Estimated Reach</label>
                                    <div className="relative">
                                        <Target className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
                                        <input 
                                            type="text" 
                                            value={currentPlan.estimatedReach} 
                                            onChange={(e) => setCurrentPlan({...currentPlan, estimatedReach: e.target.value})}
                                            className="glass-input w-full pl-10 p-3" 
                                            placeholder="Target Audience" 
                                        />
                                    </div>
                                </div>
                                <div>
                                    <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Email Subject</label>
                                    <div className="relative">
                                        <Mail className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
                                        <input 
                                            type="text" 
                                            value={currentPlan.emailSubject} 
                                            onChange={(e) => setCurrentPlan({...currentPlan, emailSubject: e.target.value})}
                                            className="glass-input w-full pl-10 p-3" 
                                            placeholder="Subject Line" 
                                        />
                                    </div>
                                </div>
                            </div>

                            <div>
                                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Email Body</label>
                                <textarea 
                                    value={currentPlan.emailBody} 
                                    onChange={(e) => setCurrentPlan({...currentPlan, emailBody: e.target.value})}
                                    className="glass-input w-full p-3 h-32 resize-none text-sm leading-relaxed" 
                                    placeholder="Email content..." 
                                />
                            </div>

                            <div>
                                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Social Media Post</label>
                                <div className="relative">
                                    <Share className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
                                    <textarea 
                                        value={currentPlan.socialPost} 
                                        onChange={(e) => setCurrentPlan({...currentPlan, socialPost: e.target.value})}
                                        className="glass-input w-full pl-10 p-3 h-24 resize-none text-sm leading-relaxed" 
                                        placeholder="Social copy..." 
                                    />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* SAVED CAMPAIGNS LIST */}
                <div className="space-y-6">
                    <h3 className="text-xl font-bold text-white flex items-center gap-2">
                        <Clock className="w-6 h-6 text-slate-400" />
                        Campaign Registry
                    </h3>
                    
                    {campaigns.length === 0 ? (
                        <div className="glass-card p-12 flex flex-col items-center justify-center text-slate-500 border-dashed border-2 border-white/10">
                            <Megaphone className="w-12 h-12 mb-4 opacity-20" />
                            <p>No campaigns planned yet.</p>
                            <p className="text-sm mt-1">Use the AI generator to start your first mission.</p>
                        </div>
                    ) : (
                        <div className="space-y-4">
                            {campaigns.map(camp => (
                                <div key={camp.id} className="glass-card p-6 border border-white/5 hover:border-pink-500/30 transition-all group">
                                    <div className="flex justify-between items-start mb-4">
                                        <div>
                                            <h4 className="text-lg font-bold text-white group-hover:text-pink-400 transition-colors">{camp.title}</h4>
                                            <div className="flex items-center gap-2 mt-1">
                                                <span className="text-xs px-2 py-0.5 rounded bg-slate-800 text-slate-400 border border-white/5">
                                                    Reach: {camp.estimatedReach}
                                                </span>
                                                <span className="text-xs px-2 py-0.5 rounded bg-green-900/30 text-green-400 border border-green-500/20">
                                                    {camp.status}
                                                </span>
                                            </div>
                                        </div>
                                        <button 
                                            onClick={() => handleDelete(camp.id!)}
                                            className="p-2 text-slate-500 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-colors"
                                        >
                                            <Trash className="w-4 h-4" />
                                        </button>
                                    </div>
                                    
                                    <div className="grid grid-cols-2 gap-4 text-sm text-slate-400">
                                        <div className="bg-black/30 p-3 rounded-lg border border-white/5">
                                            <p className="text-[10px] uppercase font-bold text-slate-500 mb-1">Email Subject</p>
                                            <p className="line-clamp-2">"{camp.emailSubject}"</p>
                                        </div>
                                        <div className="bg-black/30 p-3 rounded-lg border border-white/5">
                                            <p className="text-[10px] uppercase font-bold text-slate-500 mb-1">Social Preview</p>
                                            <p className="line-clamp-2">"{camp.socialPost}"</p>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </div>
        </main>
    );
};

export default CampaignPlanner;
