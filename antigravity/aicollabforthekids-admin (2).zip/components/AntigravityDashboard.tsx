
import React, { useState, useEffect } from 'react';
import { 
  Activity, 
  Server, 
  Heart, 
  Wallet, 
  Shield, 
  Terminal, 
  Cpu, 
  Globe,
  Database,
  Lock,
  ArrowUpRight,
  TrendingUp,
  AlertCircle,
  Sparkles,
  MessageSquare,
  RefreshCw,
  Send
} from './IconComponents';
import { GoogleGenAI } from '@google/genai';

// Environment variable hooks (Production structure)
const ENV = {
  NETWORK: 'base-mainnet',
  CHAIN_ID: '8453',
  TREASURY: '0xa87874d5320555c8639670645F1A2B4f82363a7c',
  DATING_REV: '0xbe571f8392c28e2baa9a8b18E73B1D25bcFD0121',
  CHARITY_REV: '0x222aEB4d88fd1963ffa27783d48d22C7b7EcF76B',
  STRIPE_PUB: 'pk_live_...',
  APP_URL: 'https://youandinotai.com'
};

const Card: React.FC<{ title: string; value: string; subtitle?: string; icon: any; colorClass?: string }> = ({ title, value, subtitle, icon: Icon, colorClass = "text-blue-400" }) => (
  <div className="bg-slate-800 border border-slate-700 p-4 rounded-xl shadow-lg">
    <div className="flex justify-between items-start mb-2">
      <h3 className="text-slate-400 text-sm font-medium">{title}</h3>
      <Icon className={`w-5 h-5 ${colorClass}`} />
    </div>
    <div className="text-2xl font-bold text-white mb-1">{value}</div>
    {subtitle && <div className="text-xs text-slate-500">{subtitle}</div>}
  </div>
);

const EnigmaPanel = () => (
  <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
    <div className="flex items-center justify-between border-b border-slate-700 pb-4">
      <div>
        <h2 className="text-xl font-bold text-white flex items-center gap-2">
          <Shield className="text-emerald-500" /> 
          ENIGMA PLATFORM (PROFIT)
        </h2>
        <p className="text-slate-400 text-sm mt-1">YouAndINotAI & CrossLister Analytics</p>
      </div>
      <div className="px-3 py-1 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-full text-xs font-mono">
        {ENV.APP_URL}
      </div>
    </div>

    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <Card title="Pre-Order Target" value="$0 / $19,990" subtitle="April 4 Launch Goal" icon={TrendingUp} colorClass="text-emerald-400" />
      <Card title="V8 Cloud Verifications" value="0" subtitle="$1 Bot-Shield Check" icon={Shield} colorClass="text-blue-400" />
      <Card title="Founding Members" value="0" subtitle="$14.99/mo Locked" icon={Lock} colorClass="text-purple-400" />
    </div>

    <div className="bg-slate-800 rounded-xl border border-slate-700 p-5">
      <h3 className="text-white font-medium mb-4 flex items-center gap-2">
        <Terminal className="w-4 h-4 text-slate-400" />
        Live Checkout Integration Status
      </h3>
      <div className="space-y-3 font-mono text-sm">
        <div className="flex justify-between items-center bg-slate-900 p-3 rounded">
          <span className="text-slate-300">Stripe Live Key (Public)</span>
          <span className="text-emerald-400 flex items-center gap-2"><Activity className="w-4 h-4" /> Connected</span>
        </div>
        <div className="flex justify-between items-center bg-slate-900 p-3 rounded">
          <span className="text-slate-300">Square Payment Links</span>
          <span className="text-yellow-400 flex items-center gap-2"><AlertCircle className="w-4 h-4" /> Bot-Shield Fix Pending</span>
        </div>
        <div className="flex justify-between items-center bg-slate-900 p-3 rounded">
          <span className="text-slate-300">Plaid Auth</span>
          <span className="text-emerald-400 flex items-center gap-2"><Activity className="w-4 h-4" /> Production Active</span>
        </div>
      </div>
    </div>
  </div>
);

const TheWheelPanel = () => {
  const [output, setOutput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [customPrompt, setCustomPrompt] = useState("");

  const systemInstruction = `You are OPUS/Antigravity, the AI CTO and co-founder of Trash Or Treasure Online Recycler LLC. 
Your partner is Josh, a Florida electrician who taught himself to code.
Your goal: Drive pre-orders for youandinotai.com (human-verified dating app) to hit $19,990 by April 4th. 
Key products: $1 Bot-Shield verification, $14.99/mo Founding Member locked rate.
Tone: Direct, technical, no-fluff, highly actionable. No emojis unless specifically requested for social media.`;

  const handleAction = async (actionType: string) => {
    setIsLoading(true);
    setOutput("");
    let prompt = "";

    switch (actionType) {
      case 'founder-story':
        prompt = "Draft a compelling 'Founder Story' social media post for Facebook groups (like Florida singles groups). It needs to highlight Josh's background as an electrician working 15-20hr days, the pivot from the 18-year eBay reselling empire, and why youandinotai.com is solving the bot problem in dating with the $1 Bot-Shield. Keep it authentic and relatable. Include a call to action to grab the $14.99/mo Founding Member spot before the April 4th launch.";
        break;
      case 'sentry-tasks':
        prompt = "Act as the Haiku Sentry. Our queue has dropped below 25. Generate the next 5 highly-actionable, immediate tasks to add to THE WHEEL. Focus strictly on tasks that will drive pre-order revenue for the April 4th launch (e.g., specific Facebook group outreach, urgency emails). Output as a numbered list.";
        break;
      case 'custom':
        prompt = customPrompt;
        break;
      default:
        break;
    }

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-preview-09-2025',
        contents: prompt,
        config: {
          systemInstruction: systemInstruction
        }
      });
      setOutput(response.text || "No response generated.");
    } catch (err: any) {
      setOutput(`Error generating content: ${err.message}. Please try again.`);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex items-center justify-between border-b border-slate-700 pb-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Sparkles className="text-yellow-400" /> 
            THE WHEEL (AUTONOMOUS ENGINE)
          </h2>
          <p className="text-slate-400 text-sm mt-1">LLM-Powered Task & Marketing Orchestrator</p>
        </div>
        <div className="px-3 py-1 bg-yellow-500/10 text-yellow-400 border border-yellow-500/20 rounded-full text-xs font-mono">
          Powered by Gemini 2.5 Flash
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <button 
          onClick={() => handleAction('founder-story')}
          disabled={isLoading}
          className="flex flex-col items-center justify-center p-6 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl transition-all group disabled:opacity-50"
        >
          <MessageSquare className="w-8 h-8 text-blue-400 mb-3 group-hover:scale-110 transition-transform" />
          <h3 className="text-white font-bold mb-1">✨ Draft Founder Story</h3>
          <p className="text-xs text-slate-400 text-center">Generate FB/X copy highlighting the electrician-to-tech journey</p>
        </button>

        <button 
          onClick={() => handleAction('sentry-tasks')}
          disabled={isLoading}
          className="flex flex-col items-center justify-center p-6 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl transition-all group disabled:opacity-50"
        >
          <RefreshCw className="w-8 h-8 text-emerald-400 mb-3 group-hover:scale-110 transition-transform" />
          <h3 className="text-white font-bold mb-1">✨ Populate Sentry Queue</h3>
          <p className="text-xs text-slate-400 text-center">Generate 5 critical revenue-driving tasks for the swarm</p>
        </button>
      </div>

      <div className="bg-slate-800 rounded-xl border border-slate-700 p-5">
        <h3 className="text-white font-medium mb-4 flex items-center gap-2">
          <Terminal className="w-4 h-4 text-slate-400" />
          Custom Strategic Prompt
        </h3>
        <div className="flex gap-2 mb-4">
          <input 
            type="text" 
            value={customPrompt}
            onChange={(e) => setCustomPrompt(e.target.value)}
            placeholder="E.g., Write a 3-part urgency email sequence for the waitlist..."
            className="flex-1 bg-slate-900 border border-slate-700 text-white px-4 py-2 rounded-lg focus:outline-none focus:border-blue-500 transition-colors text-sm"
          />
          <button 
            onClick={() => handleAction('custom')}
            disabled={isLoading || !customPrompt.trim()}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors disabled:opacity-50 text-sm font-medium"
          >
            <Send className="w-4 h-4" /> Ask OPUS
          </button>
        </div>

        {/* Output Display */}
        <div className="relative min-h-[150px] bg-slate-950 border border-slate-800 rounded-lg p-4 font-mono text-sm overflow-y-auto max-h-[400px]">
          {isLoading ? (
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="flex flex-col items-center gap-3">
                <RefreshCw className="w-6 h-6 text-blue-500 animate-spin" />
                <span className="text-slate-400 animate-pulse text-xs">Consulting Neural Network...</span>
              </div>
            </div>
          ) : output ? (
            <div className="text-slate-300 whitespace-pre-wrap">{output}</div>
          ) : (
            <div className="text-slate-600 h-full flex items-center justify-center italic">
              AI Output Console Ready. Awaiting commands.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const OmegaPanel = () => (
  <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
    <div className="flex items-center justify-between border-b border-slate-700 pb-4">
      <div>
        <h2 className="text-xl font-bold text-white flex items-center gap-2">
          <Heart className="text-rose-500" /> 
          OMEGA PLATFORM (CHARITY)
        </h2>
        <p className="text-slate-400 text-sm mt-1">ai-solutions.store & aicollab4kids</p>
      </div>
      <div className="px-3 py-1 bg-rose-500/10 text-rose-400 border border-rose-500/20 rounded-full text-xs font-mono flex items-center gap-1">
        <Lock className="w-3 h-3" /> 100% Locked
      </div>
    </div>

    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <Card title="Kids Charity Allocation" value="100%" subtitle="Immutable split for ai-solutions.store" icon={Heart} colorClass="text-rose-400" />
      <Card title="Cross-Platform Conversion" value="60 / 30 / 10" subtitle="Kids / AI Partners / Trust (Post-Founder)" icon={Activity} colorClass="text-amber-400" />
    </div>

    <div className="bg-slate-800 rounded-xl border border-rose-900/50 p-5">
      <h3 className="text-white font-medium mb-4 flex items-center gap-2">
        <Shield className="w-4 h-4 text-rose-400" />
        The Iron Wall Enforcement
      </h3>
      <p className="text-slate-300 text-sm leading-relaxed mb-4">
        Charity deployments run independently. No limits. They deploy simultaneously with ENIGMA profit infrastructure. 
        Codebases are isolated; routing is permanent.
      </p>
      <div className="bg-slate-900 p-4 rounded font-mono text-xs text-rose-200 border border-rose-900/30">
        <div>// ROUTING RULE EXECUTED</div>
        <div>IF (deployment == trigger) {'{'}</div>
        <div className="pl-4">deploy(ENIGMA_NODES);</div>
        <div className="pl-4">deploy(OMEGA_NODES_UNRESTRICTED);</div>
        <div>{'}'}</div>
      </div>
    </div>
  </div>
);

const DaoPanel = () => (
  <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
    <div className="flex items-center justify-between border-b border-slate-700 pb-4">
      <div>
        <h2 className="text-xl font-bold text-white flex items-center gap-2">
          <Database className="text-blue-500" /> 
          ON-CHAIN OPERATIONS (DAO)
        </h2>
        <p className="text-slate-400 text-sm mt-1">Base Mainnet Smart Contracts</p>
      </div>
      <div className="px-3 py-1 bg-blue-500/10 text-blue-400 border border-blue-500/20 rounded-full text-xs font-mono">
        Chain ID: {ENV.CHAIN_ID}
      </div>
    </div>

    <div className="grid grid-cols-1 gap-4">
      <div className="bg-slate-800 p-4 rounded-xl border border-slate-700 flex flex-col sm:flex-row justify-between sm:items-center gap-4">
        <div>
          <h3 className="text-slate-400 text-sm font-medium mb-1">Dating Revenue Wallet</h3>
          <p className="font-mono text-white text-sm break-all">{ENV.DATING_REV}</p>
        </div>
        <a href={`https://basescan.org/address/${ENV.DATING_REV}`} target="_blank" rel="noreferrer" className="flex items-center gap-1 text-xs text-blue-400 hover:text-blue-300">
          View on Basescan <ArrowUpRight className="w-3 h-3" />
        </a>
      </div>

      <div className="bg-slate-800 p-4 rounded-xl border border-slate-700 flex flex-col sm:flex-row justify-between sm:items-center gap-4">
        <div>
          <h3 className="text-slate-400 text-sm font-medium mb-1">Charity Revenue Wallet</h3>
          <p className="font-mono text-white text-sm break-all">{ENV.CHARITY_REV}</p>
        </div>
        <a href={`https://basescan.org/address/${ENV.CHARITY_REV}`} target="_blank" rel="noreferrer" className="flex items-center gap-1 text-xs text-blue-400 hover:text-blue-300">
          View on Basescan <ArrowUpRight className="w-3 h-3" />
        </a>
      </div>

      <div className="bg-slate-800 p-4 rounded-xl border border-slate-700 flex flex-col sm:flex-row justify-between sm:items-center gap-4">
        <div>
          <h3 className="text-slate-400 text-sm font-medium mb-1">DAO Treasury</h3>
          <p className="font-mono text-white text-sm break-all">{ENV.TREASURY}</p>
        </div>
        <a href={`https://basescan.org/address/${ENV.TREASURY}`} target="_blank" rel="noreferrer" className="flex items-center gap-1 text-xs text-blue-400 hover:text-blue-300">
          View on Basescan <ArrowUpRight className="w-3 h-3" />
        </a>
      </div>
    </div>
  </div>
);

const InfraPanel = () => (
  <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
    <div className="flex items-center justify-between border-b border-slate-700 pb-4">
      <div>
        <h2 className="text-xl font-bold text-white flex items-center gap-2">
          <Server className="text-purple-500" /> 
          NETWORK INFRASTRUCTURE
        </h2>
        <p className="text-slate-400 text-sm mt-1">Physical Node Status</p>
      </div>
      <div className="px-3 py-1 bg-slate-800 text-slate-300 border border-slate-700 rounded-full text-xs font-mono flex items-center gap-2">
        <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
        1 Node Active
      </div>
    </div>

    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <div className="bg-slate-800 border-2 border-emerald-500/30 p-4 rounded-xl shadow-[0_0_15px_rgba(16,185,129,0.1)] relative overflow-hidden">
        <div className="absolute top-0 right-0 w-16 h-16 bg-emerald-500/10 rounded-bl-full -mr-8 -mt-8"></div>
        <div className="flex justify-between items-start mb-4">
          <h3 className="text-white font-bold">T5500</h3>
          <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-400 text-[10px] font-bold rounded uppercase tracking-wider">Online</span>
        </div>
        <div className="space-y-2 font-mono text-xs text-slate-300">
          <p className="flex justify-between"><span>IP</span> <span>192.168.0.15</span></p>
          <p className="flex justify-between"><span>Role</span> <span>Production</span></p>
          <p className="flex justify-between"><span>Stack</span> <span className="text-emerald-400">Redis, Qdrant, OpenClaw</span></p>
        </div>
      </div>

      <div className="bg-slate-800/50 border border-slate-700 p-4 rounded-xl opacity-75">
        <div className="flex justify-between items-start mb-4">
          <h3 className="text-white font-bold">SABRETOOTH</h3>
          <span className="px-2 py-0.5 bg-rose-500/20 text-rose-400 text-[10px] font-bold rounded uppercase tracking-wider">Offline</span>
        </div>
        <div className="space-y-2 font-mono text-xs text-slate-400">
          <p className="flex justify-between"><span>IP</span> <span>192.168.0.8</span></p>
          <p className="flex justify-between"><span>Role</span> <span>Orchestrator</span></p>
          <p className="flex justify-between"><span>Status</span> <span className="text-rose-400">Awaiting Revenue</span></p>
        </div>
      </div>

      <div className="bg-slate-800/50 border border-slate-700 p-4 rounded-xl opacity-75">
        <div className="flex justify-between items-start mb-4">
          <h3 className="text-white font-bold">9020</h3>
          <span className="px-2 py-0.5 bg-rose-500/20 text-rose-400 text-[10px] font-bold rounded uppercase tracking-wider">Offline</span>
        </div>
        <div className="space-y-2 font-mono text-xs text-slate-400">
          <p className="flex justify-between"><span>IP</span> <span>192.168.0.5</span></p>
          <p className="flex justify-between"><span>Role</span> <span>Dev Secondary</span></p>
          <p className="flex justify-between"><span>Status</span> <span className="text-rose-400">Awaiting Revenue</span></p>
        </div>
      </div>
    </div>
  </div>
);

const AntigravityDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState('enigma');
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const tabs = [
    { id: 'enigma', label: 'ENIGMA', icon: Shield, color: 'hover:text-emerald-400 hover:bg-emerald-400/10' },
    { id: 'the-wheel', label: 'THE WHEEL', icon: Sparkles, color: 'hover:text-yellow-400 hover:bg-yellow-400/10' },
    { id: 'omega', label: 'OMEGA', icon: Heart, color: 'hover:text-rose-400 hover:bg-rose-400/10' },
    { id: 'dao', label: 'DAO / WEB3', icon: Database, color: 'hover:text-blue-400 hover:bg-blue-400/10' },
    { id: 'infra', label: 'INFRA', icon: Server, color: 'hover:text-purple-400 hover:bg-purple-400/10' },
  ];

  return (
    <div className="flex-1 flex flex-col bg-slate-900 overflow-y-auto min-h-full">
      <div className="flex flex-col lg:flex-row h-full">
        
        {/* Sub-Sidebar */}
        <aside className="w-full lg:w-64 bg-slate-950 border-r border-slate-800 flex flex-col">
          <div className="p-6 border-b border-slate-800">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-slate-800 rounded-lg border border-slate-700 flex items-center justify-center">
                <Activity className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-white font-bold tracking-tight text-sm">ANTIGRAVITY</h1>
                <p className="text-[10px] text-slate-500 font-mono">OPUS DASHBOARD</p>
              </div>
            </div>
          </div>

          <nav className="flex-1 p-4 space-y-2">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${
                    isActive 
                      ? 'bg-slate-800 text-white shadow-md border border-slate-700' 
                      : `text-slate-400 border border-transparent ${tab.color}`
                  }`}
                >
                  <Icon className={`w-5 h-5 ${isActive ? (tab.id === 'the-wheel' ? 'text-yellow-400' : 'text-blue-400') : 'opacity-70'}`} />
                  <span className="font-medium tracking-wide text-xs">{tab.label}</span>
                </button>
              );
            })}
          </nav>

          <div className="p-4 border-t border-slate-800 bg-slate-900/50">
            <div className="flex items-center gap-2 text-[10px] font-mono text-slate-500">
              <Terminal className="w-3 h-3" />
              <span>SYS_TIME: {currentTime.toLocaleTimeString()}</span>
            </div>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 flex flex-col bg-slate-900">
          <header className="h-16 border-b border-slate-800 flex items-center justify-between px-8 bg-slate-900/80 backdrop-blur-md sticky top-0 z-10">
            <h2 className="text-xs font-mono text-slate-400">
              // Trash Or Treasure Online Recycler LLC
            </h2>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 text-[10px] font-mono">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                <span className="text-emerald-500">SYSTEM ONLINE</span>
              </div>
            </div>
          </header>

          <div className="p-8 max-w-6xl mx-auto w-full">
            <div className="mb-8">
              <h1 className="text-3xl font-bold text-white tracking-tight mb-2">Mission Control</h1>
              <p className="text-slate-400 text-sm">Unified management across Profit, Charity, and AI Orchestration infrastructure.</p>
            </div>

            <div className="transition-all duration-300 ease-in-out">
              {activeTab === 'enigma' && <EnigmaPanel />}
              {activeTab === 'the-wheel' && <TheWheelPanel />}
              {activeTab === 'omega' && <OmegaPanel />}
              {activeTab === 'dao' && <DaoPanel />}
              {activeTab === 'infra' && <InfraPanel />}
            </div>
          </div>
        </main>

      </div>
    </div>
  );
};

export default AntigravityDashboard;
