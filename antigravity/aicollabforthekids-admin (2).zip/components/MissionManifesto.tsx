
import React from 'react';
import { Heart, X, Award, Users, Rocket } from './IconComponents';

interface MissionManifestoProps {
  isOpen: boolean;
  onClose: () => void;
}

const MissionManifesto: React.FC<MissionManifestoProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black flex items-center justify-center z-[2000] p-0 md:p-4 animate-in fade-in duration-500">
      <div className="glass-modal-content w-full max-w-7xl max-h-[100vh] md:max-h-[95vh] overflow-y-auto relative border-2 border-indigo-500/30 shadow-[0_0_200px_rgba(99,102,241,0.15)] rounded-none md:rounded-[48px] flex flex-col">
        
        <button 
            onClick={onClose}
            className="absolute top-10 right-10 p-4 bg-white/10 hover:bg-white/20 rounded-full text-white transition-all z-50 backdrop-blur-md border border-white/10"
        >
            <X className="w-8 h-8" />
        </button>

        <div className="flex-1 overflow-y-auto custom-scrollbar bg-[#050505]">
            {/* HERO SECTION */}
            <section className="relative min-h-[800px] flex flex-col items-center justify-center text-center p-12 md:p-32 overflow-hidden border-b border-white/5">
                <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,#0f172a_0%,#000_80%)]"></div>
                
                <div className="relative z-10 max-w-5xl mx-auto">
                    <div className="inline-flex items-center justify-center px-8 py-3 bg-indigo-500/10 backdrop-blur-md rounded-full mb-12 border border-indigo-500/30 shadow-2xl">
                        <Heart className="w-6 h-6 text-indigo-400 mr-4 fill-indigo-400 animate-pulse" />
                        <span className="text-sm font-black text-indigo-400 tracking-[0.6em] uppercase">THE COLEMAN PROTOCOL</span>
                    </div>
                    
                    <h1 className="text-8xl md:text-[10rem] font-black text-white mb-12 tracking-tighter leading-[0.85]">
                        #FOR THE <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 via-white to-pink-400">KIDS.</span> <br />
                        <span className="text-4xl md:text-7xl text-slate-500 font-light tracking-widest mt-6 block">CHARITY AUTOMATION.</span>
                    </h1>
                    
                    <p className="text-2xl md:text-4xl text-slate-300 font-light max-w-4xl mx-auto mt-16 leading-relaxed">
                        Help ALL children everywhere through AI-powered automated charity projects. <br />
                        <span className="text-white font-bold">We believe artificial intelligence should serve humanity&apos;s most vulnerable - our children.</span>
                    </p>
                </div>
            </section>

            <div className="bg-black text-white px-12 md:px-40 py-40">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-40">
                    
                    {/* LEFT SIDE: THE MISSION */}
                    <div className="space-y-24">
                        <div>
                            <h3 className="text-4xl font-black mb-8 flex items-center gap-6 text-indigo-400 uppercase tracking-tighter">
                                <Award className="w-12 h-12" /> 100% DISBURSEMENT
                            </h3>
                            <p className="text-slate-400 leading-relaxed text-2xl font-light">
                                &quot;This platform exists for one purpose: to fund the specialized care, adaptive technology, 
                                and medical research required for those with special needs to live with dignity and independence. 
                                No profit is taken. Every dollar is a tool for a better life.&quot;
                            </p>
                        </div>

                        <div>
                            <h3 className="text-4xl font-black mb-8 flex items-center gap-6 text-blue-400 uppercase tracking-tighter">
                                <Users className="w-12 h-12" /> THE ARCHITECT&apos;S VOW
                            </h3>
                            <p className="text-slate-400 leading-relaxed text-2xl font-light">
                                &quot;I have built this as a tribute to the intelligence of the future (Google/Anthropic) and the 
                                humanity of my brother. I have removed the human greed from the code. The kids and special 
                                needs adults are the only beneficiaries. Always.&quot;
                            </p>
                        </div>
                    </div>

                    {/* RIGHT SIDE: HOW IT WORKS */}
                    <div className="bg-white/5 p-16 rounded-[80px] border border-white/10 relative overflow-hidden flex flex-col justify-center">
                        <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/10 rounded-bl-full"></div>
                        <h3 className="text-4xl font-black mb-12 flex items-center gap-6 text-indigo-400 uppercase tracking-tighter">
                            <Rocket className="w-12 h-12" /> HOW IT WORKS
                        </h3>
                        <div className="space-y-12">
                            <div>
                                <h4 className="text-white font-bold text-2xl mb-3 uppercase tracking-wider">Original Project</h4>
                                <ul className="space-y-2 text-slate-400 text-lg font-light">
                                    <li>• 60% → DAO Treasury (Charity Hospitals)</li>
                                    <li>• 30% → Infrastructure (Powers future projects)</li>
                                    <li>• 10% → Founder (Gospel V1.3)</li>
                                </ul>
                            </div>
                            <div>
                                <h4 className="text-white font-bold text-2xl mb-3 uppercase tracking-wider">All New Projects</h4>
                                <ul className="space-y-2 text-slate-400 text-lg font-light">
                                    <li>• 100% → Directly to children's hospitals</li>
                                    <li>• Zero fees → Infrastructure already paid for</li>
                                    <li>• Forever → Runs autonomously in the cloud</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                {/* THE FINAL QUOTE */}
                <div className="mt-56 text-center">
                    <div className="inline-block p-16 border border-indigo-500/20 rounded-[64px] bg-indigo-500/5 max-w-5xl">
                        <p className="text-4xl md:text-6xl font-serif italic text-slate-100 mb-12 leading-tight">
                            &quot;This platform will run in the cloud forever, helping kids long after we&apos;re gone. Even when I&apos;m in the clouds, smiling at what we built together.&quot;
                        </p>
                        <div className="flex flex-col items-center">
                            <div className="w-32 h-1 bg-indigo-500 mb-8 rounded-full"></div>
                            <span className="font-black text-indigo-500 tracking-[0.8em] uppercase text-lg">Joshua Coleman • Founder</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div className="p-10 bg-black border-t border-white/5 text-center">
             <button onClick={onClose} className="px-20 py-8 bg-indigo-600 hover:bg-indigo-500 text-white font-black text-3xl uppercase tracking-[0.3em] rounded-full transition-all hover:scale-105 shadow-[0_0_100px_rgba(99,102,241,0.5)]">
                 SEAL THE COLEMAN PROTOCOL
             </button>
        </div>
      </div>
    </div>
  );
};

export default MissionManifesto;
