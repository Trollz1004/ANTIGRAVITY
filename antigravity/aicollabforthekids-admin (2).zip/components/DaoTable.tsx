
import React, { useState, useMemo } from 'react';
import { type DaoLaunch } from '../types';
// Add Zap to the imports from IconComponents
import { Plus, Sparkles, ArrowUp, ArrowDown, TrendingUp, Heart, ExternalLink, Activity, ShieldCheck, QrCode, Zap } from './IconComponents';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';

interface DaoTableProps {
  daoLaunches: DaoLaunch[];
  onAdd?: () => void;
  onAnalyze: (dao: DaoLaunch) => void;
  isLoading?: boolean;
}

type SortDirection = 'asc' | 'desc';

interface SortConfig {
  key: keyof DaoLaunch;
  direction: SortDirection;
}

const DaoTable: React.FC<DaoTableProps> = ({ daoLaunches, onAdd, onAnalyze, isLoading = false }) => {
  const [sortConfig, setSortConfig] = useState<SortConfig | null>(null);

  const sortedDaos = useMemo(() => {
    const sortableItems = [...daoLaunches];
    if (sortConfig !== null) {
      sortableItems.sort((a, b) => {
        if (sortConfig.key === 'launchDate') {
            const dateA = new Date(a.launchDate).getTime();
            const dateB = new Date(b.launchDate).getTime();
            if (dateA < dateB) {
                return sortConfig.direction === 'asc' ? -1 : 1;
            }
            if (dateA > dateB) {
                return sortConfig.direction === 'asc' ? 1 : -1;
            }
            return 0;
        }
        return 0;
      });
    }
    return sortableItems;
  }, [daoLaunches, sortConfig]);

  const requestSort = (key: keyof DaoLaunch) => {
    let direction: SortDirection = 'asc';
    if (sortConfig && sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  // Analytics Calculations
  const totalTreasury = daoLaunches.reduce((acc, dao) => acc + dao.treasury, 0);
  const avgTreasury = daoLaunches.length > 0 ? totalTreasury / daoLaunches.length : 0;
  const growthRate = "+12.5%"; 

  // Chart Data Preparation
  const chartData = daoLaunches.map(dao => ({
      name: dao.name.split(' ').slice(0, 1).join(''), 
      treasury: dao.treasury,
  }));

  const handleInstantDonate = () => {
      // Direct link to specific charity as requested
      window.open('https://donate.lovetotherescue.org/', '_blank');
  };

  return (
    <div className="space-y-6">
      {/* 1. PERMANENT ANALYTICS DASHBOARD */}
      <div className="grid grid-cols-1 xl:grid-cols-4 gap-6 animate-in fade-in duration-700">
          
          {/* Total Value Node */}
          <div className="glass-card p-6 bg-gradient-to-br from-indigo-900/20 via-slate-900 to-slate-950 border-indigo-500/20 relative overflow-hidden group">
              <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
                  <TrendingUp className="w-24 h-24 text-indigo-400" />
              </div>
              <p className="text-xs font-black text-indigo-400 uppercase tracking-[0.2em] mb-3">Total Ecosystem Value</p>
              <div className="flex items-baseline gap-2">
                  <h2 className="text-4xl font-black text-white tracking-tighter">${totalTreasury.toLocaleString()}</h2>
                  <span className="text-xs font-bold text-green-400 bg-green-900/30 px-2 py-0.5 rounded flex items-center gap-1">
                      <ArrowUp className="w-3 h-3" /> {growthRate}
                  </span>
              </div>
              <div className="mt-4 h-1 w-full bg-slate-800 rounded-full overflow-hidden">
                  <div className="h-full bg-indigo-500 w-2/3 animate-pulse"></div>
              </div>
          </div>

          {/* Average Launch Size */}
          <div className="glass-card p-6 bg-slate-900 border-white/5 group">
              <p className="text-xs font-black text-slate-500 uppercase tracking-[0.2em] mb-3">Avg. Launch Liquidity</p>
              <h2 className="text-4xl font-black text-white tracking-tighter">${avgTreasury.toLocaleString(undefined, { maximumFractionDigits: 0 })}</h2>
              <p className="text-[10px] text-slate-500 mt-4 font-mono uppercase">Calculated across {daoLaunches.length} active nodes</p>
          </div>

          {/* Real-time Trend Visualizer */}
          <div className="glass-card p-4 xl:col-span-2 h-[140px] flex items-center bg-black/40">
              <div className="w-full h-full">
                  <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={chartData}>
                          <XAxis dataKey="name" hide />
                          <Tooltip 
                              cursor={{fill: '#334155', opacity: 0.4}}
                              contentStyle={{backgroundColor: '#0f172a', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '12px'}}
                          />
                          <Bar dataKey="treasury" fill="#6366f1" radius={[4, 4, 0, 0]} />
                      </BarChart>
                  </ResponsiveContainer>
              </div>
          </div>
      </div>

      {/* 2. CHARITY DISPATCH CENTER */}
      <div className="glass-card p-0 border border-pink-500/30 overflow-hidden relative shadow-[0_0_50px_rgba(236,72,153,0.05)]">
          <div className="absolute top-0 right-0 w-64 h-64 bg-pink-500/5 rounded-full blur-[80px] -mr-32 -mt-32"></div>
          
          <div className="flex flex-col lg:flex-row items-stretch">
              {/* Dispatch Action */}
              <div className="flex-1 p-8 border-b lg:border-b-0 lg:border-r border-white/5 bg-gradient-to-br from-pink-950/10 to-transparent">
                  <div className="flex items-center gap-3 mb-4">
                      <div className="p-2 bg-pink-500/20 rounded-lg">
                          <Heart className="w-6 h-6 text-pink-400 fill-pink-400" />
                      </div>
                      <h3 className="text-xl font-bold text-white tracking-tight uppercase tracking-widest">Charity Dispatch Hub</h3>
                  </div>
                  <p className="text-slate-400 text-sm mb-6 leading-relaxed max-w-xl">
                      Trigger an instant donation to our Primary Medical Research Partner. 
                      Donors will receive an **official tax receipt via email** directly from the Shriners organization.
                  </p>
                  <div className="flex flex-wrap gap-4">
                      <button 
                          onClick={handleInstantDonate}
                          className="px-8 py-4 bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-500 hover:to-rose-500 text-white rounded-2xl font-black text-sm uppercase tracking-[0.2em] shadow-[0_10px_30px_rgba(225,29,72,0.3)] hover:scale-105 active:scale-95 transition-all flex items-center gap-3 group"
                      >
                          <Zap className="w-5 h-5 fill-white group-hover:animate-bounce" />
                          Execute Instant Impact
                          <ExternalLink className="w-4 h-4 opacity-50" />
                      </button>
                  </div>
              </div>

              {/* Mobile QR Gateway */}
              <div className="w-full lg:w-72 p-8 bg-black/60 flex flex-col items-center justify-center text-center">
                  <div className="relative p-3 bg-white rounded-2xl mb-4 group cursor-pointer hover:scale-105 transition-transform">
                      <QrCode className="w-24 h-24 text-slate-900" />
                      <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                          <div className="bg-pink-600 text-white text-[8px] font-black px-2 py-1 rounded-full shadow-lg">SCAN TO DONATE</div>
                      </div>
                  </div>
                  <span className="text-[10px] font-black text-pink-500 uppercase tracking-widest">Mobile Impact Key</span>
                  <p className="text-[9px] text-slate-500 mt-2 italic">Point camera for rapid life-saving support</p>
              </div>
          </div>
      </div>

      {/* 3. REGISTRY TABLE */}
      <div className="glass-card overflow-hidden border border-white/5">
        <div className="p-5 border-b border-white/10 flex justify-between items-center bg-white/5">
          <div className="flex items-center gap-3">
              <Activity className="w-5 h-5 text-indigo-400" />
              <h3 className="font-bold text-white text-lg tracking-tight">Active Launch Registry</h3>
          </div>
          {onAdd && (
              <button onClick={onAdd} disabled={isLoading} className="flex items-center px-4 py-2 bg-indigo-600/20 hover:bg-indigo-600 text-indigo-400 hover:text-white text-xs font-bold rounded-xl transition-all border border-indigo-500/30 shadow-lg">
                  <Plus className="w-3.5 h-3.5 mr-2" />
                  INITIATE NEW NODE
              </button>
          )}
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left text-slate-400">
            <thead className="text-[10px] text-slate-500 uppercase bg-black/40 font-black tracking-[0.2em]">
              <tr>
                <th scope="col" className="px-6 py-5">Sovereign Node</th>
                <th scope="col" className="px-6 py-5">Native Asset</th>
                <th scope="col" className="px-6 py-5">Vault Value</th>
                <th 
                  scope="col" 
                  className="px-6 py-5 cursor-pointer hover:text-white group select-none transition-colors" 
                  onClick={() => requestSort('launchDate')}
                >
                  <div className="flex items-center">
                    Launch Cycle
                    <span className="ml-2 flex items-center">
                      {sortConfig?.key === 'launchDate' ? (
                          sortConfig.direction === 'asc' ? <ArrowUp className="w-3.5 h-3.5 text-indigo-400" /> : <ArrowDown className="w-3.5 h-3.5 text-indigo-400" />
                      ) : (
                          <Activity className="w-3.5 h-3.5 opacity-20 group-hover:opacity-100 transition-opacity" />
                      )}
                    </span>
                  </div>
                </th>
                <th scope="col" className="px-6 py-5 text-center">Governance Proposals</th>
                <th scope="col" className="px-6 py-5 text-right">Audit Command</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {isLoading ? (
                 Array.from({ length: 4 }).map((_, i) => (
                   <tr key={i} className="animate-pulse">
                      <td className="px-6 py-6"><div className="h-4 bg-slate-800 rounded w-32"></div></td>
                      <td className="px-6 py-6"><div className="h-4 bg-slate-800 rounded w-16"></div></td>
                      <td className="px-6 py-6"><div className="h-4 bg-slate-800 rounded w-24"></div></td>
                      <td className="px-6 py-6"><div className="h-4 bg-slate-800 rounded w-24"></div></td>
                      <td className="px-6 py-6 text-center"><div className="h-4 bg-slate-800 rounded w-8 mx-auto"></div></td>
                      <td className="px-6 py-6 text-right"><div className="h-8 bg-slate-800 rounded w-20 ml-auto"></div></td>
                   </tr>
                 ))
              ) : sortedDaos.length === 0 ? (
                  <tr>
                      <td colSpan={6} className="px-6 py-12 text-center text-slate-500 italic font-mono uppercase text-xs tracking-widest">
                          [ NO REGISTRY NODES DETECTED ]
                      </td>
                  </tr>
              ) : (
                  sortedDaos.map((dao) => (
                    <tr key={dao.id} className="hover:bg-indigo-600/5 transition-all group">
                      <td className="px-6 py-5 font-black text-white whitespace-nowrap">
                          {dao.name}
                      </td>
                      <td className="px-6 py-5">
                          <span className="font-mono text-indigo-400 text-[10px] bg-indigo-500/10 px-2 py-1 rounded border border-indigo-500/20 font-bold uppercase">
                              {dao.token}
                          </span>
                      </td>
                      <td className="px-6 py-5 font-mono text-emerald-400 font-black">
                          ${dao.treasury.toLocaleString()}
                      </td>
                      <td className="px-6 py-5 text-slate-400 font-mono text-xs">
                          {new Date(dao.launchDate).toLocaleDateString()}
                      </td>
                      <td className="px-6 py-5 text-center">
                        {dao.proposals === null ? (
                          <div className="flex justify-center">
                            <div className="w-4 h-4 border-2 border-slate-700 border-t-indigo-500 rounded-full animate-spin"></div>
                          </div>
                        ) : (
                          <span className="text-white font-black font-mono">{dao.proposals}</span>
                        )}
                      </td>
                      <td className="px-6 py-5 text-right">
                        <button
                          onClick={() => onAnalyze(dao)}
                          className="inline-flex items-center justify-center px-4 py-2 text-[10px] font-black text-slate-300 hover:text-white bg-white/5 hover:bg-indigo-600/20 rounded-xl transition-all border border-white/5 hover:border-indigo-500/40 uppercase tracking-widest"
                        >
                          <Sparkles className="w-3.5 h-3.5 mr-2 text-indigo-400 group-hover:scale-125 transition-transform" />
                          Mission Audit
                        </button>
                      </td>
                    </tr>
                  ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default DaoTable;
