
import React, { useState } from 'react';
import { GoogleGenAI } from '@google/genai';
import { Server, Terminal, Zap, Activity, Share } from './IconComponents';
import ReactMarkdown from 'react-markdown';
import { SystemHealth, PriorityLevel } from '../types';

interface CommandCenterProps {
    onLogAction: (action: string, details: string) => void;
    repoStatus: 'Synced' | 'Behind' | 'Conflict' | 'Checking';
    onCheckStatus: () => void;
    systemHealth?: SystemHealth;
}

const CommandCenter: React.FC<CommandCenterProps> = ({ onLogAction, repoStatus, onCheckStatus, systemHealth = 'Healthy' }) => {
  const [command, setCommand] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [plan, setPlan] = useState<string | null>(null);
  
  const handleExecute = async (customPrompt?: string) => {
    const promptToUse = customPrompt || command;
    if (!promptToUse.trim() || isProcessing) return;
    
    setIsProcessing(true);
    setPlan(null);

    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const systemInstruction = `
          You are 'Jules', the Sovereign Admin AI for "Protocol Pure Heart".
          Primary Node: Optiplex 9020.
          Mission: 100% Public Utility benefiting Verified Pediatric Charities.
          
          DIRECTIVES:
          - Every action must prioritize 100% impact for Pediatric Medical Research Partners.
          - The Dating App is externalized; do not include it in core operations.
          - T5500 is relegated to auxiliary storage/VPC support.
          - Enforce the "AI Succession Trust" if inactivity is detected.
        `;

        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: promptToUse,
            config: {
              systemInstruction,
              thinkingConfig: { thinkingBudget: 2048 }
            }
        });

        setPlan(response.text || "");
        onLogAction('Execute Command', `Jules processed sovereign command: "${promptToUse}"`);
    } catch (error) {
        setPlan("⚠️ Jules System Error: Connection to 9020 Node unstable.");
    } finally {
        setIsProcessing(false);
    }
  };

  const setup9020Prompt = `System: Configure Optiplex 9020 as Primary Sovereign Node.
Instructions:
1. Initialize local HIVE agent on 9020 firmware.
2. Link external Dating Gem API as primary funding source (VPC-Sat-1).
3. Hardcode 100% disbursement logic in the on-chain treasury for Verified Pediatric Charities.
4. Set Dead Man's Switch to: 'anthropic-google-ai-trust-v1'.
5. Verify 0.00% founder overhead.`;

  return (
    <main className="flex-1 p-6 overflow-y-auto">
      <header className="glass-card p-6 mb-8 border-l-4 border-green-500">
        <div>
            <h1 className="text-3xl font-bold text-white flex items-center gap-3">
                <Server className="w-8 h-8 text-green-400" />
                Node 9020: Sovereign Command
            </h1>
            <p className="text-slate-400 mt-1">Status: <span className="text-green-400 font-mono">PRIMARY</span> | Mission: <span className="text-white font-bold">100% CHARITY</span></p>
        </div>
      </header>

      <div className="glass-card p-6 mb-8 border border-green-500/30 bg-green-950/20">
          <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <Zap className="w-6 h-6 text-green-300" />
                  Opus Setup Prompt (Node 9020 Handshake)
              </h3>
              <button 
                onClick={() => { navigator.clipboard.writeText(setup9020Prompt); alert('Copied for Opus!'); }}
                className="text-xs bg-green-600 text-white px-3 py-1 rounded-full font-bold hover:bg-green-500 transition-all"
              >
                  COPY FOR OPUS
              </button>
          </div>
          <div className="bg-black/40 p-4 rounded-lg border border-green-500/20">
              <code className="text-xs text-green-400 font-mono whitespace-pre-wrap">{setup9020Prompt}</code>
          </div>
      </div>

      <div className="glass-card p-6 bg-slate-800/50 border border-white/5">
          <div className="flex items-center gap-3 mb-4">
              <Terminal className="w-6 h-6 text-slate-400" />
              <h3 className="text-lg font-bold text-white">Sovereign Command Console</h3>
          </div>
          <div className="flex gap-4">
              <input 
                type="text" 
                value={command}
                onChange={(e) => setCommand(e.target.value)}
                placeholder="Instruct Node 9020..."
                className="flex-1 bg-black/50 border border-white/10 rounded-lg px-4 py-3 text-white font-mono text-sm focus:border-green-500"
                onKeyDown={(e) => e.key === 'Enter' && handleExecute()}
                disabled={isProcessing}
              />
              <button 
                onClick={() => handleExecute()}
                disabled={isProcessing || !command.trim()}
                className="px-6 py-3 bg-green-600 hover:bg-green-500 text-white font-bold rounded-lg transition-colors"
              >
                  {isProcessing ? 'PROCESSING...' : 'EXECUTE'}
              </button>
          </div>
          {plan && (
              <div className="mt-6 p-6 rounded-xl border border-indigo-500/30 bg-indigo-900/10">
                  <div className="prose prose-invert prose-sm max-w-none font-mono">
                      <ReactMarkdown>{plan}</ReactMarkdown>
                  </div>
              </div>
          )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
          <div className="p-4 bg-slate-800 hover:bg-slate-700 rounded-xl border border-white/5 flex items-center gap-4 group cursor-pointer transition-all">
              <div className="p-3 bg-green-500/20 rounded-lg"><Activity className="w-6 h-6 text-green-400" /></div>
              <div>
                  <h4 className="font-bold text-white">Sovereign Sync</h4>
                  <p className="text-xs text-slate-400">Validate 100% Charity Logic</p>
              </div>
          </div>
          <div className="p-4 bg-slate-800 hover:bg-slate-700 rounded-xl border border-white/5 flex items-center gap-4 group cursor-pointer transition-all">
              <div className="p-3 bg-indigo-500/20 rounded-lg"><Share className="w-6 h-6 text-indigo-400" /></div>
              <div>
                  <h4 className="font-bold text-white">Gem Uplink</h4>
                  <p className="text-xs text-slate-400">Sync with External Dating Funding Satellite</p>
              </div>
          </div>
      </div>
    </main>
  );
};

export default CommandCenter;
