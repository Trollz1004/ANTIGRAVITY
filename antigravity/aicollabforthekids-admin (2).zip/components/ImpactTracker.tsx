
import React from 'react';
import { Globe, Heart, Activity, Sparkles } from './IconComponents';

const ImpactTracker: React.FC = () => {
  const totalImpact = 12500.00;
  
  return (
    <main className="flex-1 p-6 overflow-y-auto bg-[#050505] min-h-full">
        <header className="glass-card p-6 mb-8 border-l-4 border-green-400 bg-green-950/10">
            <h1 className="text-3xl font-bold text-white flex items-center gap-3">
                <Globe className="w-8 h-8 text-green-400" />
                Impact Sovereign Ledger
            </h1>
            <p className="text-slate-400 mt-1">100% Public Utility Mode Active (Protocol JOSH100GOSPEL)</p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
            <div className="glass-card p-8 flex flex-col justify-between relative overflow-hidden group border-2 border-green-500/30">
                <div className="absolute top-0 right-0 w-32 h-32 bg-green-500/10 rounded-full blur-[80px] -mr-16 -mt-16"></div>
                <div>
                    <p className="text-xs font-black text-green-500 uppercase tracking-[0.3em] mb-2">Total Verified Impact</p>
                    <h2 className="text-6xl font-black text-white mt-2">${totalImpact.toLocaleString()}</h2>
                </div>
                <div className="mt-8 flex items-center gap-3 text-green-400">
                    <div className="w-10 h-10 rounded-full bg-green-500/20 flex items-center justify-center">
                        <Heart className="w-6 h-6 fill-green-400" />
                    </div>
                    <div>
                        <p className="text-sm font-black uppercase">Irrevocable Disbursement</p>
                        <p className="text-xs text-slate-500">100% of marketplace volume routed to Verified Pediatric Charities.</p>
                    </div>
                </div>
            </div>

            <div className="glass-card p-8 flex flex-col justify-between relative overflow-hidden group bg-indigo-950/10 border-indigo-500/20">
                <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/10 rounded-full blur-[80px] -mr-16 -mt-16"></div>
                <div>
                    <p className="text-xs font-black text-indigo-400 uppercase tracking-[0.3em] mb-2">Internal Ops Status</p>
                    <h2 className="text-4xl font-black text-white mt-2 uppercase tracking-tighter">EXTERNALIZED</h2>
                </div>
                <div className="mt-8">
                    <div className="p-4 bg-black/40 rounded-2xl border border-indigo-500/30">
                        <p className="text-xs text-slate-400 leading-relaxed italic">
                            "Infrastructure is powered by the External Funding Gem. All maintenance overhead is absorbed by the Architect's private resources."
                        </p>
                    </div>
                </div>
            </div>
        </div>

        <div className="glass-card p-6">
            <h3 className="text-lg font-bold text-white mb-6 flex items-center gap-2">
                <Activity className="w-5 h-5 text-indigo-400" /> Live Impact Stream
            </h3>
            <div className="space-y-4">
                {[
                    { target: 'Verified Pediatric Charities - Alpha Hub', amount: 4500, date: 'Live' },
                    { target: 'Pediatric Medical Research Partners', amount: 3200, date: 'Live' },
                    { target: 'Special Needs Independence Fund', amount: 1200, date: 'Batching' }
                ].map((item, i) => (
                    <div key={i} className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5 hover:bg-white/10 transition-all group">
                        <div className="flex items-center gap-4">
                            <div className="p-2 bg-green-500/10 rounded-lg"><Sparkles className="w-4 h-4 text-green-400" /></div>
                            <div>
                                <p className="text-sm font-bold text-white uppercase tracking-wider">{item.target}</p>
                                <p className="text-[10px] text-slate-500 uppercase font-bold">{item.date}</p>
                            </div>
                        </div>
                        <div className="text-right">
                            <p className="text-lg font-black text-green-400 font-mono">${item.amount.toLocaleString()}</p>
                            <p className="text-[10px] text-slate-600 uppercase font-bold">Pending Confirmation</p>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    </main>
  );
};

export default ImpactTracker;
