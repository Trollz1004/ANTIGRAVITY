
import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI, Modality, Type } from '@google/genai';
import { BookOpen, Palette, Headphones, Smile, Sparkles, ShieldCheck, Heart, CheckCircle, ShieldAlert, Play, Pause, Mic, Download, Printer, FileText, FileAudio, FileImage, Zap, ClipboardList, Activity } from './IconComponents';
import ReactMarkdown from 'react-markdown';

// --- Utility Functions ---
function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

const AudioVisualizer: React.FC<{ isPlaying: boolean }> = ({ isPlaying }) => {
    return (
        <div className="flex items-center gap-1 h-8">
            {[...Array(8)].map((_, i) => (
                <div 
                    key={i}
                    className={`w-1.5 bg-indigo-400 rounded-full transition-all duration-150 ${isPlaying ? 'animate-pulse' : 'h-1 opacity-50'}`}
                    style={{ 
                        height: isPlaying ? `${Math.random() * 100}%` : '4px',
                        animationDelay: `${i * 0.1}s` 
                    }}
                />
            ))}
        </div>
    );
};

const LifeSkillsStudio: React.FC = () => {
    const [topic, setTopic] = useState('');
    const [skillLevel, setSkillLevel] = useState('Foundational');
    const [plan, setPlan] = useState<string | null>(null);
    const [imageUrl, setImageUrl] = useState<string | null>(null);
    const [audioBuffer, setAudioBuffer] = useState<AudioBuffer | null>(null);
    const [status, setStatus] = useState<string>('');
    const [isPlaying, setIsPlaying] = useState(false);
    const [isListening, setIsListening] = useState(false);
    
    const audioContextRef = useRef<AudioContext | null>(null);
    const audioSourceRef = useRef<AudioBufferSourceNode | null>(null);

    const handleCreate = async () => {
        if (!topic.trim()) return;
        
        setStatus('🧬 Generating Independence Protocol...');
        setPlan(null);
        setImageUrl(null);
        setAudioBuffer(null);
        setIsPlaying(false);
        
        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

            // 1. Generate Independence Plan
            const prompt = `Act as a specialized Life Skills Coach for neurodiverse individuals. 
            Create a step-by-step, highly visual, and encouraging instruction guide for: "${topic}". 
            Skill Level: ${skillLevel}. 
            Dedication: This is for a platform inspired by Joshua Coleman's handicapped brother. 
            Keep steps simple, use visual language, and add a "Victory Celebration" note at the end.`;
            
            const response = await ai.models.generateContent({
                model: 'gemini-3-flash-preview',
                contents: prompt,
                config: { thinkingConfig: { thinkingBudget: 2048 } } 
            });
            const planText = response.text || "Loading steps...";
            setPlan(planText);

            // 2. Visual Anchor (Imagen 4)
            setStatus('🎨 Creating Visual Anchor...');
            const imageResponse = await ai.models.generateImages({
                model: 'imagen-4.0-generate-001',
                prompt: `A friendly, clear, high-contrast visual aid for learning the task: ${topic}. Soft lighting, clean lines, encouraging and bright. 16:9 aspect ratio.`,
                config: { numberOfImages: 1, aspectRatio: '16:9' }
            });
            
            if (imageResponse.generatedImages?.[0]?.image?.imageBytes) {
                setImageUrl(`data:image/png;base64,${imageResponse.generatedImages[0].image.imageBytes}`);
            }

            // 3. Audio Guidance
            setStatus('🎙️ Recording Voice Guide...');
            const speechResponse = await ai.models.generateContent({
                model: 'gemini-2.5-flash-preview-tts',
                contents: { parts: [{ text: `Let's work together on: ${topic}. Follow these steps carefully. You are doing a great job!` }] },
                config: {
                    responseModalities: [Modality.AUDIO],
                    speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } } } 
                }
            });

            const audioBytes = speechResponse.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
            if (audioBytes) {
                const rawBytes = decode(audioBytes);
                if (!audioContextRef.current) {
                    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
                    audioContextRef.current = new AudioContextClass({ sampleRate: 24000 });
                }
                const buffer = await decodeAudioData(rawBytes, audioContextRef.current, 24000, 1);
                setAudioBuffer(buffer);
            }

            setStatus('');
        } catch (error) {
            console.error(error);
            setStatus('❌ Error Generating Protocol.');
        }
    };

    const toggleAudio = () => {
        if (isPlaying) {
            audioSourceRef.current?.stop();
            setIsPlaying(false);
        } else if (audioBuffer && audioContextRef.current) {
            const source = audioContextRef.current.createBufferSource();
            source.buffer = audioBuffer;
            source.connect(audioContextRef.current.destination);
            source.onended = () => setIsPlaying(false);
            source.start();
            audioSourceRef.current = source;
            setIsPlaying(true);
        }
    };

    return (
        <main className="flex-1 p-6 overflow-y-auto bg-slate-900 min-h-full">
            <header className="glass-card p-6 mb-8 border-l-4 border-indigo-500">
                <div className="flex justify-between items-center">
                    <div>
                        <h1 className="text-3xl font-bold text-white flex items-center gap-3">
                            <Activity className="w-8 h-8 text-indigo-400" />
                            Independence Studio
                        </h1>
                        <p className="text-slate-400 mt-1">Specialized Life Skills Training for Neurodiversity & Disabilities.</p>
                    </div>
                    <div className="px-4 py-2 bg-indigo-500/10 border border-indigo-500/20 rounded-full text-xs font-black text-indigo-400 uppercase tracking-widest">
                        Handicapable Protocol
                    </div>
                </div>
            </header>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="glass-card p-6 lg:col-span-1 h-fit border-t-4 border-indigo-500">
                    <h3 className="text-lg font-bold text-white mb-4">Goal Definition</h3>
                    <div className="space-y-4">
                        <div>
                            <label className="block text-sm font-medium text-slate-400 mb-1">Independence Task</label>
                            <input 
                                type="text" 
                                value={topic}
                                onChange={(e) => setTopic(e.target.value)}
                                placeholder="e.g. Setting the table, Washing clothes..."
                                className="glass-input w-full p-3"
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-slate-400 mb-1">Adaptive Level</label>
                            <select 
                                value={skillLevel}
                                onChange={(e) => setSkillLevel(e.target.value)}
                                className="glass-input w-full p-3"
                            >
                                <option value="Foundational">Foundational (Visual Cues)</option>
                                <option value="Supported">Supported (Text + Audio)</option>
                                <option value="Independent">Independent (Checklist Only)</option>
                            </select>
                        </div>
                        <button 
                            onClick={handleCreate}
                            disabled={!!status}
                            className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold shadow-lg flex items-center justify-center gap-2 transition-all disabled:opacity-50"
                        >
                            {status ? <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div> : <Sparkles className="w-5 h-5" />}
                            Create Studio Plan
                        </button>
                        {status && <p className="text-center text-indigo-300 text-sm animate-pulse">{status}</p>}
                    </div>
                </div>

                <div className="lg:col-span-2 space-y-6">
                    {imageUrl && (
                        <div className="glass-card p-2 rounded-3xl border border-white/10 shadow-2xl animate-in zoom-in duration-500">
                            <img src={imageUrl} alt="Visual Anchor" className="w-full rounded-[20px]" />
                        </div>
                    )}

                    {plan ? (
                        <div className="glass-card p-8 border-l-8 border-indigo-500 bg-white/5 relative overflow-hidden animate-in slide-in-from-bottom-4">
                            <div className="flex justify-between items-center mb-6">
                                <h2 className="text-3xl font-black text-white uppercase tracking-tighter">{topic}</h2>
                                {audioBuffer && (
                                    <button 
                                        onClick={toggleAudio}
                                        className={`w-12 h-12 flex items-center justify-center rounded-full shadow-lg transition-all ${isPlaying ? 'bg-red-500' : 'bg-indigo-600'}`}
                                    >
                                        {isPlaying ? <Pause className="w-5 h-5 text-white" /> : <Play className="w-5 h-5 text-white ml-1" />}
                                    </button>
                                )}
                            </div>
                            <div className="prose prose-invert prose-lg max-w-none text-slate-300">
                                <ReactMarkdown>{plan}</ReactMarkdown>
                            </div>
                            <div className="mt-8 pt-6 border-t border-white/10 flex justify-between items-center">
                                <span className="text-xs font-black text-slate-600 uppercase tracking-widest">Coleman Protocol v4.0</span>
                                <div className="flex gap-2">
                                    <button className="p-2 bg-slate-800 rounded hover:bg-slate-700"><Printer className="w-4 h-4 text-slate-400" /></button>
                                    <button className="p-2 bg-slate-800 rounded hover:bg-slate-700"><Download className="w-4 h-4 text-slate-400" /></button>
                                </div>
                            </div>
                        </div>
                    ) : (
                        <div className="glass-card p-12 flex flex-col items-center justify-center text-slate-600 border-dashed border-2 border-white/10 min-h-[300px]">
                            <ClipboardList className="w-16 h-16 mb-4 opacity-10" />
                            <p className="font-bold">Awaiting Task Initiation</p>
                            <p className="text-sm mt-2">Generate a plan to see adaptive independence tools.</p>
                        </div>
                    )}
                </div>
            </div>
        </main>
    );
};

export default LifeSkillsStudio;
