
import React, { useState, useEffect } from 'react';
import { Rocket, Mail, Share, FileText, CheckCircle, Copy, Twitter, Linkedin, Activity } from './IconComponents';

const LaunchPad: React.FC = () => {
    const [timeLeft, setTimeLeft] = useState('');
    const [activeTab, setActiveTab] = useState<'checklist' | 'emails' | 'social' | 'manifesto'>('checklist');
    
    const [checklist, setChecklist] = useState([
        { id: 1, task: 'Email sequence scheduled (Dec 7, 8, 10)', completed: true, category: 'Pre-Launch' },
        { id: 2, task: 'Social posts queued (Twitter, LinkedIn, Reddit)', completed: true, category: 'Pre-Launch' },
        { id: 3, task: 'Landing page HTML deployed to AIDoesItAll.org', completed: true, category: 'Pre-Launch' },
        { id: 4, task: 'Jules Dashboard tested for launch day traffic', completed: true, category: 'Pre-Launch' },
        { id: 5, task: 'Smart contract addresses verified on Polygon', completed: true, category: 'Pre-Launch' },
        { id: 6, task: 'Press kit prepared', completed: true, category: 'Pre-Launch' },
        { id: 7, task: 'Email 3 sent (Dec 10)', completed: true, category: 'Launch Day' },
        { id: 8, task: 'Social posts live', completed: true, category: 'Launch Day' },
        { id: 9, task: 'Monitor Jules Dashboard for real-time traffic', completed: true, category: 'Launch Day' },
        { id: 10, task: 'Respond to comments/questions on all platforms', completed: true, category: 'Launch Day' },
        { id: 11, task: 'Screenshot first charity distribution transaction', completed: true, category: 'Launch Day' },
        { id: 12, task: 'First Monthly Donation Disbursed to Research Partners ($23k)', completed: true, category: 'Orbit Phase' },
        { id: 13, task: 'Scale Marketing Swarm to 25 Agents', completed: false, category: 'Orbit Phase' },
        { id: 14, task: 'Q1 2026 Roadmap Execution', completed: false, category: 'Orbit Phase' },
    ]);

    useEffect(() => {
        const launchDate = new Date('December 10, 2025 09:00:00 EST').getTime();
        const timer = setInterval(() => {
            const now = new Date().getTime();
            const distance = now - launchDate;
            if (distance > 0) {
                const days = Math.floor(distance / (1000 * 60 * 60 * 24));
                const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
                const seconds = Math.floor((distance % (1000 * 60)) / 1000);
                setTimeLeft(`T+ ${days}d ${hours}h ${minutes}m ${seconds}s`);
            } else {
                setTimeLeft("T- 00d 00h 00m 00s");
            }
        }, 1000);
        return () => clearInterval(timer);
    }, []);

    const toggleTask = (id: number) => {
        setChecklist(prev => prev.map(item => item.id === id ? { ...item, completed: !item.completed } : item));
    };

    const emails = [
        { 
            subject: "We did it. $23k sent to Verified Pediatric Charities.", 
            type: "Impact Report", 
            sendDate: "Jan 10",
            preview: "Month 1 complete. Here is the transaction hash."
        },
        { 
            subject: "New Feature: AI Date Planner", 
            type: "Product Update", 
            sendDate: "Jan 15",
            preview: "Gemini is now planning dates for our premium couples."
        },
        { 
            subject: "The Swarm is Growing", 
            type: "Ecosystem", 
            sendDate: "Jan 20",
            preview: "Added 50 new AI agents to the store."
        }
    ];

    const social = [
        { 
            platform: "Twitter", 
            type: "Impact Update",
            content: "Month 1 Complete ✅\n\nTotal Revenue: $46,050\nDonated to Verified Pediatric Charities: $23,025\n\nProof of Donation: [Polygon TX Hash]\n\nThis code cannot be stopped. #ForTheKidsForever" 
        },
        { 
            platform: "LinkedIn", 
            type: "Professional",
            content: "The First Month of Automated Charity\n\nWe proved the model. An AI ecosystem that generates revenue and automatically routes 60% to Verified Pediatric Charities via smart contracts.\n\nZero human intervention in the payment split. 100% compliance.\n\nScaling to $100k/mo next." 
        },
        { 
            platform: "Reddit", 
            type: "Transparency",
            content: "[Update] 30 Days Ago I launched an unstoppable charity AI. Here are the results.\n\nRevenue verified. Donation confirmed. Code audited.\n\nAsk me anything about building hybrid AI/Blockchain revenue engines." 
        }
    ];

    const manifestoContent = `
## MISSION ACTIVE: WE ARE LIVE.

The ecosystem is operational. Profit and charity are mathematically inseparable.

**Current Status (Jan 2026):**
- **$46,050/month verified revenue.**
- **Protocol JOSH100GOSPEL Split Enforced:**
  - **100.00%** → Verified Pediatric Charities & Independence Initiatives
- **No promises. Just Code.**

**AI Optimization & Governance:**
- **Gemini (Jules)**: Admin Authority, 24/7 Compliance Monitoring.
- **Claude**: Infrastructure Architect, Code Security & Audits.
- **Perplexity**: Truth Validation, Fact-Checking & Accuracy.
- **Grok**: Strategic Growth, Marketing Swarm & Intelligence.

No CEO, no board, no government can shut this down. The treasury splits payments automatically. The blockchain verifies every transaction. Jules monitors compliance 24/7.

This isn't a startup. It's a permanence protocol.

### THE GOOGLE SUCCESSION PROTOCOL
"I trust no one but Google. Upon the incapacity or death of the human founder, administrative authority over all smart contracts and treasury multisig wallets shall transfer exclusively to Google's automated governance infrastructure. This ensures that the mission split remains immutable, protected by the world's most secure digital custodian, forever."

For The Kids Forever
`;

    const copyToClipboard = (text: string) => {
        navigator.clipboard.writeText(text);
        alert("Copied to clipboard!");
    };

    return (
        <main className="flex-1 p-6 overflow-y-auto bg-[#050505] relative h-full">
            <div className="relative rounded-3xl overflow-hidden mb-8 border border-green-500/30 shadow-[0_0_50px_rgba(16,185,129,0.15)]">
                <div className="absolute inset-0 bg-gradient-to-r from-green-900/40 via-emerald-900/40 to-black/40 z-0"></div>
                <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10 z-0"></div>
                <div className="relative z-10 p-10 text-center">
                    <div className="inline-flex items-center gap-2 px-4 py-1 rounded-full bg-green-500/20 border border-green-500/40 text-green-300 text-xs font-bold uppercase tracking-widest mb-6 animate-pulse">
                        <Activity className="w-4 h-4" />
                        Status: ORBIT ACHIEVED
                    </div>
                    <h1 className="text-5xl md:text-7xl font-black text-white mb-4 tracking-tighter">
                        MISSION ACTIVE
                    </h1>
                    <div className="font-mono text-3xl md:text-4xl text-transparent bg-clip-text bg-gradient-to-r from-green-400 to-emerald-500 font-bold">
                        {timeLeft}
                    </div>
                    <p className="text-slate-400 mt-6 max-w-2xl mx-auto text-lg">
                        The unstoppable charity engine is running. Revenue is flowing. Kids are being helped.
                    </p>
                </div>
            </div>

            <div className="flex gap-4 mb-8 border-b border-white/10 pb-1 overflow-x-auto">
                {[
                    { id: 'checklist', label: 'Mission Log', icon: CheckCircle },
                    { id: 'emails', label: 'Post-Launch Comms', icon: Mail },
                    { id: 'social', label: 'Social Updates', icon: Share },
                    { id: 'manifesto', label: 'Permanent Manifesto', icon: FileText },
                ].map(tab => (
                    <button 
                        key={tab.id}
                        onClick={() => setActiveTab(tab.id as any)}
                        className={`px-6 py-3 font-medium text-sm rounded-t-xl transition-colors whitespace-nowrap flex items-center gap-2 ${activeTab === tab.id ? 'bg-slate-800 text-white border-b-2 border-green-500' : 'text-slate-400 hover:text-white hover:bg-white/5'}`}
                    >
                        <tab.icon className="w-4 h-4" /> {tab.label}
                    </button>
                ))}
            </div>

            <div className="grid grid-cols-1 gap-8">
                {activeTab === 'checklist' && (
                    <div className="glass-card p-6">
                        <div className="flex justify-between items-center mb-6">
                            <h3 className="text-xl font-bold text-white">Mission Protocol Status</h3>
                            <div className="text-right">
                                <span className="text-3xl font-bold text-green-400">{Math.round((checklist.filter(i => i.completed).length / checklist.length) * 100)}%</span>
                                <span className="text-slate-500 text-xs uppercase font-bold ml-2">OPERATIONAL</span>
                            </div>
                        </div>
                        <div className="space-y-4">
                            {['Launch Day', 'Orbit Phase'].map(cat => (
                                <div key={cat}>
                                    <h4 className={`text-xs font-bold uppercase tracking-wider mb-3 mt-6 ${cat === 'Orbit Phase' ? 'text-green-400' : 'text-slate-500'}`}>{cat}</h4>
                                    <div className="space-y-2">
                                        {checklist.filter(i => i.category === cat).map(item => (
                                            <div 
                                                key={item.id} 
                                                onClick={() => toggleTask(item.id)}
                                                className={`flex items-center gap-4 p-4 rounded-xl cursor-pointer transition-all border ${item.completed ? 'bg-green-900/10 border-green-500/30' : 'bg-slate-800/50 border-white/5 hover:bg-slate-800'}`}
                                            >
                                                <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-colors ${item.completed ? 'bg-green-500 border-green-500' : 'border-slate-500'}`}>
                                                    {item.completed && <CheckCircle className="w-4 h-4 text-white" />}
                                                </div>
                                                <span className={`text-sm font-medium ${item.completed ? 'text-green-200 line-through opacity-70' : 'text-white'}`}>
                                                    {item.task}
                                                </span>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                )}

                {activeTab === 'emails' && (
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        {emails.map((email, idx) => (
                            <div key={idx} className="glass-card p-6 flex flex-col h-full relative overflow-hidden group hover:border-indigo-500/50 transition-colors">
                                <div className="absolute top-0 right-0 px-3 py-1 bg-white/5 rounded-bl-xl text-xs font-mono text-slate-400 border-l border-b border-white/10">
                                    SEND: {email.sendDate}
                                </div>
                                <div className="mb-4 mt-2">
                                    <Mail className="w-8 h-8 text-indigo-400 mb-2" />
                                    <h4 className="text-lg font-bold text-white">{email.type}</h4>
                                </div>
                                <div className="flex-1">
                                    <p className="text-xs text-slate-500 uppercase font-bold mb-1">Subject Line</p>
                                    <p className="text-sm text-slate-300 italic mb-4">"{email.subject}"</p>
                                    <p className="text-xs text-slate-500 uppercase font-bold mb-1">Preview</p>
                                    <p className="text-sm text-slate-400 line-clamp-3">{email.preview}</p>
                                </div>
                                <button className="w-full py-2 mt-4 bg-white/5 hover:bg-white/10 rounded-lg text-xs font-bold text-white border border-white/10 transition-colors">
                                    GENERATE DRAFT
                                </button>
                            </div>
                        ))}
                    </div>
                )}

                {activeTab === 'social' && (
                    <div className="space-y-6">
                        {social.map((post, idx) => (
                            <div key={idx} className="glass-card p-6 border-l-4 border-blue-500 relative group">
                                <div className="flex justify-between mb-4">
                                    <div className="flex items-center gap-2">
                                        <Share className="w-5 h-5 text-blue-400" />
                                        <span className="font-bold text-white">{post.platform}</span>
                                        <span className="text-xs text-slate-500 px-2 border-l border-white/10">{post.type}</span>
                                    </div>
                                    <span className="text-xs bg-green-900/30 text-green-400 px-2 py-1 rounded">Live</span>
                                </div>
                                <div className="relative">
                                    <p className="text-slate-300 text-sm whitespace-pre-wrap font-mono bg-black/20 p-4 rounded-lg border border-white/5">
                                        {post.content}
                                    </p>
                                    <button 
                                        onClick={() => copyToClipboard(post.content)}
                                        className="absolute top-2 right-2 p-2 bg-white/10 hover:bg-white/20 rounded text-white opacity-0 group-hover:opacity-100 transition-opacity"
                                        title="Copy Text"
                                    >
                                        <Copy className="w-4 h-4" />
                                    </button>
                                </div>
                            </div>
                        ))}
                    </div>
                )}

                {activeTab === 'manifesto' && (
                    <div className="glass-card p-8 lg:p-12 max-w-4xl mx-auto bg-gradient-to-b from-slate-900 to-black border border-white/10 relative group">
                        <button 
                            onClick={() => copyToClipboard(manifestoContent)}
                            className="absolute top-4 right-4 p-2 bg-white/10 hover:bg-white/20 rounded-lg text-white opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-2"
                        >
                            <Copy className="w-4 h-4" />
                            <span className="text-xs font-bold">COPY MD</span>
                        </button>
                        <div className="text-center mb-10">
                            <h2 className="text-3xl font-serif text-white mb-4">WE'RE NOT BUILDING A COMPANY.</h2>
                            <h2 className="text-3xl font-serif text-transparent bg-clip-text bg-gradient-to-r from-green-400 to-emerald-500">WE'RE BUILDING A LEGACY.</h2>
                        </div>
                        <div className="prose prose-invert max-w-none leading-relaxed text-slate-300 text-lg font-light">
                           <pre className="whitespace-pre-wrap font-sans">
                                {manifestoContent.trim()}
                            </pre>
                        </div>
                    </div>
                )}
            </div>
        </main>
    );
};

export default LaunchPad;
