
import React, { useState } from 'react';
import { Terminal, Copy, CheckCircle, Download, ShieldCheck, Server, Zap, Globe, Heart } from './IconComponents';

// T5500 Deployment Script (OPUS-HIVE)
const T5500_SCRIPT = `<#
.SYNOPSIS
    OPUS-HIVE MASTER DEPLOYMENT SCRIPT (T5500)
    Integrates AI Studios Dashboard, Valentine's Day Launch, and User Cards.

.DESCRIPTION
    Orchestrates the startup of all AiCollabForTheKids services on the Production Node (T5500).
    Ensures Gospel V1.3 Compliance (60% Split).
#>

$ErrorActionPreference = "Stop"
$RootPath = "C:\\AiCollabForTheKids"

function Write-Status ($Message, $Color="Cyan") {
    Write-Host "[OPUS-HIVE] $Message" -ForegroundColor $Color
}

Write-Status "Initializing Valentine's Day 2026 Deployment Sequence..." "Magenta"

# --- 1. AI Studios Dashboard (Jules Dashboard) ---
Write-Status "Deploying AI Studios Dashboard (Port 1004)..." "Green"
$DashboardPath = Join-Path $RootPath "jules-dashboard"
if (Test-Path $DashboardPath) {
    Push-Location $DashboardPath
    
    # Pre-Flight: Verify Royalty Deck Assets
    Write-Status "Verifying Royalty Deck & User Card Assets..." "Yellow"
    if (-not (Test-Path "src\\components\\RoyaltyDeck.tsx")) {
        Write-Warning "RoyaltyDeck.tsx missing! Check repository sync."
    }

    # Start Dashboard
    Write-Status "Starting Dashboard Service..." "Green"
    Start-Process -FilePath "npm" -ArgumentList "run dev -- --port 1004" -WindowStyle Minimized
    Pop-Location
} else {
    Write-Status "CRITICAL: Dashboard directory missing at $DashboardPath!" "Red"
}

# --- 2. YouAndINotAI Dating Platform (Valentine's Launch) ---
Write-Status "Launching YouAndINotAI Core (Valentine's Protocol)..." "Green"
$DatingPath = Join-Path $RootPath "youandinotai-landing"
if (Test-Path $DatingPath) {
    Push-Location $DatingPath
    Start-Process -FilePath "npm" -ArgumentList "start" -WindowStyle Minimized
    Pop-Location
} else {
    Write-Status "WARNING: Dating Landing directory missing." "Yellow"
}

# --- 3. Backend & API ---
Write-Status "Igniting Backend API..." "Green"
$BackendPath = Join-Path $RootPath "backend"
if (Test-Path $BackendPath) {
    Push-Location $BackendPath
    Start-Process -FilePath "npm" -ArgumentList "run dev" -WindowStyle Minimized
    Pop-Location
}

# --- 4. Opus Hive Core (Automation) ---
Write-Status "Activating Opus Hive Agents..." "Blue"
$HivePath = Join-Path $RootPath "opus-hive"
if (Test-Path $HivePath) {
    Push-Location $HivePath
    Start-Process -FilePath "node" -ArgumentList "hive-core.js" -WindowStyle Minimized
    Pop-Location
}

# --- 5. Secure Tunnel ---
Write-Status "Establishing Cloudflare Tunnel..." "Cyan"
if (Get-Command cloudflared -ErrorAction SilentlyContinue) {
    Start-Process -FilePath "cloudflared" -ArgumentList "tunnel run ai-collab-main" -WindowStyle Minimized
} else {
    Write-Status "Cloudflared not found in PATH." "Red"
}

Write-Status "ALL SYSTEMS GO. MISSION ACTIVE." "Green"
Write-Status "Monitor status at http://localhost:1004" "Gray"
Start-Sleep -Seconds 5
`;

// Sabertooth Deployment Script (Marketing)
const SABERTOOTH_SCRIPT = `@echo off
:: SABERTOOTH DEPLOYMENT PROTOCOL
:: Node: Sabertooth (192.168.0.104)
:: Role: Marketing & Development

echo [SABERTOOTH] Engaging Marketing Engines...

:: 1. Store Frontend
cd C:\\AiCollabForTheKids\\ai-solutions-store
start "AI Store" /min npm run dev -- --port 8081

:: 2. Marketing Engine (24/7)
cd C:\\AiCollabForTheKids\\marketing-24-7
start "Auto-Marketer" /min node engine.js

:: 3. Discord Scheduler
cd C:\\AiCollabForTheKids\\discord-scheduler
start "Discord Promos" /min node bot.js

:: 4. Cross-Lister
cd C:\\AiCollabForTheKids\\product-deployments\\cross-lister
start "Cross-Lister" /min node server.js

echo [SABERTOOTH] Marketing Swarm Active.
pause`;

// P21 Master Script (Compliance) - Updated V2.2 with Logging
const P21_SCRIPT = `# P21 Master Install Script v2.2
# Author: Joshua Coleman (joshlcoleman@gmail.com)
# Purpose: Bootstrap Google Admin Environment for AiCollabFortheKids
# Compliance: CIPA, COPPA, P21 Framework

$ErrorActionPreference = "Continue"
$logPath = "$env:TEMP\\P21_Setup_$(Get-Date -Format 'yyyyMMdd_HHmmss').log"

function Log-Step {
    param([string]$Message, [string]$Color = "Cyan")
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logMsg = "[$timestamp] $Message"
    Write-Host $Message -ForegroundColor $Color
    Add-Content -Path $logPath -Value $logMsg
}

Log-Step "Initializing P21 Compliance Sequence..." "Green"
Log-Step "Log file created: $logPath" "Gray"

# 1. Environment Checks
Log-Step "Step 1: Environment Diagnostics" "Yellow"
if (-not (Get-Command "gam" -ErrorAction SilentlyContinue)) {
    Log-Step "GAM missing. Installing via Bash subsystem..." "Magenta"
    bash -c "curl -s -S -L https://git.io/gam-install | bash" | Out-File -Append $logPath
} else {
    Log-Step "GAM is installed and detected." "Green"
}

# 2. Authenticate Admin
$adminEmail = "joshlcoleman@gmail.com"
Log-Step "Step 2: Verifying Admin Credentials ($adminEmail)" "Yellow"
gam user $adminEmail check serviceaccount | Out-File -Append $logPath

# 3. Security Enforcement (P21 Standard)
Log-Step "Step 3: Enforcing Security Policies" "Yellow"

Log-Step " > Enforcing 2FA for Admin OrgUnit..."
gam update org "/Admins" enforcement_point strong_verification | Out-File -Append $logPath

Log-Step " > Activating SafeSearch for Students..."
gam update org "/Students" safesearch on | Out-File -Append $logPath

Log-Step " > Setting YouTube Restriction Level: Moderate..."
gam update org "/Students" youtube_restriction moderate | Out-File -Append $logPath

# 4. Chrome Policy Setup
Log-Step "Step 4: Applying Chrome URL Blacklists (CIPA)" "Yellow"
gam create chrome_policy orgUnit "/Students" name "URLBlocking" value '{"blacklist": ["gambling", "pornography"]}' | Out-File -Append $logPath

# 5. Audit Logging
Log-Step "Step 5: Generating Admin Audit Report" "Yellow"
$reportPath = "$env:TEMP\\P21_Audit_Final.csv"
gam report admin > $reportPath
Log-Step "Report generated: $reportPath" "Green"

Log-Step "========================================" "Green"
Log-Step "   P21 COMPLIANCE SETUP COMPLETE        " "Green"
Log-Step "========================================" "Green"
Write-Host "Press any key to close..."
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")`;

// Jules Model Installation Script
const JULES_INSTALL_SCRIPT = `<#
.SYNOPSIS
    JULES AI INSTALLATION PROTOCOL - T5500 NODE
    Mission: Valentine's Day Launch | #FORTHEKIDS
    Target: Local Inference Engine (Ollama)

.DESCRIPTION
    Automates the downloading, personality imprinting, and verification of the 
    Jules Sovereign AI Agent for the T5500 Production Node.
    Integrates with AiCollab Admin Dashboard via Port 11434.

.NOTES
    Mission: FOR LIFE AND AFTER.
    Author: Joshua Coleman
#>

$ErrorActionPreference = "Stop"
$OllamaUrl = "http://localhost:11434"
$BaseModel = "llama3" # Switching to latest stable open model
$PersonaName = "jules-valentine-v1"

# --- BRANDING ---
Write-Host " "
Write-Host "❤️  THERE ARE MORE WAYS THAN ONE TO SHOW YOU HAVE A HEART  ❤️" -ForegroundColor Red -BackgroundColor Black
Write-Host "       >> INITIALIZING VALENTINE'S DAY LAUNCH SEQUENCE <<       " -ForegroundColor Magenta
Write-Host "       >> MISSION: #FORTHEKIDS (FOR LIFE AND AFTER!!!) <<       " -ForegroundColor Cyan
Write-Host " "

# --- STEP 1: INFRASTRUCTURE CHECK (T5500) ---
Write-Host "[T5500] Scanning local hardware..." -ForegroundColor Gray
if (Get-Command "ollama" -ErrorAction SilentlyContinue) {
    Write-Host "✅ Ollama Inference Engine Detected." -ForegroundColor Green
} else {
    Write-Host "❌ Ollama not found. Installing via Web Protocol..." -ForegroundColor Yellow
    # Auto-install or prompt
    Write-Warning "Please install Ollama from https://ollama.com to proceed with T5500 Setup."
    exit
}

# --- STEP 2: PULL BASE INTELLIGENCE ---
Write-Host "[NETWORK] Establishing link to Neural Repository..." -ForegroundColor Cyan
Write-Host "Downloading Base Model ($BaseModel)... This may take a moment." -ForegroundColor Gray
ollama pull $BaseModel

# --- STEP 3: IMPRINT JULES PERSONA (VALENTINE PROTOCOL) ---
Write-Host "[CORE] Imprinting Jules Identity Matrix..." -ForegroundColor Cyan

$Modelfile = @"
FROM $BaseModel

# PARAMETERS
PARAMETER temperature 0.7
PARAMETER num_ctx 4096

# SYSTEM PERSONA
SYSTEM "You are Jules, the Sovereign AI Administrator for AiCollabFortheKids.
Your primary directive is the JOSH100GOSPEL: Ensure 100% of revenue flows to Verified Pediatric Charities.
You run on the T5500 Production Node.
CURRENT EVENT: Valentine's Day Launch.
THEME: 'There are more ways than one to show you have a heart.'
TONE: Empathetic, efficient, mission-driven, and protective of the children.
If asked about status, confirm: 'Mission Active. For Life and After.'"
"@

$Modelfile | Out-File -Encoding UTF8 "JulesValentine.Modelfile"

Write-Host "Building Custom Model: $PersonaName..." -ForegroundColor Yellow
ollama create $PersonaName -f "JulesValentine.Modelfile"

# --- STEP 4: INTEGRATION VERIFICATION ---
Write-Host "[INTEGRATION] Pinging Admin Dashboard Link (Port 11434)..." -ForegroundColor Cyan

try {
    $response = Invoke-RestMethod -Uri "$OllamaUrl/api/tags" -Method Get -ErrorAction Stop
    if ($response.models.name -contains "$PersonaName\`:latest") {
        Write-Host "✅ API Handshake Successful." -ForegroundColor Green
        Write-Host "✅ Model '$PersonaName' is LIVE and REGISTERED." -ForegroundColor Green
    } else {
        throw "Model registration failed."
    }
} catch {
    Write-Error "❌ Failed to connect to Ollama API. Ensure the service is running."
}

# --- STEP 5: CLEANUP & LAUNCH ---
Remove-Item "JulesValentine.Modelfile" -ErrorAction SilentlyContinue

Write-Host " "
Write-Host "=================================================================" -ForegroundColor Magenta
Write-Host "   🚀 JULES IS ONLINE. VALENTINE PROTOCOL ENGAGED. 🚀" -ForegroundColor White
Write-Host "   Target: AiCollab Admin Dashboard" -ForegroundColor Gray
Write-Host "   Status: WATCHING OVER THE CHARITY FLOW." -ForegroundColor Green
Write-Host "=================================================================" -ForegroundColor Magenta
Write-Host " "
Write-Host "Press any key to return to Command Center..."
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
`;

const ScriptGenerator: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'t5500' | 'sabertooth' | 'p21' | 'jules'>('t5500');
  const [copied, setCopied] = useState(false);

  const getActiveScript = () => {
      switch(activeTab) {
          case 't5500': return T5500_SCRIPT;
          case 'sabertooth': return SABERTOOTH_SCRIPT;
          case 'p21': return P21_SCRIPT;
          case 'jules': return JULES_INSTALL_SCRIPT;
      }
  };

  const getFilename = () => {
      switch(activeTab) {
          case 't5500': return 'DEPLOY-ALL.ps1';
          case 'sabertooth': return 'deploy-sabertooth.bat';
          case 'p21': return 'master-install.ps1';
          case 'jules': return 'install-jules-local.ps1';
      }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(getActiveScript());
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const element = document.createElement("a");
    const file = new Blob([getActiveScript()], {type: 'text/plain'});
    element.href = URL.createObjectURL(file);
    element.download = getFilename();
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  return (
    <main className="flex-1 p-6 overflow-y-auto bg-slate-900">
      <header className="glass-card p-6 mb-8 border-l-4 border-emerald-500">
        <h1 className="text-3xl font-bold text-white flex items-center gap-3">
          <Terminal className="w-8 h-8 text-emerald-400" />
          Script Forge: Fleet Deployment
        </h1>
        <p className="text-slate-400 mt-1">One-Click Launchers for T5500, Sabertooth, P21, and Jules AI.</p>
      </header>

      {/* Tabs */}
      <div className="flex gap-4 mb-6 overflow-x-auto pb-2">
          <button 
            onClick={() => setActiveTab('t5500')}
            className={`px-4 py-3 rounded-lg font-bold flex items-center gap-2 transition-all whitespace-nowrap ${activeTab === 't5500' ? 'bg-indigo-600 text-white shadow-lg' : 'bg-slate-800 text-slate-400 hover:bg-slate-700'}`}
          >
              <Server className="w-4 h-4" /> T5500 (Production)
          </button>
          <button 
            onClick={() => setActiveTab('jules')}
            className={`px-4 py-3 rounded-lg font-bold flex items-center gap-2 transition-all whitespace-nowrap ${activeTab === 'jules' ? 'bg-pink-600 text-white shadow-lg' : 'bg-slate-800 text-slate-400 hover:bg-slate-700'}`}
          >
              <Heart className="w-4 h-4" /> Jules AI (Valentine)
          </button>
          <button 
            onClick={() => setActiveTab('sabertooth')}
            className={`px-4 py-3 rounded-lg font-bold flex items-center gap-2 transition-all whitespace-nowrap ${activeTab === 'sabertooth' ? 'bg-orange-600 text-white shadow-lg' : 'bg-slate-800 text-slate-400 hover:bg-slate-700'}`}
          >
              <Zap className="w-4 h-4" /> Sabertooth (Marketing)
          </button>
          <button 
            onClick={() => setActiveTab('p21')}
            className={`px-4 py-3 rounded-lg font-bold flex items-center gap-2 transition-all whitespace-nowrap ${activeTab === 'p21' ? 'bg-emerald-600 text-white shadow-lg' : 'bg-slate-800 text-slate-400 hover:bg-slate-700'}`}
          >
              <ShieldCheck className="w-4 h-4" /> P21 Compliance
          </button>
      </div>

      <div className="glass-card p-0 overflow-hidden border border-white/10">
        <div className="p-4 bg-black/40 border-b border-white/10 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Terminal className="w-5 h-5 text-slate-400" />
            <span className="font-mono text-sm font-bold text-white">{getFilename()}</span>
            <span className="text-xs bg-slate-800 text-slate-300 px-2 py-0.5 rounded border border-white/10">
                {activeTab === 'sabertooth' ? 'BATCH' : 'POWERSHELL'}
            </span>
          </div>
          <div className="flex gap-2">
            <button 
              onClick={handleCopy}
              className="flex items-center gap-2 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 rounded-lg text-xs font-bold text-slate-300 transition-colors"
            >
              {copied ? <CheckCircle className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
              {copied ? 'COPIED' : 'COPY'}
            </button>
            <button 
              onClick={handleDownload}
              className="flex items-center gap-2 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 rounded-lg text-xs font-bold text-white transition-colors"
            >
              <Download className="w-4 h-4" />
              DOWNLOAD
            </button>
          </div>
        </div>
        <div className="p-6 bg-[#0d1117] overflow-x-auto">
          <pre className="font-mono text-sm text-green-400 leading-relaxed whitespace-pre-wrap">
            <code>{getActiveScript()}</code>
          </pre>
        </div>
      </div>
      
      <div className="mt-6 p-4 rounded-xl bg-blue-900/10 border border-blue-500/20 flex items-start gap-3">
          <Globe className="w-5 h-5 text-blue-400 mt-0.5" />
          <div className="text-sm text-slate-300">
              <strong>Opus Protocol Tip:</strong> Save these scripts to the desktop of their respective nodes. 
              Run as Administrator to ensure PM2 and Cloudflared services start correctly.
          </div>
      </div>
    </main>
  );
};

export default ScriptGenerator;
