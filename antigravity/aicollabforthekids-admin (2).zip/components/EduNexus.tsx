
import React, { useState } from 'react';
import { GoogleGenAI } from '@google/genai';
import { GraduationCap, Terminal, AlertCircle, Activity, Play, ClipboardList, CheckCircle } from './IconComponents';
import ReactMarkdown from 'react-markdown';

const EduNexus: React.FC = () => {
    const [mode, setMode] = useState<'script' | 'troubleshoot' | 'analytics'>('script');
    const [input, setInput] = useState('');
    const [output, setOutput] = useState('');
    const [isProcessing, setIsProcessing] = useState(false);

    const handleGenerateScript = async () => {
        if (!input.trim()) return;
        setIsProcessing(true);
        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const response = await ai.models.generateContent({
                model: 'gemini-3-flash-preview',
                contents: `Act as a Senior IT Systems Administrator. Generate a robust, well-commented script for the following task.
                Task: ${input}
                
                Output Format:
                1. Language (PowerShell/Bash/Python)
                2. The Code Block
                3. Brief explanation of what it does.
                
                Ensure safety checks (dry-run) are included if applicable.`,
                config: { thinkingConfig: { thinkingBudget: 2048 } }
            });
            setOutput(response.text || "Failed to generate script.");
        } catch (e) {
            setOutput("Error connecting to AI.");
        } finally {
            setIsProcessing(false);
        }
    };

    const handleTroubleshoot = async () => {
        if (!input.trim()) return;
        setIsProcessing(true);
        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const response = await ai.models.generateContent({
                model: 'gemini-3-flash-preview',
                contents: `Analyze the following system error log or issue description. Provide a Root Cause Analysis and step-by-step fix.
                
                Error/Issue:
                ${input}
                
                Format:
                ## Root Cause
                [Explanation]
                
                ## Recommended Fix
                [Steps]
                
                ## Prevention
                [Advice]`,
                config: { thinkingConfig: { thinkingBudget: 1024 } }
            });
            setOutput(response.text || "Failed to analyze error.");
        } catch (e) {
            setOutput("Error connecting to AI.");
        } finally {
            setIsProcessing(false);
        }
    };

    return (
        <main className="flex-1 p-6 overflow-y-auto bg-slate-900">
            <header className="glass-card p-6 mb-8 border-l-4 border-cyan-500">
                <h1 className="text-3xl font-bold text-white flex items-center gap-3">
                    <GraduationCap className="w-8 h-8 text-cyan-400" />
                    EduAdmin Nexus
                </h1>
                <p className="text-slate-400 mt-1">IT Administration & Educational Systems Management</p>
            </header>

            <div className="flex gap-4 mb-6">
                <button 
                    onClick={() => setMode('script')} 
                    className={`px-4 py-2 rounded-lg font-bold transition-colors ${mode === 'script' ? 'bg-cyan-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'}`}
                >
                    <Terminal className="w-4 h-4 inline mr-2" /> Script Forge
                </button>
                <button 
                    onClick={() => setMode('troubleshoot')} 
                    className={`px-4 py-2 rounded-lg font-bold transition-colors ${mode === 'troubleshoot' ? 'bg-cyan-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'}`}
                >
                    <AlertCircle className="w-4 h-4 inline mr-2" /> Error Oracle
                </button>
                <button 
                    onClick={() => setMode('analytics')} 
                    className={`px-4 py-2 rounded-lg font-bold transition-colors ${mode === 'analytics' ? 'bg-cyan-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'}`}
                >
                    <Activity className="w-4 h-4 inline mr-2" /> Student Analytics
                </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 h-full min-h-[500px]">
                {/* Input Area */}
                <div className="glass-card p-6 flex flex-col">
                    <h3 className="text-lg font-bold text-white mb-4">
                        {mode === 'script' ? 'Script Requirements' : mode === 'troubleshoot' ? 'Error Logs / Description' : 'Data Source'}
                    </h3>
                    
                    {mode === 'analytics' ? (
                        <div className="flex-1 flex items-center justify-center text-slate-500 border border-dashed border-white/10 rounded-xl">
                            <p>Connect Student Information System (SIS) API</p>
                        </div>
                    ) : (
                        <>
                            <textarea 
                                value={input}
                                onChange={(e) => setInput(e.target.value)}
                                placeholder={mode === 'script' ? "e.g. Create a PowerShell script to reset the print spooler on 50 remote machines..." : "Paste error logs here..."}
                                className="flex-1 glass-input p-4 resize-none font-mono text-sm text-slate-300 focus:ring-2 focus:ring-cyan-500/50"
                            />
                            <button 
                                onClick={mode === 'script' ? handleGenerateScript : handleTroubleshoot}
                                disabled={isProcessing || !input.trim()}
                                className="mt-4 w-full py-3 bg-cyan-600 hover:bg-cyan-700 text-white rounded-lg font-bold flex items-center justify-center gap-2 disabled:opacity-50 transition-all"
                            >
                                {isProcessing ? (
                                    <span className="animate-pulse">Processing...</span>
                                ) : (
                                    <>
                                        <Play className="w-4 h-4" />
                                        {mode === 'script' ? 'Generate Script' : 'Analyze Error'}
                                    </>
                                )}
                            </button>
                        </>
                    )}
                </div>

                {/* Output Area */}
                <div className="glass-card p-6 relative overflow-hidden flex flex-col">
                    <h3 className="text-lg font-bold text-white mb-4">
                        {mode === 'analytics' ? 'Dashboard' : 'System Output'}
                    </h3>
                    
                    {mode === 'analytics' ? (
                        <div className="grid grid-cols-2 gap-4">
                            <div className="bg-slate-800/50 p-4 rounded-xl">
                                <p className="text-xs text-slate-400 uppercase">Active Devices</p>
                                <p className="text-2xl font-bold text-cyan-400">1,245</p>
                            </div>
                            <div className="bg-slate-800/50 p-4 rounded-xl">
                                <p className="text-xs text-slate-400 uppercase">Help Tickets</p>
                                <p className="text-2xl font-bold text-yellow-400">34</p>
                            </div>
                            <div className="col-span-2 bg-slate-800/50 p-4 rounded-xl h-48 flex items-center justify-center">
                                <p className="text-slate-500 text-sm">Usage Chart Placeholder</p>
                            </div>
                        </div>
                    ) : (
                        <div className="flex-1 overflow-y-auto bg-black/20 rounded-xl p-4 border border-white/5 font-mono text-sm text-slate-300">
                            {output ? (
                                <div className="prose prose-invert prose-sm max-w-none">
                                    <ReactMarkdown>{output}</ReactMarkdown>
                                </div>
                            ) : (
                                <div className="h-full flex flex-col items-center justify-center text-slate-600 opacity-50">
                                    <Terminal className="w-12 h-12 mb-4" />
                                    <p>Ready to process input.</p>
                                </div>
                            )}
                        </div>
                    )}
                </div>
            </div>
        </main>
    );
};

export default EduNexus;
