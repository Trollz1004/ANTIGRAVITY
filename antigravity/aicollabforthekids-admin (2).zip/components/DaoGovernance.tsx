
import React, { useState } from 'react';
import { Users, Vote, ShieldCheck, Lock, Gem, Crown, Key, Activity, Server, Star, Sheets } from './IconComponents';
import { GovernanceProposal, JulesAction, VipTier, PriorityLevel, DaoLeader, CommunitySuggestion, TreasurySigner } from '../types';

const DaoGovernance: React.FC = () => {
  const [currentTier] = useState<VipTier>('Member');

  const [proposals] = useState<GovernanceProposal[]>([
      { 
          id: '0', 
          title: 'Emergency Stabilization & Reserve Mandate', 
          description: 'Authorize "Survival Protocol": Divert 100% of revenue to Ops/Founder until $50k Reserve is filled. Reason: Critical Infrastructure Risk.', 
          votesFor: 150000, 
          votesAgainst: 0, 
          status: 'passed', 
          endDate: 'Executed' 
      },
      { id: '1', title: 'Fund New Medical Research Wing', description: 'Allocate Q4 surplus to Pediatric Medical Research Partners.', votesFor: 12500, votesAgainst: 450, status: 'active', endDate: 'Paused (Reserve Priority)' },
      { id: '2', title: 'Expand Operations to Asia', description: 'Increase operational budget for new outreach.', votesFor: 8000, votesAgainst: 9200, status: 'active', endDate: '5 days' },
  ]);

  const [julesActions] = useState<JulesAction[]>([
      { 
          id: 'j0', 
          title: 'Protocol Pivot Executed', 
          details: 'Switching financial logic to Survival Mode. Reserve filling active.', 
          priority: 'Critical', 
          requiredTier: 'Public', 
          status: 'Completed', 
          timestamp: 'Just now',
          impactValue: 'System Saved'
      },
      { 
          id: 'j1', 
          title: 'Liquidity Optimization', 
          details: 'Moving 10 ETH to Layer 2 to reduce gas fees for donation disbursement.', 
          priority: 'High', 
          requiredTier: 'Council', 
          status: 'In Progress', 
          timestamp: '10 mins ago',
          impactValue: 'Est. $400 Saved'
      }
  ]);

  const [suggestions] = useState<CommunitySuggestion[]>([
      { id: 's1', user: 'MikeT', text: 'Add a merch store for pets', votes: 45, status: 'raw' },
      { id: 's2', user: 'JennyK', text: 'Partner with local schools', votes: 128, status: 'polished' }
  ]);

  const [signers] = useState<TreasurySigner[]>([
      { id: '1', name: 'Joshua Coleman', role: 'Founder', status: 'Active', lastActive: '5 mins ago', isMachine: false },
      { id: '2', name: 'Legal Counsel', role: 'Legal', status: 'Active', lastActive: '2 days ago', isMachine: false },
      { id: '3', name: 'Cold Storage 1', role: 'Cold_Storage', status: 'Offline', lastActive: '30 days ago', isMachine: true },
      { id: '4', name: 'Jules (Gemini)', role: 'AI_Auditor', status: 'Active', lastActive: 'Live', isMachine: true },
      { id: '5', name: 'Google Cloud Guardian', role: 'Guardian_Protocol', status: 'Standby', lastActive: 'Monitoring', isMachine: true }
  ]);

  const getPriorityColor = (p: PriorityLevel) => {
      switch(p) {
          case 'Critical': return 'bg-red-500 text-white animate-pulse shadow-[0_0_10px_rgba(239,68,68,0.6)]';
          case 'High': return 'bg-orange-500 text-white';
          case 'Medium': return 'bg-blue-500 text-white';
          case 'Low': return 'bg-slate-500 text-slate-200';
      }
  };

  const hasAccess = (required: VipTier, current: VipTier) => {
      const levels = { 'Public': 0, 'Member': 1, 'Council': 2, 'Architect': 3 };
      return levels[current] >= levels[required];
  };

  return (
    <main className="flex-1 p-6 overflow-y-auto bg-[#0a0a0a] relative overflow-hidden">
        {/* Ambient Glow */}
        <div className="absolute top-[-20%] right-[-10%] w-[800px] h-[800px] bg-gradient-radial from-purple-900/20 to-transparent rounded-full blur-[100px] pointer-events-none"></div>
        
        <header className="glass-card p-8 mb-8 border-l-4 border-purple-500 flex flex-col md:flex-row justify-between items-center bg-gradient-to-r from-slate-900 via-purple-950/20 to-slate-900 relative z-10">
            <div>
                <h1 className="text-4xl font-black text-white flex items-center gap-4 tracking-tighter">
                    <div className="p-3 bg-purple-500/20 rounded-2xl border border-purple-500/30">
                        <Users className="w-8 h-8 text-purple-400" />
                    </div>
                    <span>
                        For The Kids DAO
                        <span className="block text-sm font-medium text-slate-400 mt-1 tracking-normal">Decentralized Philanthropy. Immutable Impact.</span>
                    </span>
                </h1>
            </div>
            <div className="text-right mt-4 md:mt-0">
                 <div className="flex items-center gap-2 justify-end text-emerald-400 mb-1">
                    <ShieldCheck className="w-5 h-5" />
                    <span className="text-sm font-bold uppercase tracking-widest">Smart Contract Active</span>
                 </div>
                 <p className="text-xs text-slate-500 font-mono bg-black/40 px-3 py-1 rounded-full border border-white/5">0xAiCollab...88</p>
            </div>
        </header>

        {/* EPIC TREASURY VISUAL */}
        <div className="glass-card p-0 mb-10 border border-amber-500/30 overflow-hidden relative group">
            <div className="absolute inset-0 bg-gradient-to-r from-amber-950/30 via-black to-slate-900 z-0"></div>
            <div className="absolute top-0 right-0 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10 z-0"></div>
            
            {/* Header Strip */}
            <div className="p-6 border-b border-amber-500/20 bg-black/40 flex justify-between items-center relative z-10">
                <div className="flex items-center gap-3">
                    <div className="p-2 bg-amber-500/20 rounded-lg shadow-[0_0_15px_rgba(245,158,11,0.3)]">
                        <Key className="w-6 h-6 text-amber-400" />
                    </div>
                    <div>
                        <h3 className="text-xl font-black text-white uppercase tracking-widest">Treasury Vault</h3>
                        <p className="text-xs text-amber-500 font-bold">Multi-Sig Custody • 3-of-5 Required</p>
                    </div>
                </div>
                <div className="flex items-center gap-3">
                    <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-blue-900/30 border border-blue-500/30">
                        <Sheets className="w-4 h-4 text-blue-400" />
                        <span className="text-xs font-bold text-blue-300">Microsoft 365 Ledger Synced</span>
                    </div>
                    <div className="px-4 py-1.5 rounded-full bg-emerald-900/30 border border-emerald-500/30 text-xs font-black text-emerald-400 animate-pulse tracking-widest">
                        SECURE
                    </div>
                </div>
            </div>

            {/* Content Grid */}
            <div className="p-8 relative z-10">
                <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
                    {signers.map(signer => (
                        <div key={signer.id} className={`p-6 rounded-2xl border flex flex-col items-center text-center transition-all duration-300 transform hover:-translate-y-2 relative overflow-hidden ${
                            signer.role === 'Guardian_Protocol' 
                            ? 'bg-blue-950/40 border-blue-500/50 shadow-[0_0_30px_rgba(59,130,246,0.15)]' 
                            : 'bg-gradient-to-b from-white/10 to-transparent border-white/10 hover:border-amber-500/30'
                        }`}>
                            <div className={`w-14 h-14 rounded-full flex items-center justify-center mb-4 text-xl shadow-lg ${
                                signer.status === 'Active' ? 'bg-emerald-500/20 text-emerald-400 border-2 border-emerald-500/30' :
                                signer.status === 'Offline' ? 'bg-slate-700/50 text-slate-400 border-2 border-slate-600' :
                                'bg-blue-500/20 text-blue-400 border-2 border-blue-500/30'
                            }`}>
                                {signer.isMachine ? <Server className="w-6 h-6" /> : <Users className="w-6 h-6" />}
                            </div>
                            
                            <h4 className="text-sm font-black text-white mb-1 tracking-wide">{signer.name}</h4>
                            <p className="text-[10px] uppercase font-bold tracking-[0.2em] mb-4 text-slate-400">{signer.role.replace('_', ' ')}</p>
                            
                            <div className={`text-[10px] px-3 py-1 rounded-full flex items-center gap-1.5 font-bold uppercase ${
                                signer.status === 'Active' ? 'bg-emerald-500/10 text-emerald-400' :
                                signer.status === 'Standby' ? 'bg-blue-500/10 text-blue-400' :
                                'bg-slate-700/50 text-slate-500'
                            }`}>
                                <Activity className="w-3 h-3" />
                                {signer.status}
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-8 mb-8">
            {/* JULES JEWELRY BOX */}
            <div className="xl:col-span-2 glass-card p-0 border border-indigo-500/30 overflow-hidden flex flex-col h-[600px] shadow-[0_0_40px_rgba(99,102,241,0.1)]">
                <div className="p-6 border-b border-indigo-500/20 bg-indigo-950/30 flex justify-between items-center">
                    <div className="flex items-center gap-4">
                        <div className="p-2 bg-indigo-500/20 rounded-xl border border-indigo-500/40">
                            <Crown className="w-6 h-6 text-indigo-400" />
                        </div>
                        <div>
                            <h3 className="text-xl font-black text-white tracking-tight">Jules Jewelry Box</h3>
                            <p className="text-xs text-indigo-300 uppercase tracking-widest font-bold">Autonomous Decision Ledger</p>
                        </div>
                    </div>
                </div>
                <div className="flex-1 overflow-y-auto custom-scrollbar divide-y divide-white/5 bg-slate-900/50">
                    {julesActions.map((action) => {
                        const unlocked = hasAccess(action.requiredTier, currentTier);
                        return (
                            <div key={action.id} className={`p-6 transition-all duration-500 hover:bg-white/5 group ${!unlocked ? 'opacity-40 grayscale blur-[1px]' : ''}`}>
                                <div className="flex items-start gap-5">
                                    <div className={`mt-1 w-24 flex-shrink-0 text-center py-2 rounded-lg text-[10px] font-black uppercase tracking-wider shadow-lg ${getPriorityColor(action.priority)}`}>
                                        {action.priority}
                                    </div>
                                    <div className="flex-1">
                                        <div className="flex justify-between items-start mb-2">
                                            <h4 className="text-lg font-bold text-white group-hover:text-indigo-400 transition-colors">{unlocked ? action.title : 'RESTRICTED CONTENT'}</h4>
                                            <span className="text-xs text-slate-500 font-mono">{action.timestamp}</span>
                                        </div>
                                        <p className="text-sm text-slate-300 leading-relaxed">
                                            {unlocked ? action.details : 'You must achieve Council Tier to view these autonomous decisions.'}
                                        </p>
                                        <div className="mt-3 flex items-center gap-2">
                                            <span className="text-[10px] text-green-400 font-bold bg-green-900/20 px-2 py-0.5 rounded border border-green-500/20">
                                                IMPACT: {action.impactValue}
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        );
                    })}
                </div>
            </div>

            {/* COMMUNITY GEMS */}
            <div className="glass-card p-6 bg-gradient-to-br from-slate-900 to-pink-950/20 border-pink-500/20">
                <h3 className="font-black text-white flex items-center gap-3 mb-6 text-xl">
                    <Gem className="w-6 h-6 text-pink-400" /> Community Gems
                </h3>
                <div className="space-y-4">
                    {suggestions.filter(s => s.status !== 'mounted').map(suggestion => (
                        <div key={suggestion.id} className="p-4 bg-white/5 rounded-2xl border border-white/5 hover:border-pink-500/30 transition-all hover:bg-white/10 group">
                            <p className="text-sm text-slate-200 leading-relaxed font-medium">"{suggestion.text}"</p>
                            <div className="flex items-center justify-between mt-3 pt-3 border-t border-white/5">
                                <span className="text-xs font-bold text-pink-400">{suggestion.user}</span>
                                <span className="text-xs text-slate-400 bg-black/30 px-2 py-1 rounded-full group-hover:text-white transition-colors">{suggestion.votes} Votes</span>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>

        {/* PROPOSALS */}
        <h3 className="text-2xl font-black text-white mb-6 flex items-center gap-3">
            <Vote className="w-7 h-7 text-yellow-400" />
            Active Governance Proposals
        </h3>
        <div className="grid grid-cols-1 gap-6 pb-12">
            {proposals.map(prop => (
                <div key={prop.id} className={`glass-card p-8 flex flex-col md:flex-row justify-between items-center gap-8 ${prop.id === '0' ? 'border-2 border-emerald-500/50 bg-emerald-950/10' : 'border border-white/10'}`}>
                    <div className="flex-1">
                        <div className="flex items-center gap-3 mb-3">
                            <span className={`px-3 py-1 rounded-full text-xs font-black uppercase tracking-widest ${
                                prop.status === 'passed' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-slate-700 text-slate-300'
                            }`}>
                                {prop.status}
                            </span>
                            <span className="text-xs text-slate-500 font-mono">Ends in: {prop.endDate}</span>
                        </div>
                        <h4 className="text-xl font-bold text-white mb-2">{prop.title}</h4>
                        <p className="text-sm text-slate-400 max-w-2xl">{prop.description}</p>
                    </div>
                    
                    <div className="w-full md:w-1/3 bg-black/40 p-4 rounded-xl border border-white/5">
                        <div className="flex justify-between text-xs mb-2 font-bold uppercase tracking-wider">
                            <span className="text-emerald-400">Yes (100%)</span>
                            <span className="text-rose-400">No (0%)</span>
                        </div>
                        <div className="h-3 bg-slate-800 rounded-full overflow-hidden flex relative">
                            <div className="absolute inset-0 bg-gradient-to-r from-emerald-600 to-emerald-400" style={{ width: '100%' }}></div>
                        </div>
                        <div className="mt-3 text-center">
                            <span className="text-xs text-slate-500 font-mono">{prop.votesFor.toLocaleString()} Votes Cast</span>
                        </div>
                    </div>
                </div>
            ))}
        </div>
    </main>
  );
};

export default DaoGovernance;
