
import React, { useState } from 'react';
import { ShieldCheck, Lock, Smartphone, ArrowRight, QrCode } from './IconComponents';

interface TwoFactorAuthProps {
  onVerify: () => void;
  onCancel?: () => void;
  mode: 'setup' | 'verify';
}

const TwoFactorAuth: React.FC<TwoFactorAuthProps> = ({ onVerify, onCancel, mode }) => {
  const [code, setCode] = useState('');
  const [error, setError] = useState('');
  const [step, setStep] = useState(mode === 'setup' ? 1 : 2); // 1: Scan, 2: Verify

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (code === '123456') { // Mock verification
      onVerify();
    } else {
      setError('Invalid code. Please try again.');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#0f172a] relative overflow-hidden">
      <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-5"></div>
      <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-indigo-900/20 to-purple-900/20 pointer-events-none"></div>

      <div className="glass-card p-8 w-full max-w-md relative z-10 border border-white/10 shadow-2xl">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-indigo-500/20 rounded-full flex items-center justify-center mx-auto mb-4 border border-indigo-500/30">
            <ShieldCheck className="w-8 h-8 text-indigo-400" />
          </div>
          <h2 className="text-2xl font-bold text-white">Two-Factor Authentication</h2>
          <p className="text-slate-400 text-sm mt-2">
            {step === 1 ? 'Secure your account with Google Authenticator' : 'Enter the 6-digit code from your app'}
          </p>
        </div>

        {step === 1 && (
          <div className="space-y-6">
            <div className="bg-white p-4 rounded-xl mx-auto w-fit">
               {/* Placeholder QR Code */}
               <QrCode className="w-32 h-32 text-black" />
            </div>
            
            <div className="text-center">
                <p className="text-xs text-slate-500 uppercase tracking-wider mb-2">Or enter manual key</p>
                <code className="bg-black/30 px-4 py-2 rounded text-indigo-300 font-mono text-sm select-all">
                    JBSW Y3DP EHPK 3PXP
                </code>
            </div>

            <button 
              onClick={() => setStep(2)}
              className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-bold transition-all flex items-center justify-center gap-2"
            >
              Next <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}

        {step === 2 && (
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-slate-400 mb-2">Verification Code</label>
              <div className="relative">
                <input
                  type="text"
                  value={code}
                  onChange={(e) => {
                      if (/^\d*$/.test(e.target.value) && e.target.value.length <= 6) {
                          setCode(e.target.value);
                          setError('');
                      }
                  }}
                  placeholder="000000"
                  className="w-full bg-black/30 border border-white/10 rounded-xl p-4 text-center text-2xl tracking-[0.5em] text-white focus:outline-none focus:border-indigo-500 font-mono"
                  maxLength={6}
                />
                <Smartphone className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
              </div>
              {error && <p className="text-red-400 text-xs mt-2 text-center">{error}</p>}
            </div>

            <div className="flex gap-3">
                {onCancel && (
                    <button 
                        type="button"
                        onClick={onCancel}
                        className="flex-1 py-3 bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-xl font-bold transition-all"
                    >
                        Cancel
                    </button>
                )}
                <button 
                type="submit"
                className="flex-1 py-3 bg-green-600 hover:bg-green-500 text-white rounded-xl font-bold transition-all shadow-lg shadow-green-900/20"
                >
                Verify
                </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};

export default TwoFactorAuth;
