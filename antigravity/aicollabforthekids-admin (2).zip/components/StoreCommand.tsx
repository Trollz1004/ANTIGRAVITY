
import React, { useState, useRef } from 'react';
import { GoogleGenAI, Type } from '@google/genai';
import { ShoppingBag, UploadCloud, Tag, Barcode, DollarSign, Search, Copy, CheckCircle, Image as ImageIcon } from './IconComponents';

const StoreCommand: React.FC = () => {
    const [image, setImage] = useState<string | null>(null);
    const [productData, setProductData] = useState<any>(null);
    const [isProcessing, setIsProcessing] = useState(false);
    const fileInputRef = useRef<HTMLInputElement>(null);
    const [upc, setUpc] = useState('');

    const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (event) => {
                setImage(event.target?.result as string);
            };
            reader.readAsDataURL(file);
        }
    };

    const generateListing = async () => {
        if (!image) return;
        setIsProcessing(true);
        setProductData(null);

        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const base64Data = image.split(',')[1];

            const response = await ai.models.generateContent({
                model: 'gemini-3-flash-preview',
                contents: [
                    {
                        inlineData: {
                            mimeType: 'image/jpeg',
                            data: base64Data
                        }
                    },
                    { text: "Analyze this image and generate a product listing. Return JSON with: title, description (SEO optimized), estimated_price (number), tags (array), category." }
                ],
                config: {
                    responseMimeType: "application/json",
                    responseSchema: {
                        type: Type.OBJECT,
                        properties: {
                            title: { type: Type.STRING },
                            description: { type: Type.STRING },
                            estimated_price: { type: Type.NUMBER },
                            tags: { type: Type.ARRAY, items: { type: Type.STRING } },
                            category: { type: Type.STRING }
                        }
                    }
                }
            });

            const data = JSON.parse(response.text || '{}');
            setProductData(data);

        } catch (error) {
            console.error("Store AI Error:", error);
            alert("Failed to generate listing.");
        } finally {
            setIsProcessing(false);
        }
    };

    const handleScanUpc = async () => {
        if (!upc.trim()) return;
        // Mock lookup
        setIsProcessing(true);
        setTimeout(() => {
            setProductData({
                title: "Scanned Product Item (Mock)",
                description: "Details retrieved from global UPC database.",
                estimated_price: 19.99,
                tags: ["retail", "scanned", "inventory"],
                category: "General"
            });
            setIsProcessing(false);
        }, 1000);
    };

    return (
        <main className="flex-1 p-6 overflow-y-auto bg-slate-900">
            <header className="glass-card p-6 mb-8 border-l-4 border-orange-500">
                <h1 className="text-3xl font-bold text-white flex items-center gap-3">
                    <ShoppingBag className="w-8 h-8 text-orange-400" />
                    Ai-Solutions.Store
                </h1>
                <p className="text-slate-400 mt-1">Automated E-commerce Operations</p>
            </header>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Input Section */}
                <div className="glass-card p-6 space-y-6">
                    <h3 className="text-lg font-bold text-white mb-4">Product Source</h3>
                    
                    {/* UPC Search */}
                    <div className="relative">
                        <input 
                            type="text" 
                            placeholder="Enter UPC / Barcode" 
                            value={upc}
                            onChange={(e) => setUpc(e.target.value)}
                            className="glass-input w-full pl-10 py-3"
                        />
                        <Barcode className="w-5 h-5 text-slate-400 absolute left-3 top-3.5" />
                        <button 
                            onClick={handleScanUpc}
                            className="absolute right-2 top-2 p-1.5 bg-orange-600 rounded hover:bg-orange-500 text-white"
                        >
                            <Search className="w-4 h-4" />
                        </button>
                    </div>

                    <div className="text-center text-slate-500 text-xs uppercase tracking-widest font-bold">OR</div>

                    {/* Image Upload */}
                    <div 
                        onClick={() => fileInputRef.current?.click()}
                        className="border-2 border-dashed border-white/20 rounded-2xl p-8 text-center cursor-pointer hover:bg-white/5 transition-colors relative overflow-hidden"
                    >
                        {image ? (
                            <img src={image} alt="Preview" className="max-h-64 mx-auto rounded shadow-lg" />
                        ) : (
                            <div className="py-10">
                                <UploadCloud className="w-12 h-12 text-orange-400 mx-auto mb-4" />
                                <p className="text-slate-300 font-bold">Upload Product Image</p>
                                <p className="text-slate-500 text-sm mt-2">AI will generate the listing automatically</p>
                            </div>
                        )}
                        <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleImageUpload} />
                    </div>

                    <button 
                        onClick={generateListing}
                        disabled={isProcessing || !image}
                        className="w-full py-4 bg-orange-600 hover:bg-orange-700 text-white rounded-xl font-bold shadow-lg disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                    >
                        {isProcessing ? 'Analyzing Product...' : 'Magic Listing Generator'}
                    </button>
                </div>

                {/* Output Section */}
                <div className="glass-card p-6 border border-orange-500/30 relative">
                    {productData ? (
                        <div className="animate-in fade-in slide-in-from-bottom-4">
                            <div className="flex justify-between items-start mb-4">
                                <span className="px-3 py-1 rounded-full bg-orange-500/20 text-orange-400 text-xs font-bold uppercase tracking-wider border border-orange-500/30">
                                    {productData.category}
                                </span>
                                <div className="flex gap-2">
                                    <button className="p-2 bg-slate-700 rounded hover:bg-slate-600 text-slate-300"><Copy className="w-4 h-4" /></button>
                                    <button className="p-2 bg-green-600 rounded hover:bg-green-500 text-white font-bold text-xs flex items-center gap-1"><CheckCircle className="w-3 h-3" /> Publish</button>
                                </div>
                            </div>

                            <h2 className="text-2xl font-bold text-white mb-2">{productData.title}</h2>
                            <p className="text-3xl font-bold text-green-400 mb-6">${productData.estimated_price}</p>

                            <div className="space-y-4">
                                <div className="bg-black/30 p-4 rounded-xl border border-white/5">
                                    <h4 className="text-xs text-slate-400 uppercase tracking-wider mb-2">Description</h4>
                                    <p className="text-slate-300 text-sm leading-relaxed">{productData.description}</p>
                                </div>

                                <div>
                                    <h4 className="text-xs text-slate-400 uppercase tracking-wider mb-2">Tags</h4>
                                    <div className="flex flex-wrap gap-2">
                                        {productData.tags?.map((tag: string, i: number) => (
                                            <span key={i} className="px-2 py-1 bg-slate-800 rounded text-xs text-slate-300 border border-white/5">
                                                #{tag}
                                            </span>
                                        ))}
                                    </div>
                                </div>
                            </div>
                        </div>
                    ) : (
                        <div className="h-full flex flex-col items-center justify-center text-slate-600 opacity-50">
                            <Tag className="w-16 h-16 mb-4" />
                            <p>Generated listing details will appear here.</p>
                        </div>
                    )}
                </div>
            </div>
        </main>
    );
};

export default StoreCommand;
