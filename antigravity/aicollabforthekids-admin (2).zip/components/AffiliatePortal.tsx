
import React, { useState, useEffect } from 'react';
// Added ShoppingBag to fix Cannot find name 'ShoppingBag' error
import { Users, DollarSign, Zap, Share, CheckCircle, Copy, ArrowRight, Activity, ShieldCheck, Gem, ShoppingBag } from './IconComponents';
import { AffiliatePartner, ReferralSale, AffiliatePayout } from '../types';

const AffiliatePortal: React.FC = () => {
    const [partners, setPartners] = useState<AffiliatePartner[]>([
        { 
            id: 'aff1', 
            name: 'Tech Vanguard', 
            email: 'promo@vanguard.io', 
            tier: 'Founder', 
            referralCode: 'LEGACY-001', 
            totalEarnings: 4500.00, 
            pendingBalance: 120.50, 
            joinedAt: '2025-11-20', 
            status: 'active' 
        },
        { 
            id: 'aff2', 
            name: 'Special Needs Outreach', 
            email: 'admin@outreach.org', 
            tier: 'Gold', 
            referralCode: 'IMPACT-55', 
            totalEarnings: 1200.00, 
            pendingBalance: 45.00, 
            joinedAt: '2025-12-10', 
            status: 'active' 
        }
    ]);

    const [recentSales] = useState<ReferralSale[]>([
        { id: 's1', affiliateId: 'aff1', productName: 'Independence Assistant AI', saleAmount: 200, commission: 20, timestamp: '2026-01-06T18:30:00Z', status: 'verified' },
        { id: 's2', affiliateId: 'aff2', productName: 'Vocational Training Module', saleAmount: 150, commission: 15, timestamp: '2026-01-06T19:05:00Z', status: 'pending' },
    ]);

    const [payouts] = useState<AffiliatePayout[]>([
        { id: 'p1', affiliateId: 'aff1', amount: 500, method: 'Polygon', timestamp: '2026-01-01T10:00:00Z', txHash: '0xabc...123' },
    ]);

    const [isGenerating, setIsGenerating] = useState(false);
    const [newLink, setNewLink] = useState('');

    const generateLink = () => {
        setIsGenerating(true);
        setTimeout(() => {
            setNewLink(`https://ai-solutions.store/?ref=COLEMAN-${Math.floor(Math.random()*9000)+1000}`);
            setIsGenerating(false);
        }, 800);
    };

    return (
        <main className="flex-1 p-6 overflow-y-auto bg-[#050505] min-h-full">
            {/* ALERT BOX */}
            <div className="bg-emerald-900/20 border border-emerald-500/30 rounded-2xl p-6 mb-8 flex items-center justify-between backdrop-blur-xl">
                <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-emerald-500/20 flex items-center justify-center">
                        <Activity className="w-6 h-6 text-emerald-400 animate-pulse" />
                    </div>
                    <div>
                        <h4 className="text-white font-bold text-lg">Legacy Link Protocol Active</h4>
                        <p className="text-emerald-400/70 text-sm">Automated payout engine verifying 10% global referral commission.</p>
                    </div>
                </div>
                <button 
                    onClick={generateLink}
                    disabled={isGenerating}
                    className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-black uppercase text-xs tracking-widest transition-all shadow-lg shadow-emerald-900/20 flex items-center gap-2"
                >
                    {isGenerating ? <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div> : <Zap className="w-4 h-4" />}
                    Generate Referral Unit
                </button>
            </div>

            {newLink && (
                <div className="glass-card p-4 mb-8 bg-emerald-900/10 border-emerald-500/40 animate-in slide-in-from-top-4 flex items-center justify-between">
                    <div className="flex items-center gap-3 overflow-hidden">
                        <Share className="w-5 h-5 text-emerald-400 flex-shrink-0" />
                        <code className="text-emerald-300 text-sm font-mono truncate">{newLink}</code>
                    </div>
                    <button 
                        onClick={() => { navigator.clipboard.writeText(newLink); alert('Link Copied!'); }}
                        className="p-2 hover:bg-white/10 rounded-lg text-emerald-400 transition-all"
                    >
                        <Copy className="w-5 h-5" />
                    </button>
                </div>
            )}

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* PARTNERS LIST */}
                <div className="lg:col-span-2 space-y-6">
                    <div className="glass-card overflow-hidden border border-white/5">
                        <div className="p-6 border-b border-white/10 flex justify-between items-center bg-white/5">
                            <h3 className="text-xl font-bold text-white flex items-center gap-3">
                                <Users className="w-6 h-6 text-indigo-400" />
                                Elite Growth Partners
                            </h3>
                        </div>
                        <div className="overflow-x-auto">
                            <table className="w-full text-left text-sm text-slate-400">
                                <thead className="bg-black/40 text-[10px] uppercase font-black tracking-[0.2em] text-slate-500">
                                    <tr>
                                        <th className="px-6 py-4">Partner</th>
                                        <th className="px-6 py-4">Code</th>
                                        <th className="px-6 py-4">Earnings</th>
                                        <th className="px-6 py-4">Balance</th>
                                        <th className="px-6 py-4">Status</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-white/5">
                                    {partners.map(partner => (
                                        <tr key={partner.id} className="hover:bg-white/5 transition-colors">
                                            <td className="px-6 py-4">
                                                <div className="flex items-center gap-3">
                                                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-xs font-black ${partner.tier === 'Founder' ? 'bg-yellow-500/20 text-yellow-500' : 'bg-slate-700 text-slate-300'}`}>
                                                        {partner.name[0]}
                                                    </div>
                                                    <div>
                                                        <p className="text-white font-bold">{partner.name}</p>
                                                        <p className="text-[10px] text-slate-500">{partner.tier} Tier</p>
                                                    </div>
                                                </div>
                                            </td>
                                            <td className="px-6 py-4 font-mono text-indigo-400 font-bold">{partner.referralCode}</td>
                                            <td className="px-6 py-4 text-white font-mono">${partner.totalEarnings.toLocaleString()}</td>
                                            <td className="px-6 py-4 text-emerald-400 font-mono font-bold">${partner.pendingBalance.toLocaleString()}</td>
                                            <td className="px-6 py-4">
                                                <span className="px-2 py-0.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 rounded text-[10px] font-black uppercase">
                                                    {partner.status}
                                                </span>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>

                    {/* LIVE COMMISSION STREAM */}
                    <div className="glass-card p-6 border border-white/5">
                        <h3 className="text-lg font-bold text-white mb-6 flex items-center gap-3">
                            <Activity className="w-5 h-5 text-emerald-400" />
                            Live Commission Stream
                        </h3>
                        <div className="space-y-4">
                            {recentSales.map(sale => (
                                <div key={sale.id} className="flex items-center justify-between p-4 bg-black/40 rounded-2xl border border-white/5 group hover:border-emerald-500/30 transition-all">
                                    <div className="flex items-center gap-4">
                                        <div className="w-10 h-10 rounded-xl bg-emerald-500/10 flex items-center justify-center">
                                            <ShoppingBag className="w-5 h-5 text-emerald-400" />
                                        </div>
                                        <div>
                                            <p className="text-sm font-bold text-white">{sale.productName}</p>
                                            <p className="text-[10px] text-slate-500 uppercase font-black">
                                                Partner: {partners.find(p => p.id === sale.affiliateId)?.name}
                                            </p>
                                        </div>
                                    </div>
                                    <div className="text-right">
                                        <p className="text-emerald-400 font-black font-mono">+${sale.commission.toFixed(2)}</p>
                                        <p className="text-[9px] text-slate-600 uppercase font-bold">{sale.status}</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>

                {/* SIDEBAR: PAYOUT SETTINGS */}
                <div className="space-y-6">
                    <div className="glass-card p-8 bg-gradient-to-br from-indigo-950/20 to-black border-indigo-500/30 relative overflow-hidden">
                        <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/10 rounded-bl-full -mr-16 -mt-16"></div>
                        <h3 className="text-xl font-bold text-white mb-6">Autonomous Payouts</h3>
                        
                        <div className="space-y-4">
                            <div className="p-4 bg-black/60 rounded-xl border border-white/10">
                                <p className="text-xs text-slate-400 mb-1">Total Payouts Distributed</p>
                                <p className="text-3xl font-black text-white font-mono">$12,045.00</p>
                            </div>
                            
                            <div className="flex flex-col gap-2">
                                <label className="text-[10px] font-black text-indigo-400 uppercase tracking-widest">Payout Frequency</label>
                                <select className="glass-input p-3 text-xs">
                                    <option>Immediate (Polygon USDC)</option>
                                    <option>Weekly (Square)</option>
                                    <option>Monthly (Wire)</option>
                                </select>
                            </div>

                            <button className="w-full py-4 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-black uppercase text-xs tracking-[0.2em] transition-all shadow-xl">
                                Execute Batch Payout
                            </button>
                        </div>
                    </div>

                    <div className="glass-card p-6">
                        <h3 className="text-lg font-bold text-white mb-4">Payout History</h3>
                        <div className="space-y-3">
                            {payouts.map(p => (
                                <div key={p.id} className="p-3 bg-white/5 rounded-xl border border-white/5 flex justify-between items-center">
                                    <div>
                                        <p className="text-xs font-bold text-white">{p.method} Transfer</p>
                                        <p className="text-[10px] font-mono text-slate-500">{p.txHash}</p>
                                    </div>
                                    <span className="text-sm font-black text-white font-mono">${p.amount}</span>
                                </div>
                            ))}
                        </div>
                        <button className="w-full mt-4 text-[10px] font-black text-slate-500 hover:text-indigo-400 transition-colors uppercase tracking-widest">
                            View Full Ledger <ArrowRight className="inline w-3 h-3 ml-1" />
                        </button>
                    </div>
                </div>
            </div>
        </main>
    );
};

export default AffiliatePortal;
