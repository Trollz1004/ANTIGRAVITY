<#
.SYNOPSIS
    FOR THE KIDS - Deploy All Systems
    Gospel v1.3: 60% Charity | 30% Infra | 10% Founder

.DESCRIPTION
    Master deployment script that:
    - Starts all PM2 agents
    - Opens all ports/services
    - Launches all dashboards in browser
    - Verifies all domains are live

.NOTES
    Created: 2026-01-05
    Author: OPUS House Cleaned Edition
#>

param(
  [switch]$SkipBrowser,
  [switch]$Verbose
)

# ═══════════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════════
$Script:ProjectRoot = "C:\AiCollabForTheKids"
$Script:ErrorCount = 0

# Dashboard URLs
$Script:Dashboards = @{
  "Command Dashboard"  = "http://localhost:1004"
  "Jules Dashboard"    = "http://localhost:5173"
  "AI Solutions Store" = "http://localhost:8081"
  "YouAndINotAI"       = "http://localhost:9000"
  "API Server"         = "http://localhost:3000/health"
}

# Cloudflare Pages (Public)
$Script:CloudflarePages = @{
  "AI Solutions Store" = "https://ai-solutions-store.pages.dev"
  "YouAndINotAI"       = "https://youandinotai.pages.dev"
  "Jules Dashboard"    = "https://jules-dashboard.pages.dev"
}

# PM2 Core Agents to ensure running
$Script:CoreAgents = @(
  "for-the-kids-api",
  "ai-solutions-store",
  "command-dashboard",
  "youandinotai-landing",
  "twitter-agent",
  "marketing-24-7"
)

# ═══════════════════════════════════════════════════════════════
# HELPER FUNCTIONS
# ═══════════════════════════════════════════════════════════════
function Write-Banner {
  param([string]$Text)
  $line = "═" * 60
  Write-Host ""
  Write-Host $line -ForegroundColor Cyan
  Write-Host "  $Text" -ForegroundColor White
  Write-Host $line -ForegroundColor Cyan
}

function Write-Status {
  param(
    [string]$Message,
    [string]$Status = "INFO",
    [string]$Color = "White"
  )
  $timestamp = Get-Date -Format "HH:mm:ss"
  $statusColors = @{
    "OK"    = "Green"
    "ERROR" = "Red"
    "WARN"  = "Yellow"
    "INFO"  = "Cyan"
    "START" = "Magenta"
  }
  $c = if ($statusColors[$Status]) { $statusColors[$Status] } else { $Color }
  Write-Host "[$timestamp] " -NoNewline -ForegroundColor DarkGray
  Write-Host "[$Status] " -NoNewline -ForegroundColor $c
  Write-Host $Message -ForegroundColor White
}

function Test-Port {
  param([int]$Port)
  try {
    $connection = New-Object System.Net.Sockets.TcpClient
    $connection.Connect("127.0.0.1", $Port)
    $connection.Close()
    return $true
  }
  catch {
    return $false
  }
}

function Test-Url {
  param([string]$Url)
  try {
    $response = Invoke-WebRequest -Uri $Url -Method Head -TimeoutSec 5 -UseBasicParsing -ErrorAction Stop
    return $response.StatusCode -eq 200
  }
  catch {
    return $false
  }
}

# ═══════════════════════════════════════════════════════════════
# MAIN DEPLOYMENT STAGES
# ═══════════════════════════════════════════════════════════════

Write-Banner "FOR THE KIDS - DEPLOY ALL SYSTEMS"
Write-Host "  Gospel v1.3: 60% Charity | 30% Infra | 10% Founder" -ForegroundColor Yellow
Write-Host ""

# ─────────────────────────────────────────────────────────────────
# STAGE 1: PM2 Fleet Startup
# ─────────────────────────────────────────────────────────────────
Write-Banner "STAGE 1: PM2 Fleet Startup"

Write-Status "Restoring PM2 saved processes..." "START"
pm2 resurrect 2>$null
Start-Sleep -Seconds 2

# Ensure core agents are running
foreach ($agent in $Script:CoreAgents) {
  $status = pm2 show $agent 2>$null | Select-String "status"
  if ($status -match "online") {
    Write-Status "$agent is ONLINE" "OK"
  }
  else {
    Write-Status "$agent is not running - attempting restart..." "WARN"
    pm2 restart $agent 2>$null
    Start-Sleep -Seconds 1
  }
}

# Get fleet summary
$pm2List = pm2 list 2>$null | Select-String "online"
$onlineCount = ($pm2List | Measure-Object).Count
Write-Status "PM2 Fleet: $onlineCount agents ONLINE" "OK"

# ─────────────────────────────────────────────────────────────────
# STAGE 2: Verify Local Ports
# ─────────────────────────────────────────────────────────────────
Write-Banner "STAGE 2: Verify Local Ports"

$ports = @{
  1004 = "Command Dashboard"
  3000 = "API Server"
  5173 = "Jules Dashboard (Vite)"
  8081 = "AI Solutions Store"
  9000 = "YouAndINotAI Landing"
}

foreach ($port in $ports.Keys) {
  if (Test-Port -Port $port) {
    Write-Status "Port $port ($($ports[$port])) is OPEN" "OK"
  }
  else {
    Write-Status "Port $port ($($ports[$port])) is CLOSED" "WARN"
    $Script:ErrorCount++
  }
}

# ─────────────────────────────────────────────────────────────────
# STAGE 3: Verify Cloudflare Pages
# ─────────────────────────────────────────────────────────────────
Write-Banner "STAGE 3: Verify Cloudflare Pages"

foreach ($name in $Script:CloudflarePages.Keys) {
  $url = $Script:CloudflarePages[$name]
  if (Test-Url -Url $url) {
    Write-Status "$name ($url) is LIVE" "OK"
  }
  else {
    Write-Status "$name ($url) is DOWN" "ERROR"
    $Script:ErrorCount++
  }
}

# ─────────────────────────────────────────────────────────────────
# STAGE 4: Open Dashboards in Browser
# ─────────────────────────────────────────────────────────────────
if (-not $SkipBrowser) {
  Write-Banner "STAGE 4: Opening Dashboards"
    
  # Open local dashboards
  Start-Sleep -Seconds 1
    
  # Command Dashboard
  if (Test-Port -Port 1004) {
    Write-Status "Opening Command Dashboard..." "START"
    Start-Process "http://localhost:1004"
  }
    
  # API Health
  if (Test-Port -Port 3000) {
    Write-Status "Opening API Health Check..." "START"
    Start-Process "http://localhost:3000/health"
  }
    
  # AI Solutions Store (local)
  if (Test-Port -Port 8081) {
    Write-Status "Opening AI Solutions Store (local)..." "START"
    Start-Process "http://localhost:8081"
  }
    
  # Cloudflare Pages (production)
  Write-Status "Opening Cloudflare Pages (production)..." "START"
  Start-Process "https://ai-solutions-store.pages.dev"
  Start-Process "https://youandinotai.pages.dev"
    
  # PM2 Monit (optional)
  Write-Status "Opening PM2 Dashboard in terminal..." "START"
  Start-Process cmd -ArgumentList "/c pm2 monit" -WindowStyle Normal
}

# ─────────────────────────────────────────────────────────────────
# FINAL SUMMARY
# ─────────────────────────────────────────────────────────────────
Write-Banner "DEPLOYMENT COMPLETE"

if ($Script:ErrorCount -eq 0) {
  Write-Host ""
  Write-Host "  ✅ ALL SYSTEMS OPERATIONAL" -ForegroundColor Green
  Write-Host ""
  Write-Host "  📊 PM2 Fleet: $onlineCount agents online" -ForegroundColor Cyan
  Write-Host "  🌐 Cloudflare Pages: LIVE" -ForegroundColor Cyan
  Write-Host "  🔌 Local Ports: OPEN" -ForegroundColor Cyan
  Write-Host ""
}
else {
  Write-Host ""
  Write-Host "  ⚠️  DEPLOYMENT COMPLETED WITH $Script:ErrorCount WARNING(S)" -ForegroundColor Yellow
  Write-Host ""
  Write-Host "  Check the logs above for details." -ForegroundColor White
  Write-Host ""
}

Write-Host "  FOR THE KIDS - 60% to Verified Pediatric Charities 🎯" -ForegroundColor Magenta
Write-Host ""

# Keep window open
if (-not $SkipBrowser) {
  Write-Host "Press any key to close..." -ForegroundColor DarkGray
  $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
}
