
export interface DaoLaunch {
  id: string;
  name: string;
  token: string;
  treasury: number;
  launchDate: string;
  proposals: number | null;
}

export interface StartupKpis {
  mrr: number;
  cac: number;
  churnRate: string;
  burnRate: number;
  runway: number;
}

export interface AuditLog {
  id: string;
  action: string;
  details: string;
  user: string;
  timestamp: string;
  status: 'success' | 'failure' | 'pending';
  metadata?: {
    targetId?: string;
    targetType?: 'user' | 'system' | 'repo' | 'dating_user' | 'applicant';
    actionType?: 'security' | 'retry' | 'none' | 'ban' | 'verify' | 'approve' | 'reject';
  };
}

export type View = 
  | 'dashboard' | 'dao' | 'chat' | 'live' | 'command' 
  | 'audit' | 'media' | 'lifeskills' | 'kids' | 'dating' | 'dating-site' | 'impact' | 'browser' 
  | 'security' | 'governance' | 'mobile' | 'antigravity'
  | 'edu' | 'store' | 'pr' | 'review' | 'scripts' | 'launch' | 'auth-2fa'
  | 'command-1004' | 'hive' | 'droid' | 'royalty' | 'affiliate' | 'ms365' | 'campaign' | 'terminal';

export interface GroundingChunk {
  web?: {
    uri?: string;
    title?: string;
  };
  maps?: {
    uri?: string;
    title?: string;
  };
}

export interface ChatMessage {
  role: 'user' | 'model';
  content: string;
  groundingSources?: GroundingChunk[];
  image?: string; // Base64 string
}

export interface CampaignPlan {
  id?: string;
  title: string;
  emailSubject: string;
  emailBody: string;
  socialPost: string;
  estimatedReach: string;
  status?: 'Draft' | 'Scheduled' | 'Sent';
}

export type SystemHealth = 'Healthy' | 'Degraded' | 'Critical';

export interface AffiliatePartner {
  id: string;
  name: string;
  email: string;
  tier: 'Silver' | 'Gold' | 'Founder';
  referralCode: string;
  totalEarnings: number;
  pendingBalance: number;
  joinedAt: string;
  status: 'active' | 'suspended';
}

export interface ReferralSale {
  id: string;
  affiliateId: string;
  productName: string;
  saleAmount: number;
  commission: number;
  timestamp: string;
  status: 'pending' | 'verified' | 'paid';
}

export interface AffiliatePayout {
  id: string;
  affiliateId: string;
  amount: number;
  method: 'Polygon' | 'Square' | 'Wire';
  timestamp: string;
  txHash?: string;
}

export interface AntigravityApplicant {
  id: string;
  name: string;
  email: string;
  specialty: 'AI/ML' | 'Blockchain' | 'Full Stack' | 'Physics Engine' | 'Security';
  github: string;
  pitch: string;
  status: 'pending' | 'under_review' | 'accepted' | 'rejected';
  score: number;
  appliedAt: string;
}

export interface KickstarterProject {
  id: string;
  name: string;
  goal: number;
  pledged: number;
  backers?: number;
  daysLeft?: number;
  status?: 'active' | 'successful' | 'failed';
}

export type SubscriptionTier = 'Free' | 'Basic' | 'Premium' | 'VIP';

export interface DatingUser {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  plan: SubscriptionTier;
  trustScore: number;
  verified: boolean;
  status: 'active' | 'banned' | 'suspended';
  joinedAt: string;
  matches: number;
  revenue: number;
}

export interface ComplianceCheck {
  id: string;
  name: string;
  category: 'legal' | 'financial' | 'technical';
  status: 'pass' | 'fail' | 'warning';
  details: string;
  lastChecked: string;
}

export interface GovernanceProposal {
  id: string;
  title: string;
  description: string;
  votesFor: number;
  votesAgainst: number;
  status: 'active' | 'passed' | 'rejected';
  endDate: string;
}

export type PriorityLevel = 'Critical' | 'High' | 'Medium' | 'Low';
export type VipTier = 'Public' | 'Member' | 'Council' | 'Architect';

export interface JulesAction {
  id: string;
  title: string;
  details: string;
  priority: PriorityLevel;
  requiredTier: VipTier;
  status: 'Pending' | 'In Progress' | 'Completed';
  timestamp: string;
  impactValue: string;
}

export interface DaoLeader {
  id: string;
  name: string;
  role: string;
  tokensHeld: number;
  contributions: number;
  avatar: string;
}

export interface CommunitySuggestion {
  id: string;
  user: string;
  text: string;
  votes: number;
  status: 'raw' | 'polished' | 'mounted';
}

export type SignerRole = 'Founder' | 'Legal' | 'Cold_Storage' | 'AI_Auditor' | 'Guardian_Protocol';
export type SignerStatus = 'Active' | 'Offline' | 'Standby' | 'Triggered';

export interface TreasurySigner {
  id: string;
  name: string;
  role: SignerRole;
  status: SignerStatus;
  lastActive: string;
  isMachine: boolean;
}

declare global {
  interface Window {
    showDirectoryPicker(): Promise<FileSystemDirectoryHandle>;
  }
  interface FileSystemHandle {
    readonly kind: 'file' | 'directory';
    readonly name: string;
  }
  interface FileSystemFileHandle extends FileSystemHandle {
    getFile(): Promise<File>;
    createWritable(): Promise<FileSystemWritableFileStream>;
  }
  interface FileSystemDirectoryHandle extends FileSystemHandle {
    values(): AsyncIterableIterator<FileSystemHandle>;
  }
  interface FileSystemWritableFileStream extends WritableStream {
    write(data: string): Promise<void>;
    close(): Promise<void>;
  }
}
