
import { GoogleGenAI } from '@google/genai';
import React, { useState, useEffect } from 'react';
import AffiliatePortal from './components/AffiliatePortal';
import AnalysisModal from './components/AnalysisModal';
import AntigravityConsole from './components/AntigravityConsole';
import AuditLogTable from './components/AuditLogTable';
import CampaignPlanner from './components/CampaignPlanner';
import ChatView from './components/ChatView';
import CodeReviewer from './components/CodeReviewer';
import CometBrowser from './components/CometBrowser';
import CommandCenter from './components/CommandCenter';
import DaoGovernance from './components/DaoGovernance';
import DaoTable from './components/DaoTable';
import DashboardView from './components/DashboardView';
import DatingManager from './components/DatingManager';
import EduNexus from './components/EduNexus';
import { ShieldCheck, Lock, Users, Server } from './components/IconComponents';
import ImpactTracker from './components/ImpactTracker';
import LifeSkillsStudio from './components/KidsCorner';
import LaunchPad from './components/LaunchPad';
import LiveChatView from './components/LiveChatView';
import MediaStudio from './components/MediaStudio';
import MicrosoftNexus from './components/MicrosoftNexus';
import MissionManifesto from './components/MissionManifesto';
import MobileBridge from './components/MobileBridge';
import PrWizard from './components/PrWizard';
import RoyaltyDeck from './components/RoyaltyDeck';
import ScriptGenerator from './components/ScriptGenerator';
import SecurityNexus from './components/SecurityNexus';
import Sidebar from './components/Sidebar';
import StoreCommand from './components/StoreCommand';
import TitleBar from './components/TitleBar';
import TwoFactorAuth from './components/TwoFactorAuth';
import { initialDaoLaunches, initialAuditLogs } from './data/mockData';
import { View, AuditLog, DaoLaunch } from './types';

const App: React.FC = () => {
    const [view, setView] = useState<View>('dashboard');
    const [isMobileOpen, setIsMobileOpen] = useState(false);
    const [isAuthenticated, setIsAuthenticated] = useState(false);
    const [currentUser, setCurrentUser] = useState<any>(null);
    const [authError, setAuthError] = useState('');
    const [isMissionOpen, setIsMissionOpen] = useState(false);
    
    // 2FA State
    const [is2FAEnabled, setIs2FAEnabled] = useState(false);
    const [_is2FAVerified, _setIs2FAVerified] = useState(false);
    const [_show2FASetup, _setShow2FASetup] = useState(false);

    // Data State
    const [auditLogs, setAuditLogs] = useState<AuditLog[]>(initialAuditLogs);
    const [daoLaunches, _setDaoLaunches] = useState<DaoLaunch[]>(initialDaoLaunches);

    // Analysis Modal State
    const [analysisData, setAnalysisData] = useState<{ isOpen: boolean; title: string; content: string | null; isLoading: boolean }>({
        isOpen: false,
        title: '',
        content: null,
        isLoading: false
    });

    useEffect(() => {
        const savedUser = localStorage.getItem('aiCollabUser');
        if (savedUser) {
            const user = JSON.parse(savedUser);
            setCurrentUser(user);
            const user2FA = localStorage.getItem('aiCollabUser2FA');
            if (user2FA === 'enabled') {
                setIs2FAEnabled(true);
                _setIs2FAVerified(true); 
            }
            setIsAuthenticated(true);
        }
    }, []);

    const _handleCredentialResponse = (response: any) => {
        const base64Url = response.credential.split('.')[1];
        const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
        const jsonPayload = decodeURIComponent(window.atob(base64).split('').map(function(c) {
            return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
        }).join(''));
        const payload = JSON.parse(jsonPayload);

        if (payload.email === 'joshlcoleman@gmail.com' || payload.email_verified) {
            const user2FA = localStorage.getItem('aiCollabUser2FA');
            if (user2FA === 'enabled') {
                setIs2FAEnabled(true);
                setCurrentUser(payload);
                _setIs2FAVerified(false);
            } else {
                setIsAuthenticated(true);
                setCurrentUser(payload);
                localStorage.setItem('aiCollabUser', JSON.stringify(payload));
            }
            setAuthError('');
        } else {
            setAuthError('Unauthorized Account. Access Restricted.');
        }
    };

    const handleDevBypass = () => {
        const ownerUser = {
            email: 'joshlcoleman@gmail.com',
            name: 'Joshua Coleman (Architect)',
            picture: 'https://github.com/Trollz1004.png',
            email_verified: true
        };
        setCurrentUser(ownerUser);
        setIsAuthenticated(true);
        localStorage.setItem('aiCollabUser', JSON.stringify(ownerUser));
    };

    const handleAnalyzeDao = async (dao: DaoLaunch) => {
        setAnalysisData({ isOpen: true, title: `Jules Mission Audit: ${dao.name}`, content: null, isLoading: true });
        
        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const response = await ai.models.generateContent({
                model: 'gemini-3-flash-preview',
                contents: `Analyze this DAO for Joshua Coleman under THE COLEMAN PROTOCOL (100% Independence/Charity).
                
                DAO Data: ${JSON.stringify(dao)}
                
                CONTEXT: The platform now runs 100% for pediatric charities and special needs independence. 
                
                YOUR TASK:
                1. Verify alignment with special needs independence goals.
                2. Suggest how Node 9020 can automate support for handicapped individuals in this DAO.
                3. Explain the succession impact on the Coleman family beneficiaries.`,
                config: { thinkingConfig: { thinkingBudget: 4096 } }
            });
            setAnalysisData(prev => ({ ...prev, content: response.text || "Analysis Lost.", isLoading: false }));
        } catch (e) {
            console.error(e);
            setAnalysisData(prev => ({ ...prev, content: "## Neural Disconnect\nAudit aborted.", isLoading: false }));
        }
    };

    if (!isAuthenticated && !currentUser) {
        return (
            <div className="min-h-screen bg-[#050505] flex items-center justify-center relative overflow-hidden">
                <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10"></div>
                <div className="glass-card p-10 max-w-md w-full text-center relative z-10 border border-white/10 shadow-2xl">
                    <div className="w-20 h-20 bg-indigo-600/20 rounded-full flex items-center justify-center mx-auto mb-6 border border-indigo-500/30">
                        <ShieldCheck className="w-10 h-10 text-indigo-400" />
                    </div>
                    <h1 className="text-3xl font-bold text-white mb-2">AiCollab<span className="text-indigo-400">Admin</span></h1>
                    <p className="text-slate-400 mb-8 text-sm">Human Independence Infrastructure</p>
                    <div className="flex flex-col items-center gap-4 mb-6">
                        <div id="googleSignInDiv"></div>
                        <div className="w-full flex items-center gap-2">
                            <div className="flex-1 h-px bg-white/10"></div>
                            <span className="text-[10px] text-slate-500 uppercase font-bold">Owner Access</span>
                            <div className="flex-1 h-px bg-white/10"></div>
                        </div>
                        <button onClick={handleDevBypass} className="w-full py-2.5 bg-indigo-600/10 hover:bg-indigo-600/20 text-indigo-400 border border-indigo-500/30 rounded-full text-sm font-bold transition-all flex items-center justify-center gap-2">
                            <Users className="w-4 h-4" /> Joshua&apos;s Quick Access
                        </button>
                    </div>
                    {authError && <div className="p-3 bg-red-900/30 border border-red-500/30 rounded-lg text-red-400 text-sm flex items-center justify-center gap-2"><Lock className="w-4 h-4" /> {authError}</div>}
                    <p className="mt-8 text-xs text-slate-500 font-mono text-center">MISSION: THE COLEMAN PROTOCOL<br />100% DISBURSEMENT TO INDEPENDENCE</p>
                </div>
            </div>
        );
    }

    return (
        <div className="flex h-screen bg-[#0f172a] text-slate-100 font-sans overflow-hidden">
            <Sidebar currentView={view} onSetView={setView} isMobileOpen={isMobileOpen} onMobileClose={() => setIsMobileOpen(false)} onOpenMission={() => setIsMissionOpen(true)} />
            <div className="flex-1 flex flex-col min-w-0 relative">
                <TitleBar />
                <div className="mt-[30px] flex-1 overflow-hidden relative flex flex-col animate-in fade-in duration-500">
                    {view === 'dashboard' && <DashboardView />}
                    {view === 'launch' && <LaunchPad />}
                    {view === 'command' && <CommandCenter onLogAction={(a, d) => setAuditLogs(prev => [{id: Date.now().toString(), action: a, details: d, user: currentUser.email, timestamp: new Date().toISOString(), status: 'success'}, ...prev])} repoStatus="Synced" onCheckStatus={() => {}} />}
                    {view === 'governance' && <DaoGovernance />}
                    {view === 'audit' && <AuditLogTable logs={auditLogs} />}
                    {view === 'security' && <SecurityNexus onEnable2FA={() => _setShow2FASetup(true)} is2FAEnabled={is2FAEnabled} />}
                    {view === 'impact' && <ImpactTracker />}
                    {view === 'store' && <StoreCommand />}
                    {view === 'dating' && <DatingManager />}
                    {view === 'dao' && <DaoTable daoLaunches={daoLaunches} onAnalyze={handleAnalyzeDao} />}
                    {view === 'antigravity' && <AntigravityConsole />}
                    {view === 'scripts' && <ScriptGenerator />}
                    {view === 'edu' && <EduNexus />}
                    {view === 'pr' && <PrWizard />}
                    {view === 'review' && <CodeReviewer />}
                    {view === 'media' && <MediaStudio />}
                    {view === 'lifeskills' && <LifeSkillsStudio />}
                    {view === 'browser' && <CometBrowser />}
                    {view === 'chat' && <ChatView />}
                    {view === 'live' && <LiveChatView />}
                    {view === 'mobile' && <MobileBridge />}
                    {view === 'royalty' && <RoyaltyDeck />}
                    {view === 'affiliate' && <AffiliatePortal />}
                    {view === 'ms365' && <MicrosoftNexus />}
                    {view === 'campaign' && <CampaignPlanner />}
                    {view === 'command-1004' && (
                        <div className="flex-1 bg-black flex flex-col">
                            <div className="p-2 bg-slate-800 flex justify-between items-center text-xs border-b border-white/10">
                                <div className="flex items-center gap-2">
                                    <Server className="w-4 h-4 text-indigo-400" />
                                    <span className="font-bold text-white">Node 9020 (Primary Command)</span>
                                </div>
                                <button className="text-blue-400 hover:text-white" onClick={() => window.open('http://localhost:1004', '_blank')}>Open External</button>
                            </div>
                            <iframe src="http://localhost:1004" className="flex-1 w-full h-full border-none" title="Node 9020 Command" />
                        </div>
                    )}
                    {view === 'terminal' && <CommandCenter onLogAction={(a, d) => setAuditLogs(prev => [{id: Date.now().toString(), action: a, details: d, user: currentUser.email, timestamp: new Date().toISOString(), status: 'success'}, ...prev])} repoStatus="Synced" onCheckStatus={() => {}} />}
                </div>
            </div>
            <MissionManifesto isOpen={isMissionOpen} onClose={() => setIsMissionOpen(false)} />
            <AnalysisModal isOpen={analysisData.isOpen} onClose={() => setAnalysisData(prev => ({ ...prev, isOpen: false }))} title={analysisData.title} content={analysisData.content} isLoading={analysisData.isLoading} />
        </div>
    );
};

export default App;
