
const express = require('express');
const router = express.Router();
const logger = require('../utils/logger');

// POST /api/affiliates/register - Create a new affiliate partner
router.post('/register', async (req, res) => {
    try {
        const { name, email, tier } = req.body;
        const referralCode = `REF-${Math.random().toString(36).substring(7).toUpperCase()}`;

        const result = await req.app.locals.pool.query(
            `INSERT INTO affiliates (name, email, tier, referral_code, status)
             VALUES ($1, $2, $3, $4, 'active')
             RETURNING id, referral_code`,
            [name, email, tier || 'Silver', referralCode]
        );

        res.json({ success: true, partner: result.rows[0] });
    } catch (error) {
        logger.error('Affiliate registration error:', error);
        res.status(500).json({ error: 'Registration failed' });
    }
});

// GET /api/affiliates/stats/:id - Get stats for a specific partner
router.get('/stats/:id', async (req, res) => {
    try {
        const { id } = req.params;
        
        const earningsResult = await req.app.locals.pool.query(
            `SELECT SUM(commission) as total, COUNT(*) as sales_count
             FROM referral_sales
             WHERE affiliate_id = $1`,
            [id]
        );

        res.json({ 
            success: true, 
            stats: {
                totalEarnings: earningsResult.rows[0].total || 0,
                salesCount: earningsResult.rows[0].sales_count || 0
            }
        });
    } catch (error) {
        logger.error('Affiliate stats error:', error);
        res.status(500).json({ error: 'Failed to fetch stats' });
    }
});

// POST /api/affiliates/payout - Request or execute a payout
router.post('/payout', async (req, res) => {
    try {
        const { affiliateId, amount, method } = req.body;
        
        // Automation logic for Polygon tx would go here
        
        const result = await req.app.locals.pool.query(
            `INSERT INTO affiliate_payouts (affiliate_id, amount, method, status)
             VALUES ($1, $2, $3, 'completed')
             RETURNING id, timestamp`,
            [affiliateId, amount, method]
        );

        res.json({ success: true, payout: result.rows[0] });
    } catch (error) {
        logger.error('Payout error:', error);
        res.status(500).json({ error: 'Payout processing failed' });
    }
});

module.exports = router;
