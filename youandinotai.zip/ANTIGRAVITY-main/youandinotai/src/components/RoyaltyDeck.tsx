/**
 * RoyaltyDeck.tsx — The Royalty Deck of Hearts
 *
 * Premium holographic card component showcasing the $2,500 Royalty Card.
 * 3D perspective tilt, holographic shimmer, floating hearts, and
 * founder-tier launch messaging.
 *
 * @license Apache-2.0
 */

import { useState, useRef } from 'react';
import { motion, useMotionValue, useTransform, useSpring } from 'motion/react';
import { Crown, Heart, Shield, Star, Gem, Infinity as InfinityIcon, Zap } from 'lucide-react';

const ROYALTY_LINK = 'https://square.link/u/CafhorUS';

/* ─── Floating Hearts Background ─── */
function FloatingHearts() {
  const hearts = Array.from({ length: 12 }, (_, i) => ({
    id: i,
    left: `${8 + Math.random() * 84}%`,
    delay: Math.random() * 5,
    duration: 4 + Math.random() * 6,
    size: 10 + Math.random() * 14,
    opacity: 0.08 + Math.random() * 0.12,
  }));

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {hearts.map((h) => (
        <motion.div
          key={h.id}
          className="absolute text-amber-400"
          style={{ left: h.left, bottom: '-20px', opacity: h.opacity }}
          animate={{ y: [0, -800], opacity: [h.opacity, 0], rotate: [0, 360] }}
          transition={{ duration: h.duration, delay: h.delay, repeat: Infinity, ease: 'linear' }}
        >
          <Heart size={h.size} fill="currentColor" />
        </motion.div>
      ))}
    </div>
  );
}

/* ─── Holographic Card ─── */
function HolographicCard() {
  const cardRef = useRef<HTMLDivElement>(null);
  const [isHovering, setIsHovering] = useState(false);

  const mouseX = useMotionValue(0.5);
  const mouseY = useMotionValue(0.5);

  const rotateX = useSpring(useTransform(mouseY, [0, 1], [12, -12]), { stiffness: 200, damping: 20 });
  const rotateY = useSpring(useTransform(mouseX, [0, 1], [-12, 12]), { stiffness: 200, damping: 20 });

  const sheenX = useTransform(mouseX, [0, 1], ['-100%', '200%']);
  const sheenY = useTransform(mouseY, [0, 1], ['-100%', '200%']);

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    mouseX.set((e.clientX - rect.left) / rect.width);
    mouseY.set((e.clientY - rect.top) / rect.height);
  };

  const handleMouseLeave = () => {
    setIsHovering(false);
    mouseX.set(0.5);
    mouseY.set(0.5);
  };

  const benefits = [
    { icon: InfinityIcon, text: 'Lifetime VIP access — never pay again', from: 'from-purple-400', to: 'to-purple-600' },
    { icon: Shield, text: 'Priority matching & dedicated support', from: 'from-blue-400', to: 'to-blue-600' },
    { icon: Star, text: 'Exclusive Royalty badge on your profile', from: 'from-amber-300', to: 'to-amber-500' },
    { icon: Zap, text: 'Early access to every new feature', from: 'from-pink-400', to: 'to-pink-600' },
    { icon: Gem, text: 'Revenue share from platform growth', from: 'from-emerald-400', to: 'to-emerald-600' },
  ];

  return (
    <div style={{ perspective: '1200px' }} className="w-full max-w-md mx-auto">
      <motion.div
        ref={cardRef}
        onMouseMove={handleMouseMove}
        onMouseEnter={() => setIsHovering(true)}
        onMouseLeave={handleMouseLeave}
        style={{ rotateX, rotateY, transformStyle: 'preserve-3d' }}
        initial={{ opacity: 0, y: 60, scale: 0.9 }}
        whileInView={{ opacity: 1, y: 0, scale: 1 }}
        viewport={{ once: true, margin: '-50px' }}
        transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
        className="relative rounded-3xl overflow-hidden cursor-pointer group"
      >
        {/* Card base with gold gradient border */}
        <div className="absolute inset-0 rounded-3xl bg-gradient-to-br from-amber-400 via-yellow-300 to-orange-500 p-[2px]">
          <div className="w-full h-full rounded-3xl bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950" />
        </div>

        {/* Holographic shimmer overlay */}
        <motion.div
          className="absolute inset-0 rounded-3xl pointer-events-none z-10"
          style={{
            background: `linear-gradient(
              115deg,
              transparent 20%,
              rgba(255, 215, 0, 0.08) 35%,
              rgba(255, 180, 50, 0.12) 40%,
              rgba(255, 100, 200, 0.08) 45%,
              rgba(100, 200, 255, 0.08) 50%,
              rgba(255, 215, 0, 0.12) 55%,
              transparent 70%
            )`,
            backgroundSize: '200% 200%',
            backgroundPosition: isHovering ? undefined : 'center',
            x: sheenX,
            y: sheenY,
            opacity: isHovering ? 1 : 0.3,
            mixBlendMode: 'screen',
          }}
          transition={{ opacity: { duration: 0.3 } }}
        />

        {/* Outer glow on hover */}
        <motion.div
          className="absolute -inset-1 rounded-3xl pointer-events-none"
          style={{
            background: 'radial-gradient(ellipse at center, rgba(255,215,0,0.2) 0%, transparent 70%)',
            opacity: isHovering ? 1 : 0,
          }}
          transition={{ duration: 0.3 }}
        />

        {/* Card content */}
        <div className="relative z-20 p-6 md:p-8">
          {/* Top row: suit corners + crown */}
          <div className="flex items-start justify-between mb-4">
            <div className="flex flex-col items-center">
              <span className="text-amber-400 text-2xl font-black leading-none">R</span>
              <Heart size={14} className="text-red-500 fill-red-500 mt-0.5" />
            </div>
            <motion.div
              animate={{ y: [0, -6, 0] }}
              transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
              className="relative w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-300 to-orange-500 border-b-[4px] border-orange-700 shadow-[0_8px_16px_rgba(245,158,11,0.4)] flex items-center justify-center transform rotate-3"
            >
              <Crown size={32} className="text-white drop-shadow-lg" strokeWidth={2.5} />
              <div className="absolute top-0 left-0 right-0 h-1/2 bg-gradient-to-b from-white/40 to-transparent rounded-t-2xl pointer-events-none" />
              <div className="absolute inset-0 rounded-2xl shadow-[inset_0_-2px_6px_rgba(0,0,0,0.2)] pointer-events-none" />
            </motion.div>
            <div className="flex flex-col items-center">
              <span className="text-amber-400 text-2xl font-black leading-none rotate-180">R</span>
              <Heart size={14} className="text-red-500 fill-red-500 mt-0.5" />
            </div>
          </div>

          {/* Title */}
          <div className="text-center mb-5">
            <h3 className="text-3xl md:text-4xl font-black tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-yellow-200 to-amber-400 leading-tight">
              ROYALTY CARD
            </h3>
            <div className="flex items-center justify-center gap-2 mt-1">
              <div className="h-px flex-1 max-w-[60px] bg-gradient-to-r from-transparent to-amber-500/50" />
              <span className="text-xs uppercase tracking-[0.3em] text-amber-400/70 font-bold">Deck of Hearts</span>
              <div className="h-px flex-1 max-w-[60px] bg-gradient-to-l from-transparent to-amber-500/50" />
            </div>
          </div>

          {/* Price */}
          <div className="text-center mb-6">
            <div className="inline-block relative">
              <span className="text-5xl md:text-6xl font-black text-transparent bg-clip-text bg-gradient-to-b from-white via-amber-100 to-amber-300 leading-none">
                $2,500
              </span>
              <motion.div
                className="absolute -top-3 -right-6 w-8 h-8 rounded-full bg-gradient-to-br from-emerald-300 to-teal-500 border-b-[2px] border-teal-700 shadow-lg flex items-center justify-center"
                animate={{ rotate: [0, 15, -15, 0], scale: [1, 1.1, 1] }}
                transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
              >
                <Gem size={14} className="text-white drop-shadow-md" strokeWidth={2.5} />
                <div className="absolute top-0 left-0 right-0 h-1/2 bg-gradient-to-b from-white/40 to-transparent rounded-t-full pointer-events-none" />
              </motion.div>
            </div>
            <p className="text-amber-400/60 text-xs mt-1 uppercase tracking-widest font-bold">One-time • Lifetime access</p>
          </div>

          {/* Benefits */}
          <div className="space-y-3 mb-6">
            {benefits.map((b, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.1 * i + 0.3, duration: 0.4 }}
                className="flex items-center gap-4 text-sm bg-white/5 border border-white/10 rounded-2xl p-2 pr-4 hover:bg-white/10 transition-colors"
              >
                <div className={`relative flex-shrink-0 w-10 h-10 rounded-xl bg-gradient-to-br ${b.from} ${b.to} border-b-[3px] border-black/30 shadow-lg flex items-center justify-center transform ${i % 2 === 0 ? '-rotate-3' : 'rotate-3'}`}>
                  <b.icon size={20} className="text-white drop-shadow-md" strokeWidth={2.5} />
                  {/* Glossy highlight */}
                  <div className="absolute top-0 left-0 right-0 h-1/2 bg-gradient-to-b from-white/30 to-transparent rounded-t-xl pointer-events-none" />
                  {/* Inner shadow for 3D effect */}
                  <div className="absolute inset-0 rounded-xl shadow-[inset_0_-2px_4px_rgba(0,0,0,0.2)] pointer-events-none" />
                </div>
                <span className="text-gray-200 font-medium">{b.text}</span>
              </motion.div>
            ))}
          </div>

          {/* Founder callout */}
          <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-xl p-3 mb-6 text-center">
            <p className="text-emerald-400 text-sm font-bold">
              Only 5 Royalty Cards will be issued at launch
            </p>
            <p className="text-emerald-400/60 text-xs mt-0.5">
              Lifetime VIP access plus the published founder revenue-share terms
            </p>
          </div>

          {/* CTA */}
          <a
            href={ROYALTY_LINK}
            target="_blank"
            rel="noopener noreferrer"
            className="block w-full text-center no-underline"
          >
            <motion.div
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              className="relative overflow-hidden py-4 px-8 rounded-2xl bg-gradient-to-b from-yellow-300 to-amber-500 text-black font-black text-lg shadow-[0_6px_0_#b45309,0_15px_20px_rgba(245,158,11,0.4)] hover:shadow-[0_4px_0_#b45309,0_10px_15px_rgba(245,158,11,0.4)] hover:translate-y-[2px] active:shadow-[0_0px_0_#b45309,0_0px_0px_rgba(245,158,11,0.4)] active:translate-y-[6px] transition-all"
            >
              <span className="relative z-10 flex items-center justify-center gap-2 drop-shadow-sm">
                <Crown size={20} strokeWidth={2.5} />
                Claim Your Royalty Card
              </span>
              {/* Glossy top highlight */}
              <div className="absolute top-0 left-0 right-0 h-1/3 bg-gradient-to-b from-white/40 to-transparent rounded-t-2xl pointer-events-none" />
              {/* Animated shine */}
              <motion.div
                className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent skew-x-12"
                animate={{ x: ['-150%', '250%'] }}
                transition={{ duration: 2.5, repeat: Infinity, repeatDelay: 4, ease: 'easeInOut' }}
              />
            </motion.div>
          </a>

          {/* Bottom suit corners */}
          <div className="flex justify-between mt-4">
            <Heart size={12} className="text-red-500/30 fill-red-500/30" />
            <div className="flex gap-1">
              {[...Array(5)].map((_, i) => (
                <Heart key={i} size={8} className="text-red-500/20 fill-red-500/20" />
              ))}
            </div>
            <Heart size={12} className="text-red-500/30 fill-red-500/30" />
          </div>
        </div>
      </motion.div>
    </div>
  );
}

/* ─── Main Export ─── */
export function RoyaltyDeck() {
  return (
    <section className="relative z-10 py-16 md:py-24 px-4 overflow-hidden">
      {/* Ambient glow behind everything */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-amber-500/5 rounded-full blur-[120px]" />
      </div>

      <FloatingHearts />

      <div className="max-w-2xl mx-auto relative">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-10"
        >
          <div className="inline-flex items-center gap-2 bg-amber-400/10 border border-amber-400/20 rounded-full px-4 py-1.5 mb-4 shadow-[0_0_15px_rgba(245,158,11,0.2)]">
            <div className="w-5 h-5 rounded-full bg-gradient-to-br from-amber-300 to-orange-500 flex items-center justify-center shadow-sm border-b border-black/20">
              <Crown size={10} className="text-white" strokeWidth={3} />
            </div>
            <span className="text-xs uppercase tracking-[0.2em] text-amber-400 font-bold">Limited Edition</span>
          </div>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-yellow-200 to-amber-400 mb-3">
            The Royalty Deck of Hearts
          </h2>
          <p className="text-gray-400 text-sm md:text-base max-w-md mx-auto leading-relaxed">
            The ultimate founding membership. Lifetime VIP status, revenue share,
            and priority access to every premium feature that follows launch.
          </p>
        </motion.div>

        {/* The card */}
        <HolographicCard />

        {/* Trust badges */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5, duration: 0.6 }}
          className="flex flex-wrap justify-center gap-4 mt-8 text-xs text-gray-400 font-medium"
        >
          <span className="flex items-center gap-2 bg-white/5 px-3 py-1.5 rounded-full border border-white/10">
            <div className="w-5 h-5 rounded-full bg-gradient-to-br from-emerald-400 to-teal-600 flex items-center justify-center shadow-sm border-b border-black/20">
              <Shield size={10} className="text-white" strokeWidth={3} />
            </div>
            Final sale terms
          </span>
          <span className="flex items-center gap-2 bg-white/5 px-3 py-1.5 rounded-full border border-white/10">
            <div className="w-5 h-5 rounded-full bg-gradient-to-br from-red-400 to-rose-600 flex items-center justify-center shadow-sm border-b border-black/20">
              <Heart size={10} className="text-white fill-white" strokeWidth={3} />
            </div>
            Founder terms locked
          </span>
          <span className="flex items-center gap-2 bg-white/5 px-3 py-1.5 rounded-full border border-white/10">
            <div className="w-5 h-5 rounded-full bg-gradient-to-br from-amber-300 to-orange-500 flex items-center justify-center shadow-sm border-b border-black/20">
              <Star size={10} className="text-white fill-white" strokeWidth={3} />
            </div>
            5 cards total
          </span>
        </motion.div>
      </div>
    </section>
  );
}
