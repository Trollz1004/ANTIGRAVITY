import React from 'react';
import { motion } from 'motion/react';
import { CalendarDays, DollarSign, Heart, ShieldCheck, Sparkles, Users } from 'lucide-react';

const cards = [
  {
    icon: Heart,
    title: '60% to Shriners',
    body: 'Every $1 Bot-Shield verification and every Founder Plan subscription directly supports Shriners Children\'s hospitals.',
    href: '#pricing',
    cta: 'Support the Cause',
    color: 'from-emerald-400 to-teal-600',
  },
  {
    icon: Users,
    title: 'Community First',
    body: 'We believe a dating app should do more than just match people. It should make a positive impact on the world.',
    href: '#mission',
    cta: 'Our Mission',
    color: 'from-green-400 to-lime-600',
  },
  {
    icon: Sparkles,
    title: 'Transparent Giving',
    body: 'We are committed to transparency. Our charity impact ledger will be public, showing exactly how much we\'ve raised.',
    href: '#pricing',
    cta: 'View Plans',
    color: 'from-rose-400 to-orange-500',
  },
];

const stats = [
  { icon: Heart, label: 'Donation Rate', value: '60%' },
  { icon: Users, label: 'Beneficiary', value: "Shriners" },
  { icon: Sparkles, label: 'Impact', value: 'Real Lives' },
];

function Particle({ delay }: { delay: number }) {
  return (
    <motion.div
      initial={{ y: '100%', opacity: 0, x: Math.random() * 100 + '%' }}
      animate={{ y: '-10%', opacity: [0, 1, 1, 0], x: `${Math.random() * 100}%` }}
      transition={{ duration: Math.random() * 10 + 10, repeat: Infinity, delay, ease: 'linear' }}
      className="absolute h-1 w-1 rounded-full bg-emerald-400 blur-[1px]"
    />
  );
}

export function CharitySection() {
  return (
    <section
      id="mission"
      className="relative overflow-hidden bg-gradient-to-b from-black via-[#08150d] to-[#041109] px-6 py-24"
    >
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        {[...Array(30)].map((_, index) => (
          <Particle key={index} delay={index * 0.45} />
        ))}
      </div>

      <div className="relative z-10 mx-auto max-w-7xl">
        <div className="mb-20 space-y-6 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 rounded-full border border-emerald-500/20 bg-emerald-500/10 px-4 py-2 text-xs font-black uppercase tracking-[0.3em] text-emerald-400"
          >
            <Heart size={14} />
            Charity Mission
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-4xl font-black leading-none tracking-tighter text-white md:text-7xl"
          >
            Real Connections.
            <br />
            Real Community.
            <br />
            <span className="bg-gradient-to-r from-emerald-400 to-green-600 bg-clip-text text-transparent">
              Real Impact.
            </span>
          </motion.h2>

          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="mx-auto max-w-3xl text-lg font-light text-gray-400"
          >
            YouAndiNotAi keeps its mission at the forefront: 60% of all proceeds are donated to Shriners Children's. Bot-Shield verification and public founder pricing help us build a real community while making a real difference.
          </motion.p>
        </div>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="mb-20 grid grid-cols-1 gap-8 rounded-[3rem] border border-white/5 bg-zinc-900/50 p-8 backdrop-blur-md md:grid-cols-3"
        >
          {stats.map((stat) => (
            <div key={stat.label} className="flex flex-col items-center space-y-2 text-center">
              <div className="rounded-2xl bg-emerald-500/10 p-3 text-emerald-400">
                <stat.icon size={24} />
              </div>
              <div className="text-3xl font-black text-white">{stat.value}</div>
              <div className="text-[10px] font-bold uppercase tracking-widest text-gray-500">{stat.label}</div>
            </div>
          ))}
        </motion.div>

        <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
          {cards.map((card) => (
            <motion.div key={card.title} whileHover={{ y: -10, scale: 1.02 }} className="relative group">
              <div
                className={`absolute -inset-1 rounded-[2.5rem] bg-gradient-to-r ${card.color} opacity-25 blur transition duration-1000 group-hover:opacity-75 group-hover:duration-200`}
              />
              <div className="relative flex h-full flex-col rounded-[2.5rem] border border-white/10 bg-zinc-900/90 p-8 backdrop-blur-xl">
                <div className={`mb-6 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br ${card.color} shadow-lg shadow-green-500/20`}>
                  <card.icon className="text-white" size={32} />
                </div>
                <h3 className="mb-3 text-2xl font-black uppercase tracking-tight text-white">{card.title}</h3>
                <p className="mb-8 flex-1 text-sm leading-relaxed text-gray-400">{card.body}</p>
                <a
                  href={card.href}
                  className="flex w-full items-center justify-center gap-2 rounded-2xl border border-white/10 bg-white/5 py-4 font-bold text-white no-underline transition-all hover:border-emerald-400 hover:bg-emerald-500"
                >
                  {card.cta}
                </a>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="mt-20 text-center">
          <div className="inline-flex items-center gap-4 rounded-3xl border border-white/10 bg-white/5 p-6">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-emerald-500 text-white">
              <Heart size={24} />
            </div>
            <div className="text-left">
              <div className="text-sm font-bold uppercase tracking-tight text-white">Charity First</div>
              <div className="text-xs text-gray-400">
                60% of all proceeds from Bot-Shield and Founder Plans go directly to Shriners Children's.
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
